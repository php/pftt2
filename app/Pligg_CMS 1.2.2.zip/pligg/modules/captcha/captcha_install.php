<?php
	$module_info['name'] = 'Captcha';
	$module_info['desc'] = 'Allows you to add CAPTCHA fields to the register, comment or story submission fields to prevent mass posting.';
	$module_info['version'] = 1.0;
	$module_info['settings_url'] = '../module.php?module=captcha';
	//$module_info['db_add_field'][]=array(table_prefix . 'links', 'akismet', 'TINYINT',  3, "UNSIGNED", 0, '0');
?>

