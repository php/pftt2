<?php
	$module_info['name'] = 'Human Check';
	$module_info['desc'] = 'Allows you to protect story submission form to prevent mass posting.';
	$module_info['version'] = 1.0;
	//$module_info['settings_url'] = '../module.php?module=hc';
	//$module_info['db_add_field'][]=array(table_prefix . 'links', 'akismet', 'TINYINT',  3, "UNSIGNED", 0, '0');
?>

