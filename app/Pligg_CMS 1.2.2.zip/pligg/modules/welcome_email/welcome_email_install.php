<?php
	$module_info['name'] = 'Send Welcome Email';
	$module_info['desc'] = 'Sends welcome to email to a user who just registered.';
	$module_info['version'] = 0.2;
?>