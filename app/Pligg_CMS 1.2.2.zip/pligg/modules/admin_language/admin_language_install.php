<?php
	$module_info['name'] = 'Admin Modify Language';
	$module_info['desc'] = 'Allows the god users to modify the lang.conf file';
	$module_info['version'] = 0.2;
	$module_info['settings_url'] = '../module.php?module=admin_language';
	// this is where you set the modules "name" and "version" that is required
	// if more that one module is required then just make a copy of that line
?>
