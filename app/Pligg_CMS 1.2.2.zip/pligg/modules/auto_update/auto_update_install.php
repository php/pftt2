<?php
	$module_info['name'] = 'Pligg Auto Update module';
	$module_info['desc'] = 'This module connects to Pligg.com every 24 hours and checks if there is a new version out. If there is a more recent version it will suggest that you upgrade through a notice on the Pligg Admin Panel. ';
	$module_info['version'] = 0.1;
	$module_info['update_url'] = 'http://forums.pligg.com/versioncheck.php?product=autoupdate';
//	$module_info['homepage_url'] = 'http://forums.pligg.com/pligg-modules/19061-pligg-update-notifier.html';
?>