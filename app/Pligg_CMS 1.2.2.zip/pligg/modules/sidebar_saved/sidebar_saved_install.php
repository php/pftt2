<?php
	$module_info['name'] = 'Sidebar Saved';
	$module_info['desc'] = 'Displays recently saved stories in the sidebar.';
	$module_info['version'] = 0.2;
	// $module_info['requires'][] = array('', 0.2);
?>
