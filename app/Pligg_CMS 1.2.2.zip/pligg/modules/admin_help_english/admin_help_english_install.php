<?php

	$module_info['name'] = 'Admin Help English';

	$module_info['desc'] = 'Help documents to introduce you to Pligg and provide you with common answers and definitions.';

	$module_info['version'] = 0.3;


?>