<?php

echo ' <br />
		</div>
	</div>
</div>


<div id="footer-wrap">
	<div class="footer">
		<div class="rss-feeds">
			<h1>Pligg CMS RSS Feeds</h1>
			<ul>
				<li><a href="http://www.pligg.com/blog/feed/" target="_blank">Blog</a></li>
				<li><a href="http://twitter.com/statuses/user_timeline/6024362.rss" target="_blank">Twitter</a></li>
				<li><a href="http://forums.pligg.com/external.php" target="_blank">Forum</a></li>
			</ul>
		</div>
	</div>
	<div id="about">
		<h3><a href="http://forums.pligg.com/">Help!</a></h3>
		<br /><div class="design">For support and additional free downloads to enhance your Pligg install please visit <a href="http://www.pligg.com">Pligg.com</a> and the <a href="http://forums.pligg.com">Pligg Forum.</a></div>
		<br>
	</div>
</div>

</body>
</html>';

?>
