---------------------------------------------------------------
  Release
---------------------------------------------------------------

   We proudly present Pligg CMS 1.2.2
   Released May 18, 2012 12:45 PDT
   SVN Build: 2464

---------------------------------------------------------------
  Installation and Upgrading
---------------------------------------------------------------

   Please see the readme.html file included with the release for 
   the most up to date and detailed instructions for installing 
   and upgrading Pligg.

---------------------------------------------------------------
  CHANGELOG
---------------------------------------------------------------

   This update addresses security issues, adds a few smaller 
   features, takes some steps to optimize code, and adds
   some older phrases that were previously left out of the 
   language file.
   
---------------------------------------------------------------
  Links
---------------------------------------------------------------

   Homepage : http://pligg.com/
   Forums : http://forums.pligg.com/
   Donate : http://forums.pligg.com/donate/
   Gallery : http://www.pligg.com/gallery/
   Shop : http://pligg.com/pro/
   Blog : http://pligg.com/blog/

---------------------------------------------------------------
  License
---------------------------------------------------------------

	Pligg is an open source project and is licensed under the 
	Affero General Public License. Please read the full license at:
	http://www.affero.org/oagpl.html
