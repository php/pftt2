<?php
/**
 * Internationalization file for magic words.
 */

$magicWords = array();

$magicWords['en'] = array(
	'describe' => array( 0, 'describe' ),
	'listerrors' => array( 0, 'listerrors' ),
);
