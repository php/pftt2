jLoader.Initialize( "appleseed-login" );

jLoader.Appleseed_login = function ( ) { 

	// Add tabs to debug section
    $("#appleseed-login").tabs();
	
}