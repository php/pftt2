jLoader.Initialize( "login-join" );

jLoader.Login_join = function ( ) { 

	// Add form validation to the join form.
	$("#join").validate();
	
}
