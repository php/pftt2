jLoader.Initialize( "appleseed-debug" );

jLoader.Appleseed_debug = function ( ) { 

	$("#appleseed-debug").tabs();
	
}
