<?php
	/**
	 * Available Themes for phpPgAdmin
	 *
	 * $Id: 
	 */

	// List of themes
	
	$appThemes = array(
		'default' => 'Default',
		'cappuccino' => 'Cappuccino',
		'gotar' => 'Blue/Green'
	);
?>
