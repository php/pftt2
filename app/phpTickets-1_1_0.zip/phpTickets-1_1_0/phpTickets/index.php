<?php

require("config.inc.php");
require("mysql_fns.php");
require("tickets.inc.php");

// Let's set up session if data was posted.
if ($_SERVER['REQUEST_METHOD'] == "POST" || ($_SERVER['REQUEST_METHOD'] == "GET" and $_GET['login'] == "true")) {
    session_start();

    session_register("email");
    session_register("sesstime");
    session_register("email");
    session_register("user_level");

    $_SESSION['sesstime'] = mktime() + GetSetting('session_timeout');

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $account = $_POST['account'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $ticket = $_POST['ticket'];
    } else {
        $email = $_GET['email'];
        $ticket = $_GET['ticket'];
    }
}

if (isset($email) && isset($ticket) && strlen($email) > 6) {
    $result = $db->query($dbh,"SELECT email,id FROM tickets WHERE email='$email' and id='$ticket'");
    if ($db->numrows($result) > 0) {
        $row = $db->fetcharray($result);
        $_SESSION['user_level'] = "3";
    }

}

if (isset($account) && isset($password)) {
    $result = $db->query($dbh,"SELECT email,security FROM reps WHERE username='$account' and password='$password'");
    if ($db->numrows($result) > 0) {
        $row = $db->fetcharray($result);
            session_register("rep");
            $_SESSION['rep'] = $account;
            $email = $row[0];
            $_SESSION['user_level'] = $row[1];
    }
}

if ($_SESSION['user_level'] > "0") {
    $now = time();
    $res = $db->query($dbh,"INSERT INTO log VALUES (NULL,'".$_SERVER['REMOTE_ADDR']."','$account',$now)");
    $_SESSION['email'] = $email;
    header("Location: reload.php");
    exit;
}

// User wasn't successful logging in so
// let's send them the regular login page.

require("header.php");

// If user tried to log in, let them know they failed.
if (isset($_POST['account']) || ($_SERVER['REQUEST_METHOD'] == "GET" and $_GET['login'] == "true")) {
    print "<p><center>Could not log you in!</center></p>";
    session_destroy();
}

?>
<table align="center" border="0" cellpadding="2" cellspacing="2">
  <tr valign="middle">
    <td align="right"><a href="http://www.phptickets.org"><img src="phpTickets.jpg" border="0"></a></td>
    <td align="left">phpTickets - Open Source Ticket Management Software</td>
  </tr>
</table>
<form METHOD="POST" action="index.php" name="login">
<table border="1" align="center" cellspacing="0" cellpadding="0">
  <tr valign="top">
    <td class="boxtitle" align="center">phpTickets Administration Login</td>
<?php
if (GetSetting('guest_access') == "true") {
?>
    <td class="boxtitle" align="center">phpTickets Customer Login</td>
<?php
}
?>
  </tr>
  <tr>
    <td>
      <table width="300" border="0" cellpadding="2" cellspacing="1">
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td align=right width="100">Username:</td><td align=left width="200"><input type="text" name="account"></td></tr>
        <tr><td align=right>Password:</td><td align=left><input type="password" name="password"></td></tr>
        <tr><td align="center">&nbsp;</td><td><input type="submit" class="button" value="Login"></td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td colspan="2" align="center">Registered users may sign in here.</td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
      </table>
    </td>
<?php
if (GetSetting('guest_access') == "true") {
?>
    <td>
      <table width="300" border="0" cellpadding="2" cellspacing="1">
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td align=right width="100">Email:</td><td align=left width="200"><input type="text" name="email"></td></tr>
        <tr><td align=right>Ticket #:</td><td align=left><input type="text" name="ticket"></td></tr>
        <tr><td align="center">&nbsp;</td><td><input type="submit" class="button" value="View Tickets"></td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td colspan="2" align="center">Guests with open tickets may view them here.</td></tr>
        <tr><td colspan="2" align="center" class="normal">Enter any ticket number to view tickets.</td></tr>
      </table>
    </td>
<?php
}
?>
  </tr>
</table>
</form>
<script language="JavaScript">
   document.login.account.focus()
</script>
<?php
require("footer.php");
?>

