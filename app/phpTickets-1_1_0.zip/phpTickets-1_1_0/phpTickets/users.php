<?php

require("auth.php");
print "<body bgcolor=#FFFFFF>";

if (isset($_GET['remove']) && CheckSecurity("remove_users") == "true")    {
    if ($_GET['remove'] <> '1') {
        $res = $db->query($dbh,"SELECT security FROM `reps` where id='".$_GET['remove']."'");
        $res_row = (mysql_fetch_row($res));
        if ($_SESSION['user_level'] <= $res_row[0]) {
            $result = $db->query($dbh,"DELETE FROM `reps` WHERE id='".$_GET['remove']."'");
            if ($result) print "<center>User successfully removed!</center>";
        } else {
            print "<center>You do not not have proper authority to delete this user.</center>";
        }
    }
}   

if (isset($_POST['update']) && CheckSecurity("update_users") == "true")    {
    if ($_POST['update'] == "1") { $_POST['security'] = "1"; }
    if ($_SESSION['user_level'] <= $_POST['security']) {
        $result = $db->query($dbh,"UPDATE `reps` set name='".$_POST['name']."', email='".$_POST['email']."', username='".$_POST['username']."', password='".$_POST['password']."', security='".$_POST['security']."' WHERE id='".$_POST['update']."';");
        if ($result) print "<center>User successfully updated!</center>";
    } else {
        print "<center>You do not not have proper authority to set this security level.</center>";
    }
}

if (isset($_POST['add']) && CheckSecurity("add_users") == "true") {
    if ($_SESSION['user_level'] <= $_POST['security']) {
        $result = $db->query($dbh,"INSERT INTO `reps` VALUEs (NULL, '".$_POST['name']."', '".$_POST['email']."', '".$_POST['username']."', '".$_POST['password']."', '".$_POST['security']."');");
        if ($result) print "<center>User successfully added!</center>";
    } else {
        print "<center>You do not not have proper authority to set this security level.</center>";
    }
}

$result = $db->query($dbh,"SELECT * FROM `reps`");

?>
<h3 align="center"><br>phpTicket Users</h2><br>
<table width="600" border="1" cellspacing="0" cellpadding="6" align="center">
    <tr>
        <td>Name</td>
        <td>Email</td>
        <td>Username</td>
        <td>Security</td>
        <?php
        if (CheckSecurity("update_users") == "true" or CheckSecurity("remove_users") == "true") {
            print '<td colspan="2" align="center">Actions</td>';
        }
        ?>
    </tr>
    <?php
    for ($i = 0; $row = $db->fetcharray($result); $i++) {
        ?>
        <tr>
        <td valign="top"><?php echo $row[1]?></td>
        <td valign="top"><?php echo $row[2]?></td>
        <td valign="top"><?php echo $row[3]?></td>
        <td valign="top"><?php $row[5] == 1 ? print "Admin" : print "user"; ?></td>
        <?php
        if (CheckSecurity("update_users") == "true" or CheckSecurity("remove_users") == "true") {
            ?>
            <td valign="top">&nbsp;<?php if (CheckSecurity("update_users") == "true") print "<a href=\"users.php?edit=$row[0]\">Edit</a>"; ?></td>
            <td valign="top">&nbsp;<?php if (CheckSecurity("remove_users") == "true") print "<a href=\"users.php?remove=$row[0]\">Delete</a>"; ?></td>
            <?php
        }
        ?>
        </tr>
        <?php
    }
    ?>
</table>
<?php
$db->freeresult($result);
if (isset($_GET['edit']) && $_GET['edit'] <> "1")    {
    $result = $db->query($dbh,"SELECT * FROM `reps` WHERE id='".$_GET['edit']."'");
    $row = $db->fetcharray($result);
}
if (CheckSecurity("add_users") == "true" or (CheckSecurity("update_users") == "true" && isset($_GET['edit']))) {
?>
<form action="users.php" name="users" method="post" onsubmit="return validate()">
<?php
if (isset($_GET['edit']) && $_GET['edit'] <> "1") {
    print "<h3 align='center'>Edit User</h3>";
    print "<input type=\"hidden\" name=\"update\" value=\"$row[0]\">";
} else {
    print "<h3 align='center'>Add User</h3>";
    print "<input type=\"hidden\" name=\"add\" value=\"true\">";
}
?>
<table width="350" border="0" cellspacing="0" cellpadding="6" align="center">
<tr><td width="125"><strong>Name</strong></td><td width="225"><input type="text" size="25" name="name" value="<?php echo $row[1]?>"></td></tr>
<tr><td><strong>Email</strong></td><td><input type="text" size="30" name="email" value="<?php echo $row[2]?>"></td></tr>
<tr><td><strong>Username</strong></td><td><input type="text" size="25" name="username" value="<?php echo $row[3]?>"></td></tr>
<tr><td><strong>Password</strong></td><td><input type="password" size="25" name="password" value="<?php echo $row[4]?>"></td></tr>
<tr><td><strong>Password Again</strong></td><td><input type="password" size="25" name="password2" value="<?php echo $row[4]?>"></td></tr>
<tr><td><strong>Security</strong></td><td><select name="security"><option value="1" <?php if ($row[5] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($row[5] == "2") print "selected"?>>User</option></select></td></tr>
<tr><td align="right"><input type="submit" class="button" value="submit"></td><td align="left"><input type="reset" class="button" value="Reset"></td></tr>
</table>
</form>
<script language="JavaScript" type="text/javascript">
    function validate() {
        var frm = document.forms["users"];
        if(frm.password.value != frm.password2.value) {
            alert('Passwords do not match!');
            return false;
        } else {
            return true;
        }
    }
</script>

<?php
}

require("footer.php");

?>
