<?php

require("auth.php");

if (CheckSecurity("update_security") <> "true") {
    exit;
}

if (isset($_POST['update']))    {
        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['create_ticket']."' where zone='create_ticket';");
        if (!$result) print "<center>Error Updating Security for Create Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['reply_ticket']."' where zone='reply_ticket';");
        if (!$result) print "<center>Error Updating Security for Reply to Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['open_ticket']."' where zone='open_ticket';");
        if (!$result) print "<center>Error Updating Security for Open Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['close_ticket']."' where zone='close_ticket';");
        if (!$result) print "<center>Error Updating Security for Close Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['archive_ticket']."' where zone='archive_ticket';");
        if (!$result) print "<center>Error Updating Security for Archive Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['update_priority']."' where zone='update_priority';");
        if (!$result) print "<center>Error Updating Security for Update Priority</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['search_tickets']."' where zone='search_tickets';");
        if (!$result) print "<center>Error Updating Security for Search Tickets</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['add_users']."' where zone='add_users';");
        if (!$result) print "<center>Error Updating Security for Add Users</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['remove_users']."' where zone='remove_users';");
        if (!$result) print "<center>Error Updating Security for Remove Users</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['update_users']."' where zone='update_users';");
        if (!$result) print "<center>Error Updating Security for Update Users</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['add_categories']."' where zone='add_categories';");
        if (!$result) print "<center>Error Updating Security for Add Categories</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['remove_categories']."' where zone='remove_categories';");
        if (!$result) print "<center>Error Updating Security for Remove Categories</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['update_categories']."' where zone='update_categories';");
        if (!$result) print "<center>Error Updating Security for Update Categories</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['update_settings']."' where zone='update_settings';");
        if (!$result) print "<center>Error Updating Security for Update Settings</center>";

        $result = $db->query($dbh,"UPDATE security SET level='".$_POST['update_security']."' where zone='update_security';");
        if (!$result) print "<center>Error Updating Security for Update Security</center>";

        print "<center>Security Updated!</center>";
        print "<center>Please <a href=\"reload.php\">Click Here</a> to reload settings.</center>";

        ?>
        <SCRIPT LANGUAGE="JavaScript">
        top.document.location.href = "reload.php";
        </SCRIPT>
        <?php

}   

$result = $db->query($dbh,"SELECT * FROM `security`;");
while($row = mysql_fetch_array($result)) {
    $security[$row[1]] = $row[2];
}

if (CheckSecurity("update_security") == "true") {
?>
<h3 align="center"><br>phpTickets Security</h3><br>
<form action="security.php" name="sets" method="post">
<table width="400" border="0" cellspacing="0" cellpadding="6" align="center">
<input type="hidden" name="update" value="security">
<tr><td width="200"><strong>Create Tickets</strong></td><td width="200"><select name="create_ticket"><option value="1" <?php if ($security['create_ticket'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['create_ticket'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['create_ticket'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Reply to Tickets</strong></td><td><select name="reply_ticket"><option value="1" <?php if ($security['reply_ticket'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['reply_ticket'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['reply_ticket'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Open Tickets</strong></td><td><select name="open_ticket"><option value="1" <?php if ($security['open_ticket'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['open_ticket'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['open_ticket'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Close Tickets</strong></td><td><select name="close_ticket"><option value="1" <?php if ($security['close_ticket'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['close_ticket'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['close_ticket'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Archive Tickets</strong></td><td><select name="archive_ticket"><option value="1" <?php if ($security['archive_ticket'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['archive_ticket'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['archive_ticket'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Update Priority</strong></td><td><select name="update_priority"><option value="1" <?php if ($security['update_priority'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['update_priority'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['update_priority'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Search Tickets</strong></td><td><select name="search_tickets"><option value="1" <?php if ($security['search_tickets'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['search_tickets'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['search_tickets'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Add Users</strong></td><td><select name="add_users"><option value="1" <?php if ($security['add_users'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['add_users'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['add_users'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Remove Users</strong></td><td><select name="remove_users"><option value="1" <?php if ($security['remove_users'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['remove_users'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['remove_users'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Update Users</strong></td><td><select name="update_users"><option value="1" <?php if ($security['update_users'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['update_users'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['update_users'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Add POP Accounts</strong></td><td><select name="add_categories"><option value="1" <?php if ($security['add_categories'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['add_categories'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['add_categories'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Remove POP Accounts</strong></td><td><select name="remove_categories"><option value="1" <?php if ($security['remove_categories'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['remove_categories'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['remove_categories'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Update POP Accounts</strong></td><td><select name="update_categories"><option value="1" <?php if ($security['update_categories'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['update_categories'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['update_categories'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Update Settings</strong></td><td><select name="update_settings"><option value="1" <?php if ($security['update_settings'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['update_settings'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['update_settings'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td><strong>Update Security</strong></td><td><select name="update_security"><option value="1" <?php if ($security['update_security'] == "1") print "selected"?>>Admin</option><option value="2" <?php if ($security['update_security'] == "2") print "selected"?>>Users</option><option value="3" <?php if ($security['update_security'] == "3") print "selected"?>>Guests</option></select></td></tr>
<tr><td align="right"><input type="submit" class="button" value="Update Security"></td><td align="left"><input type="reset" class="button" value="Reset"></td></tr>
</table>
</form>
<?php
}
require("footer.php");
?>
