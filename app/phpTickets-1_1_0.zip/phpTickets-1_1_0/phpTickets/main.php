<?php

require("auth.php");
print "<body bgcolor=#FFFFFF>";

if (extension_loaded("imap")) GetEmails();
else echo "<div align=center>IMAP Module is not loaded so phpTickets cannot load new tickets from POP3 
accounts.</div>";

if (isset($_POST['a']) && isset($_POST['t'])) {
    if ($_POST['a'] == "manage") {
        if ($_POST['archive']) {
            foreach ($_POST['t'] as $id => $val) {
                $db->query($dbh,"update tickets set status='archive' where ID = ".$id.";");
            }
        } else if ($_POST['setpriority']) {
            foreach ($_POST['t'] as $id => $val) {
                $db->query($dbh,"update tickets set priority=".$_POST['newpriority']." WHERE ID = ".$id.";");
            }
        } else if ($_POST['close']) {
            foreach ($_POST['t'] as $id => $val) {
                ChangeStatus($id,"closed");
            }
        } else if ($_POST['open']) {
            foreach ($_POST['t'] as $id => $val) {
                ChangeStatus($id,"open");
            }
        }
    }
}

if (isset($_POST['status'])) {
    $stat = $_POST['status'];
} elseif (isset($_GET['status'])) {
    $stat = $_GET['status'];
} elseif ($_POST['search']) {
    $stat = "search";
} else {
    $stat = "open";
}

if ($stat == "search") {
    print '<h3 align="center">Search Results</h3>';
} elseif ($stat == 'closed') {
    print '<h3 align="center">Closed Tickets</h3>';
} elseif ($stat == 'open') {
    print '<h3 align="center">Open Tickets</h3>';
}

?>
    
<form action="main.php" method="POST">
<table width="98%" border="0" cellspacing=0 cellpadding=0 align="center" class="box">
<tr bgcolor="<?php echo GetSetting('ticket_bar_color')?>">
    <td class="boxtitle">&nbsp;</td>
    <td class="boxtitle">Subject</td>
    <td class="boxtitle">From</td>
    <td class="boxtitle">Category</td>
    <td class="boxtitle">Unanswered Msgs</td>
    <td class="boxtitle">Priority</td>
    <td class="boxtitle">Status</td>
</tr>

<?php

if ( isset($_POST['search'])) {
    $query = "select * from tickets where 0 ";
    if ($_POST['name']) {
        $query .= "or name like '%".$_POST['search']."%' ";
    }
    if ($_POST['email']) {
        $query .= "or email like '%".$_POST['search']."%' ";
    }
    if ($_POST['subject']) {
        $query .= "or subject like '%".$_POST['search']."%' ";
    }
    if ($_POST['message']) {
        $res = $db->query($dbh,"SELECT ticket FROM messages WHERE message LIKE '%".$_POST['search']."%'");
    if (mysql_num_rows($res) > 0) {
            while ($row = mysql_fetch_array($res)) {
                $ids .= "$row[0],";
            }
            $ids = rtrim($ids,',');
            $query .= "or ID IN ($ids)";
        }
    }
    $query .= ";";
    $tickets_res = $db->query($dbh,$query);
} else {

    if (!session_is_registered("rep")) {
        $tickets_res = $db->query($dbh,"select * from tickets where status = '".$stat."' and email='".$_SESSION['email']."';");
    } else {
        $tickets_res = $db->query($dbh,"select * from tickets where status = '".$stat."';");
    }
}

$tick_count = 0;

while ($tickets_row = mysql_fetch_array($tickets_res)) {
    $tickets[$tickets_row["ID"]] = new Ticket($tickets_row);
    $tick_count++;
}
    
$count = 0;
while ($count < $tick_count) {
    $highestscore = 0;
    foreach($tickets as $ticket) {
        if (((isset($lastscore)) ? ($ticket->score <= $lastscore) : (1 == 1)) and ($ticket->score >= $highestscore) and ($ticket->printed == false)) {
            $highestscore = $ticket->score;
            $next = $ticket->id;
        }
    }
    $lastscore = $highestscore;
    if ($tickets[$next]->priority == 1) {
        print '<tr bgcolor="#CAFFCA">';
        $pri = '<font color="green">Low</font>';
    }
    if ($tickets[$next]->priority == 2) {
        print '<tr bgcolor="F9FDCC">';
        $pri = 'Normal';
    }
    if ($tickets[$next]->priority == 3) {
        print '<tr bgcolor="#FBA3A3">';
        $pri = '<font color="Red">High</font>';
    }
    print '<td><input type="checkbox" class="whitechk" name="t['.$tickets[$next]->id.']"></td>';
    print '<td><a href="view.php?a=vticket&id='.$tickets[$next]->id.'">'.$tickets[$next]->subject.'</a></td>';
    print '<td>'.$tickets[$next]->name.'</td>';
    $cat_res = $db->query($dbh, "select * from categories where id = '".$tickets[$next]->cat."';");
    $cat_row = mysql_fetch_array($cat_res);
    print '<td>'.$cat_row["name"].'</td>';
    print '<td>'.$tickets[$next]->unanswered.'</tD>';
    print '<td>'.$pri.'</td>';
    print '<td>'.$tickets[$next]->status.'</td>';
    print '</tr>';

    $tickets[$next]->printed = true;
    $count++;
}

print "</table><center><br><table width=90% border=0 cellspacing=0 cellpadding=0><tr><td align=center>&nbsp;";
print '<input type="hidden" name="a" value="manage">';
if (CheckSecurity("archive_ticket") == "true") {
    print '<input type="submit" class="button" name="archive" value="Archive Selected">';
}
print "</td><td align=center>&nbsp;";
if ($stat == 'closed' or $stat == 'search') {
    if (CheckSecurity("open_ticket") == "true") {
        print '<input type="submit" class="button" name="open" value="Open Selected">';
    }
}
if ($stat == "search") {
    print "</td><td align=center>&nbsp;";
}
if ($stat == 'open' or $stat == 'search') {
    if (CheckSecurity("close_ticket") == "true") {
        print '<input type="submit" class="button" name="close" value="Close Selected">';
    }
}
print "</td><td align=center>&nbsp;";
print '<input type="submit" class="button" name="refresh" value="Refresh Page">';
print "</td><td align=center>&nbsp;";
if (CheckSecurity("update_priority") == "true") {
    print '<input type="submit" class="button" name="setpriority" value="Change Selected Priority:">&nbsp;';
    print '<select name="newpriority"><option value=1>Low</option><option value=2>Normal</option><option value=3>High</option></select>';
}
print "</td></tr></table>";
print '<input type="hidden" name="status" value="'.$stat.'">';
print '</form>';

require("footer.php");

?>

