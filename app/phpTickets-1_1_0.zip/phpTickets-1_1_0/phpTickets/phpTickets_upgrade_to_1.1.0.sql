--
-- SQL Database Upgrade Script for phpTickets v1.1.0
-- 
-- 
-- Database: `phptickets`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `security`
-- 

INSERT INTO `settings` VALUES (NULL, 'session_timeout', '28800');
INSERT INTO `settings` VALUES (NULL, 'email_message', 'ticket_email.txt');

--
-- Table structure for table `log`
--

CREATE TABLE log (
  id int(7) NOT NULL auto_increment,
  ip varchar(15) default NULL,
  user varchar(15) default NULL,
  timestamp int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

