<?php

require("auth.php");
print "<body bgcolor=#FFFFFF>";

if (isset($_GET['remove']) && CheckSecurity("remove_categories") == "true") {
    $result = $db->query($dbh,"DELETE FROM `categories` WHERE id='".$_GET['remove']."'");
    if ($result) print "<center>POP account successfully removed!</center>";
}

if (isset($_POST['update']) && CheckSecurity("update_categories") == "true")    {
    $result = $db->query($dbh,"UPDATE `categories` set name='".$_POST['name']."', pophost='".$_POST['pophost']."', popuser='".$_POST['popuser']."', poppass='".$_POST['poppass']."', replyto='".$_POST['replyto']."' WHERE id='".$_POST['update']."';");
    if ($result) print "<center>POP account successfully updated!</center>";
}

if (isset($_POST['add']) && CheckSecurity("add_categories") == "true") {
    $result = $db->query($dbh,"INSERT INTO `categories` VALUES (NULL,'".$_POST['name']."', '".$_POST['pophost']."', '".$_POST['popuser']."', '".$_POST['poppass']."', '".$_POST['replyto']."');");
    if ($result) print "<center>POP account successfully added!</center>";
}

$result = $db->query($dbh,"SELECT * FROM `categories`");

?>
<h3 align="center"><br>Categories / POP Accounts</h2><br>
<table width="600" border="1" cellspacing="0" cellpadding="6" align="center">
<tr>
    <td>Name</td>
    <td>Host</td>
    <td>Username</td>
    <td>Password</td>
    <td>Reply Email</td>
    <?php
    if (CheckSecurity("update_categories") == "true" or CheckSecurity("remove_categories") == "true") {
        print '<td colspan="2" align="center"><strong>Actions</strong></td>';
    }
    ?>
</tr>
<?php
for ($i = 0; $row = $db->fetcharray($result); $i++) {
?>
    <tr>
        <td valign="top"><?php echo $row[1]?></td>
        <td valign="top"><?php echo $row[2]?></td>
        <td valign="top"><?php echo $row[3]?></td>
        <td valign="top"><?php echo $row[4]?></td>
        <td valign="top"><?php echo $row[5]?></td>
        <?php
        if (CheckSecurity("update_categories") == "true" or CheckSecurity("remove_categories") == "true") {
            ?>
            <td valign="top">&nbsp;<?php if (CheckSecurity("update_categories") == "true") print "<a href=\"pops.php?edit=$row[0]\">Edit</a>"; ?></td>
            <td valign="top">&nbsp;<?php if (CheckSecurity("remove_categories") == "true") print "<a href=\"pops.php?remove=$row[0]\">Delete</a>"; ?></td>
            <?php
        }
        ?>
    </tr>
<?php
}
$db->freeresult($result);

if (isset($_GET['edit']))    {
    $result = $db->query($dbh,"SELECT * FROM `categories` WHERE id='".$_GET['edit']."'");
    $row = $db->fetcharray($result);
}
?>
</table>
<?php
if (CheckSecurity("add_categories") == "true" or (CheckSecurity("update_categories") == "true" && isset($_GET['edit']))) {
?>
<form action="pops.php" method="post">
<?php
if (isset($_GET['edit'])) {
    print "<h3 align='center'>Edit POP Account</h3>";
    print "<input type=\"hidden\" name=\"update\" value=\"$row[0]\">";
} else {
    print "<h3 align='center'>Add POP Account</h3>";
    print "<input type=\"hidden\" name=\"add\" value=\"true\">";
}
?>
<table width="350" border="0" cellspacing="0" cellpadding="6" align="center">
<tr><td>Category Name</td><td width="225"><input type="text" size="25" name="name" value="<?php echo $row[1]?>"></td></tr>
<tr><td>POP Host</td><td><input type="text" size="30" name="pophost" value="<?php echo $row[2]?>"></td></tr>
<tr><td>POP User</td><td><input type="text" size="25" name="popuser" value="<?php echo $row[3]?>"></td></tr>
<tr><td>POP Password</td><td><input type="text" size="25" name="poppass" value="<?php echo $row[4]?>"></td></tr>
<tr><td>Reply To Address</td><td><input type="text" size="30" name="replyto" value="<?php echo $row[5]?>"></td></tr>
<tr><td align="right"><input type="submit" class="button" value="submit"></td><td align="left"><input type="reset" class="button" value="Reset"></td></tr>
</table>
</form>

<?php
}

require("footer.php");

?>
