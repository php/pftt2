First of all, let me say that I haven't had
the time to dedicate to this project as I would
like. I have made some major visual enhancements
to this verions. I hope you all like it. The script
to upgrade the database may not work flawlessly,
but hpefully you can manage. If you have any
questions, feel free to post to the mailing list
at phptickets@phptickets.org.

If anyone has any suggestions or feature requests,
feel free to send them in. Also, one more major
enhancement I would like to add is file attachments.
But I sure as most of you know it wil be quite a
task to do this "properly".

Enjoy!

Jeff Jarchow

