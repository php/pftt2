<?php
if (isset($dbh)) {
    $db->close($dbh);
}
?>
</body>
</html>
