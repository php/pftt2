<?php

require("auth.php");

if (CheckSecurity("update_settings") <> "true") {
    exit;
}

if ($_POST['update'] == "settings") {
        $result = $db->query($dbh,"UPDATE settings SET value='".$_POST['trouble_email']."' where name='trouble_email';");
        if (!$result) print "<center>Error Updating Trouble Email</center>";

        $result = $db->query($dbh,"UPDATE settings SET value='".$_POST['org_name']."' where name='org_name';");
        if (!$result) print "<center>Error Updating Organization Name</center>";

        $result = $db->query($dbh,"UPDATE settings SET value='".$_POST['email_message']."' where name='email_message';");
        if (!$result) print "<center>Error Updating Email Message</center>";

        ($_POST['send_email_create'] == "on") ? $value = "true" : $value = "false";
        $result = $db->query($dbh,"UPDATE settings SET value='$value' where name='send_email_create';");
        if (!$result) print "<center>Error Updating Send Email Upon Create</center>";

        ($_POST['send_email_reply'] == "on") ? $value = "true" : $value = "false";
        $result = $db->query($dbh,"UPDATE settings SET value='$value' where name='send_email_reply';");
        if (!$result) print "<center>Error Updating Send Email Upon Reply</center>";

        ($_POST['guest_access'] == "on") ? $value = "true" : $value = "false";
        $result = $db->query($dbh,"UPDATE settings SET value='$value' where name='guest_access';");
        if (!$result) print "<center>Error Updating Guest Access</center>";

        $result = $db->query($dbh,"UPDATE settings SET value='".$_POST['session_timeout']."' where name='session_timeout';");
        if (!$result) print "<center>Error Updating SessionTimeout</center><br>";

        print "<center>Settings Updated!</center>\n\n";

        print "<center>Please <a href=\"reload.php\">Click Here</a> to reload settings.</center>";

	?>
	<SCRIPT LANGUAGE="JavaScript">
	top.document.location.href = "reload.php";
	</SCRIPT>
	<?php

}   

$result = $db->query($dbh,"SELECT * FROM `settings`;");
while($row = mysql_fetch_array($result)) {
    $settings[$row[1]] = $row[2];
}
if (CheckSecurity("update_settings") == "true") {
?>
<h3 align="center"><br>phpTickets Settings</h3><br>
<form action="settings.php" name="sets" method="post">
<table width="400" border="0" cellspacing="0" cellpadding="6" align="center">
<input type="hidden" name="update" value="settings">
<tr><td width="200">Version</td><td width="200"><strong><?php echo GetSetting("version")?></strong></td></tr>
<tr><td><strong>Trouble Email</td><td><input type="text" size="30" name="trouble_email" value="<?php echo $settings['trouble_email']?>"></td></tr>
<tr><td>Organization Name</td><td><input type="text" size="30" name="org_name" value="<?php echo $settings['org_name']?>"></td></tr>
<tr><td>Upon Ticket Creation</td><td><input type="checkbox" name="send_email_create" <?php if ($settings['send_email_create'] == "true") print "checked"?>> Send Email to Customer</td></tr>
<tr><td>Upon Ticket Reply</td><td><input type="checkbox" name="send_email_reply" <?php if ($settings['send_email_reply'] == "true") print "checked"?>> Send Email to Customer</td></tr>
<tr><td>Email Message</td><td><input type="text" name="email_message"  value="<?php echo $settings['email_message']?>"></td></tr>
<tr><td>Allow Guest Access</td><td><input type="checkbox" name="guest_access" <?php if ($settings['guest_access'] == "true") print "checked"?>> (Define security on security page)</td></tr>
<tr><td>Session Timeout (sec.)</td><td><input type="text" size="12" name="session_timeout" value="<?php echo $settings['session_timeout']?>"></td></tr>
<tr><td align="right"><input type="submit" class="button" value="Update Settings"></td><td align="left"><input type="reset" class="button" value="Reset"></td></tr>
</table>
</form>
<?php
}

require("footer.php");

?>
