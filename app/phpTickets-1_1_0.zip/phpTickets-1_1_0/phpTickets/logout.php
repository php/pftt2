<?php
    session_start();
    session_unregister("rep");
    session_unregister("email");
    session_unregister("sesstime");
    session_unregister("user_level");
    session_unset();
    session_destroy();
    header ("Location: index.php");
    exit;
?>

