<?
require_once("attachments.inc.php");
$host="{mail.phptickets.org/pop3:110/notls}"; // pop3host
$login="help@qcihost.net"; //pop3 login
$password="josie24"; //pop3 password
$savedirpath="attachments" ; // attachement will save in same directory where scripts run othrwise give abs path
$jk=new readattachment(); // Creating instance of class####
$jk->getdata($host,$login,$password,$savedirpath); // calling member function

?>
