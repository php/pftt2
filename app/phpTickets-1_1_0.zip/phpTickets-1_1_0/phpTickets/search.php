<?php

require("auth.php");
print "<body bgcolor=#FFFFFF>";

?>
    <script language="JavaScript">
    <!--
    function validate_form ( )
    {
        valid = true;
        if ( document.search.search.value == "" )
        {
            alert ( "Search field must contain search criteria." );
            valid = false;
        }
        return valid;
    }
    //-->
    </script>
    <h3 align="center">Search Tickets</h3><br>
    <form name="search" action="main.php" onSubmit="return validate_form ( );" method="post">
    <table width="250" border="0" cellspacing="0" cellpadding="6" align="center">
    <tr><td align="right" width="125"><strong>Search For</strong></td><td width="125"><input type="text" name="search"></td></tr>
    <tr><td colspan="2" align="center"><strong>Search Fields</strong></td></tr>
    <tr><td align="left"><strong>Email Address</strong></td><td><input type="checkbox" class="whitechk" name="email" checked></td></tr>
    <tr><td align="left"><strong>Name</strong></td><td><input type="checkbox" class="whitechk" name="name" checked></td></tr>
    <tr><td align="left"><strong>Subject</strong></td><td><input type="checkbox" class="whitechk" name="subject" checked></td></tr>
    <tr><td align="left"><strong>Message</strong></td><td><input type="checkbox" class="whitechk" name="message" checked></td></tr>
<?php
/* Work in Progress
    <tr><td align="left"><strong>Open Status</strong></td><td><input type="checkbox" class="whitechk" name="open" checked></td></tr>
    <tr><td align="left"><strong>Closed Status</strong></td><td><input type="checkbox" class="whitechk" name="close" checked></td></tr>
    <tr><td align="left"><strong>Archive Status</strong></td><td><input type="checkbox" class="whitechk" name="archive"></td></tr>
*/
?>
    <tr><td colspan="2" align="center"><input type="submit" class="button" value="Submit"> <input type="reset" class="button" value="Reset"></td></tr>
    </table>
    </form>
<?php
require("footer.php");
?>
