<?php

class Ticket {
    var $id;
    var $subject;
    var $name;
    var $email;
    var $phone;
    var $status;
    var $rep;
    var $cat;
    var $priority;
    var $in;
    var $out;
    var $unanswered;
    var $score;
    var $printed;
    var $age;

    function Ticket ($row) {
        global $pri_value, $db_host, $db_user, $db_pass, $db_db;

        $db = new db();
        $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

        $this->id = $row["ID"];
        $this->subject = $row["subject"];
        $this->name = $row["name"];
        $this->email = $row["email"];
        $this->phone = $row["phone"];
        $this->status = $row["status"];
        $this->rep = $row["rep"];
        $this->cat = $row["cat"];
        $this->priority = $row["priority"];
        $this->in = 0;
        $this->out = 0;
        $this->printed = false;

        $messages_res = $db->query($dbh,"select * from messages where ticket = ".$this->id." order by timestamp ASC;");
        while ($messages_row = mysql_fetch_array($messages_res)) {
            $this->in = 0;
            $answer_res = $db->query($dbh,"select * from answers where reference = ".$messages_row["ID"].";");
            $this->out = $this->out + mysql_num_rows($answer_res);
            if (mysql_num_rows($answer_res) == 0) {
                if (!isset($this->age))
                    $this->age = time() - $messages_row["timestamp"];
                $this->unanswered++;
            }
        }

        //The score determines the priority in the list. High score = first. Could need tweaking here...
        if ($this->unanswered == "") {
            $this->unanswered = 0;
            $this->score = $this->priority;
        } else {
            $this->score = (($this->priority * 400000) + $this->age);
        }
    }
}


function GetEmails() {
    global $trouble_email, $db_host, $db_user, $db_pass, $db_db;

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

    /* Find out which pop accounts (categories) we have to check */
    $cat_res = $db->query($dbh,"select * from categories;");

    /* Check each pop accounts / categories */
    while ($cat_row = mysql_fetch_array($cat_res)) {
        $mbox = imap_open("{".$cat_row["pophost"]."/pop3:110/notls}INBOX",$cat_row["popuser"],$cat_row["poppass"])
		or print ("Error retrieving new mail from ".$cat_row["pophost"]."<br>\n");
        next;         
        $curmsg = 1;
        if (imap_num_msg($mbox) <> 0) print "Retrieving new messages.<br>";
        while ($curmsg <= imap_num_msg($mbox)) {
            $body = get_part($mbox, $curmsg, "TEXT/PLAIN");
            if ($body == "")
                $body = get_part($mbox, $curmsg, "TEXT/HTML");
            $body=eregi_replace("-----Original.*","",$body); // filters out outlook's quotes from replies
            if ($body == "") { /* We can't do anything with this email, leave it there */
                print "Error: Message could not be parsed. I left it in the mailbox.<br>";
                continue;
            }
            $head = imap_headerinfo($mbox, $curmsg, 800, 800);
            // TODO:  Name and Email address should be properly parsed here.
            $email = $head->reply_toaddress;
            $email=eregi_replace(".*<","",$email); // pl - quick hack to parse name, email
            $email=eregi_replace(">.*","",$email); // pl - quick hack contd.
            $name = $head->fromaddress;
            $name=eregi_replace(" <.*","",$name); // pl - quick hack contd.
            $subject = $head->fetchsubject;
            print "Subject: $subject<br>";

            /* Check the subject for ticket number */
            if (!ereg ("[[][#][0-9]{6}[]]", $head->fetchsubject)) {
                /* Seems like a new ticket, create it first */
                print "Creating a new ticket.<br>";
                $ticket_id = CreateTicket($subject, $name, $email, $cat_row["id"], "", "2", $body);
                if ($ticket_id == false) {
                    /* We had troubles creating the ticket. Forward the problematic email to a real human  */
                    print "Warning: CreateTicket failed! Message forwarded to $trouble_email <br>";
                    mail ($trouble_email, "{TROUBLE} $subject", "[ERROR: CreateTicket failed]\n".$body, "From: $name\nReply-To: $email");
                    imap_delete($mbox, $curmsg);
                    $curmsg++;
                    continue;
                }
            } else {
                /* Seems like a followup of an existing ticket, extract ticket_id from subject */
                $ticket_id = substr(strstr($head->fetchsubject, "[#"), 2, 6);
                print "Follow up to ticket #$ticket_id<br>"; 
            }

            if (!PostMessage($ticket_id, $body)) {
                /* Could not post the ticket, forward the problematic email to a real human */
                print "Warning: PostMessage failed! Message forwarded to $trouble_email <bR>";
                mail ($trouble_email, "{TROUBLE} $subject", "[ERROR: PostMessage failed]\n".$body, "From: $name\nReply-To: $email");
            }

            imap_delete($mbox, $curmsg);
            $curmsg++;
        }

        imap_expunge($mbox);
        imap_close($mbox);
    }
}


/* Nice code from cleong@organic.com */
function get_mime_type(&$structure) { 
    $primary_mime_type = array("TEXT", "MULTIPART", "MESSAGE", "APPLICATION", "AUDIO", "IMAGE", "VIDEO", "OTHER"); 
    
    if($structure->subtype) { 
        return $primary_mime_type[(int) $structure->type] . '/' . $structure->subtype; 
    } 
    return "TEXT/PLAIN"; 
} 

function get_part($stream, $msg_number, $mime_type, $structure = false, $part_number = false) { 
    if(!$structure) { 
        $structure = imap_fetchstructure($stream, $msg_number); 
    } 
    if($structure) { 
        if($mime_type == get_mime_type($structure)) { 
            if(!$part_number) { 
                $part_number = "1"; 
            } 
            $text = imap_fetchbody($stream, $msg_number, $part_number); 
            if($structure->encoding == 3) { 
                return imap_base64($text); 
            } else if($structure->encoding == 4) { 
                return imap_qprint($text); 
            } else { 
                return $text; 
            } 
        } 
        if($structure->type == 1) /* multipart */ { 
            while(list($index, $sub_structure) = each($structure->parts)) { 
                if($part_number) { 
                    $prefix = $part_number . '.'; 
                } 
                $data = get_part($stream, $msg_number, $mime_type, $sub_structure, $prefix . ($index + 1)); 
                if($data) { 
                    return $data; 
                } 
            } 
        } 
    } 
    return false; 
} 

function CreateTicket($subject, $name, $email, $cat, $phone, $pri=2, $message) {
    global $db_host, $db_user, $db_pass, $db_db;

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

    if ($subject == "")
        $subject = "[No Subject]";

    /* Generate random ticket_id */
    do {
        mt_srand ((double) microtime() * 1000000);
        $ID =  mt_rand(0,9) . mt_rand(0,9) . mt_rand(0,9) . mt_rand(0,9) . mt_rand(0,9) . mt_rand(0,9);
    } while(ValidID($ID) == false);

    /* Insert the ticket */
    $db->query($dbh, "insert into tickets (subject, name, email, cat, phone, status, ID, priority) VALUES ('".addslashes($subject)."', '$name', '$email', '$cat', '$phone', 'open', '$ID', $pri);");
    if (mysql_error($dbh)) {
        return false;
    }

    if (GetSetting('send_email_create') == "true") {
        $cat_res = $db->query($dbh,"select * from categories where id = ".$cat.";");
        $cat_row = mysql_fetch_array($cat_res);
        $from = $cat_row["replyto"];
        if ($from == "") {
            $from = GetSetting("trouble_email");
        }
        if (file_exists(GetSetting("email_message"))) {
            $file = file_get_contents(GetSetting("email_message"));
	}
        $file = str_replace("<<ticket>>",$ID,$file);
        $file = str_replace("<<email>>",$email,$file);
        $buffer = nl2br($message);
        $buffer = str_replace("\'", "'", $buffer);
        $buffer = str_replace('\"', '"', $buffer);
 
        if (Send_Email($email, $from, "[#".$ID."] ".$subject, $file."<br><br>--------Original Message--------<br>".$buffer)) {
            echo "Creation email sent.<br>\n";
        } else {
            echo "Creation email failed.<br>\n";
        }
    }

    /* Succeeded */
    return $ID;
}

function PostMessage($ticket, $message) {
    global $db_host, $db_user, $db_pass, $db_db;
    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

    $now = time();
    $res = $db->query($dbh,"select * from tickets where ID = $ticket;");
    if (mysql_error($dbh)) {
        print mysql_error($dbh) . "<br>";
        return false;
    }

    if (mysql_num_rows($res) == 0) {
        print "unknown ticket!<br>";
        return false;
    }
    
    /* Make sure the ticket is open */
    $db->query($dbh, "update tickets set status = 'open' where ID = $ticket;");

    $db->query($dbh, "insert into messages (ticket, message, timestamp) VALUES($ticket, '".addslashes($message)."', $now);");
    if (mysql_error($dbh)) {
        print mysql_error($dbh) . "<br>";
        return false;
    }

    return mysql_insert_id($dbh);
}

function PostAnswer($message, $rep, $reference) {
    global $dbh, $db_host, $db_user, $db_pass, $db_db;
    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);


    $now = time();

    $msg_res = $db->query($dbh,"select ticket,message from messages where ID = $reference;");
    $msg_row = mysql_fetch_array($msg_res);
    $ticket = $msg_row["ticket"];

    $res = $db->query($dbh,"select * from tickets where ID = $ticket;");
    if (mysql_error($dbh)) {
        return false;
    }

    if (mysql_num_rows($res) == 0) {
        return false;
    }

    $db->query($dbh,"insert into answers (ticket, message, timestamp, rep, reference) VALUES('$ticket', '$message', '$now', '$rep', '$reference');");

    if (mysql_error($dbh)) {
        return false;
    }
    
    $ticket_row = mysql_fetch_array($res);

    $message = str_replace("\r", "\n", $message);
    $message = str_replace("\n\n", "\n", $message);
    if (GetSetting('send_email_reply') == "true") {
        $cat_res = $db->query($dbh,"select * from categories where id = ".$ticket_row['cat'].";");
        $cat_row = mysql_fetch_array($cat_res);
        $from = $cat_row["replyto"];
        if ($from == "") {
            $from = GetSetting("trouble_email");
        }


        $ans_res = $db->query($dbh,"select message from answers where ticket = $ticket;");
        if (mysql_error($dbh)) {
            return false;
        }
        $buffer = "-------- Original Message --------<br>br>\n".$msg_row["message"];
        while ($ans_row = mysql_fetch_array($ans_res)) {
            $buffer = $ans_row[0] ."<br><br>\n-------- Next Response --------<br><br>\n". $buffer;
        }

        $buffer = nl2br($buffer);
        $buffer = str_replace("\'", "'", $buffer);
        $buffer = str_replace('\"', '"', $buffer);

        if (Send_Email($ticket_row["email"], $from,"[#".$ticket_row["ID"]."] ".$ticket_row["subject"], $message."<br><br>\n----<br>\n".GetSetting('org_name')."<br><br>-------- Message History --------<br>".$buffer)) {
            echo "<center>Reply email sent.</center><br>\n";
        } else {
            echo "<center>Reply email failed.</center><br>\n";
        }
    }
    return mysql_insert_id($dbh);
}

function ChangeStatus($ticket,$stat) {
    global $db,$dbh;

    $db->query($dbh,"update tickets set status = '".$stat."' where ID = '".$ticket."';");

    return; 
}

function ValidID($ID) {
    global $db_host, $db_user, $db_pass, $db_db;

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

    $res = $db->query($dbh,"SELECT ID FROM tickets where ID = $ID;")
        or die (mysql_error($dbh));

    if (mysql_num_rows($res) != 0)
        return false;

    return true;
}

function CheckSecurity($zone) {
    /*
        Subroutine to check security.
        Returns results as follows

        return <= 1 is admin
        return <= 2 other registered users
        return <= 3 guests

    */

    global $db_host, $db_user, $db_pass, $db_db;

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

    $res = $db->query($dbh,"SELECT level from security where zone='".$zone."';") or die (mysql_error($dbh));

    if ($db->numrows($res) > 0) {
        $row = $db->fetcharray($res);
        $sec_level = $row['level'];
    } else {
        return false;
    }

    if ($_SESSION['user_level'] <= $sec_level) {
        return true;
    } else {
        return false;
    }
}

function GetSetting($setting) {
    // Subroutine used to get setting from setting table
    global $db_host, $db_user, $db_pass, $db_db;

    $db = new db();
    $dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);
    $result = $db->query($dbh, "select value from settings where name='".$setting."';");
    $row = $db->fetcharray($result);
    return $row['value'];
}

function Send_Email ($to,$from,$subject,$message) {
    // Prepare headers for HTML EMail Message
    $headers = "From: " . $from . " <" . $from . ">\r\n";
    $headers .= "Return-Path: " . $from . " <" . $from . ">\r\n";
    $headers .= "Reply-To: " . $from . " <" . $from . ">\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\r\n";

    // Send Message
    return mail($to,$subject,$message,$headers);
}

?>
