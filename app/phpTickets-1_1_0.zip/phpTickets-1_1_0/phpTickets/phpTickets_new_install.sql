GRANT select,insert,update,delete ON phpTickets.* TO phpTickets@localhost IDENTIFIED BY 'password';

--
-- Table structure for table `answers`
--

CREATE TABLE answers (
  ID int(7) NOT NULL auto_increment,
  ticket varchar(20) default NULL,
  message text,
  timestamp int(10) NOT NULL default '0',
  rep int(5) NOT NULL default '0',
  reference int(7) default NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

--
-- Table structure for table `categories`
--

CREATE TABLE categories (
  id int(5) NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  pophost varchar(200) NOT NULL default '',
  popuser varchar(200) NOT NULL default '',
  poppass varchar(200) NOT NULL default '',
  replyto varchar(200) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `categories`
--


INSERT INTO categories VALUES (1,'Test Account','mail.test.org','help@test.org','pass123','help@test.org');

--
-- Table structure for table `log`
--

CREATE TABLE log (
  id int(7) NOT NULL auto_increment,
  ip varchar(15) default NULL,
  user varchar(15) default NULL,
  timestamp int(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Table structure for table `messages`
--

CREATE TABLE messages (
  ID int(7) NOT NULL auto_increment,
  ticket varchar(20) default NULL,
  message text,
  timestamp int(10) NOT NULL default '0',
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

--
-- Table structure for table `reps`
--

CREATE TABLE reps (
  ID int(5) NOT NULL auto_increment,
  name varchar(255) default NULL,
  email varchar(255) default NULL,
  username varchar(50) NOT NULL default '',
  password varchar(50) default NULL,
  security enum('1','2') NOT NULL default '2',
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

--
-- Dumping data for table `reps`
--


INSERT INTO reps VALUES (1,'Admin','your_email@yourhost.com','admin','password','1');

--
-- Table structure for table `security`
--

CREATE TABLE security (
  id smallint(6) NOT NULL auto_increment,
  zone varchar(25) NOT NULL default '',
  level enum('1','2','3') NOT NULL default '1',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `security`
--


INSERT INTO security VALUES (1,'create_ticket','3');
INSERT INTO security VALUES (2,'reply_ticket','2');
INSERT INTO security VALUES (3,'open_ticket','2');
INSERT INTO security VALUES (4,'close_ticket','3');
INSERT INTO security VALUES (5,'archive_ticket','2');
INSERT INTO security VALUES (6,'update_priority','2');
INSERT INTO security VALUES (7,'search_tickets','3');
INSERT INTO security VALUES (8,'add_users','2');
INSERT INTO security VALUES (9,'remove_users','2');
INSERT INTO security VALUES (10,'update_users','2');
INSERT INTO security VALUES (11,'add_categories','1');
INSERT INTO security VALUES (12,'remove_categories','1');
INSERT INTO security VALUES (13,'update_categories','1');
INSERT INTO security VALUES (14,'update_settings','1');
INSERT INTO security VALUES (15,'update_security','1');

--
-- Table structure for table `settings`
--

CREATE TABLE settings (
  id smallint(6) NOT NULL auto_increment,
  name varchar(255) default NULL,
  value varchar(255) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `settings`
--


INSERT INTO settings VALUES (1,'version','1.1.0');
INSERT INTO settings VALUES (2,'trouble_email','admin@testorg');
INSERT INTO settings VALUES (3,'org_name','My Org');
INSERT INTO settings VALUES (4,'send_email_create','true');
INSERT INTO settings VALUES (5,'send_email_reply','true');
INSERT INTO settings VALUES (6,'guest_access','true');
INSERT INTO settings VALUES (17,'session_timeout','28800');
INSERT INTO settings VALUES (18,'email_message','ticket_email.txt');

--
-- Table structure for table `tickets`
--

CREATE TABLE tickets (
  subject text,
  name text,
  email text,
  phone text,
  status enum('open','closed','archive') NOT NULL default 'open',
  rate int(2) default NULL,
  rep int(5) default NULL,
  ID int(6) NOT NULL default '0',
  cat int(5) NOT NULL default '0',
  priority tinyint(1) NOT NULL default '2',
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

