<html>
<head>
<title><?=GetSetting('org_name')?> Trouble Ticket System</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>
<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0">
