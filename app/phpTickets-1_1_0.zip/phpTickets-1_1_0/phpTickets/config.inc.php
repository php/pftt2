<?php
// Default Database Info for Project
$db_host = "localhost";
$db_user = "phpTickets";
$db_pass = "password";
$db_db   = "phpTickets";
?>
