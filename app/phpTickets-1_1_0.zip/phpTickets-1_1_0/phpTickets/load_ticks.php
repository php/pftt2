<?

// Bring in all necessary include files
require("mysql_fns.php");
require("config.inc.php");
require("tickets.inc.php");

// Establish initial connection to database
$db = new db();
$dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

if (extension_loaded("imap")) GetEmails();
else echo "<div align=center>IMAP Module is not loaded so phpTickets cannot load new tickets from POP3 accounts.</div>";

$db->close($dbh);
?>
