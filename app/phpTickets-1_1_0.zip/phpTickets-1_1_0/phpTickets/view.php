<?php
require("auth.php");
print "<body bgcolor=#FFFFFF>";

if ($_POST['a'] == "panswer") {
    $msg_res = mysql_query("select ticket from messages where ID = '".$_POST['id']."'");
    $msg_row = mysql_fetch_array($msg_res);
    if ($_POST['message'] <> "") {
        $rep = session_is_registered("rep") ? $_SESSION['rep'] : $_SESSION['email'];
        if (PostAnswer($_POST['message'], $rep, $_POST['id'])) {
            if ($_POST['close']) {
                ChangeStatus($msg_row['ticket'],"closed");
            }
            if ($_POST['open']) {
                ChangeStatus($msg_row['ticket'],"open");
            }
            print "<center>Reply Posted Successfully!</center>";
            ViewTicket($msg_row["ticket"]);
        } else {
            print "<center>Error Posting Reply!</center>";
            ViewTicket($msg_row["ticket"]);
        }
    } else {
        print "<center>Your post did not contain any reply message!</center>";
        ViewTicket($msg_row["ticket"]);
    }
} else {
    ViewTicket($_GET['id']);
}

function ViewTicket($id) {
    global $rep,$guests_can_reply,$guests_can_open,$guests_can_close;
    $ticket_res = mysql_query("select * from tickets where ID = $id;");
    $ticket_row = mysql_fetch_array($ticket_res);
    $cat_res = mysql_query("select * from categories where id = ".$ticket_row["cat"].";");
    $cat_row = mysql_fetch_array($cat_res);
    if ($ticket_row["priority"] == 1) {
        $pri = '<font color="green">Low</font>';
    } else if ($ticket_row["priority"] == 2) {
        $pri = '<font color="#000000">Normal</font>';
    } else if ($ticket_row["priority"] == 3) {
        $pri = '<font color="Red">High</font>';
    }
    ?>
    <h3 align="center">View ticket</h3>
    <div align="center"><a href="main.php?status=<?php echo $ticket_row["status"]?>">Back to main</a></div><br>
    <table border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td>
          <table class="box" align="center" cellspacing="0" cellpadding="0" width="500" border=0>
            <tr>
              <td class="boxtitle" align="center" width="500" colspan="4">Ticket Id: <?php print $id;?></td>
            </tr>
            <tr>
              <td>
                <table class="box" align="center" cellspacing="0" cellpadding="4" width="100%" border=0>
                  <tr>
                    <td align="left" width="75">Name:</td>
                      <td align="left" width="150"><?php print $ticket_row["name"]; ?></td>
                      <td align="left" width="75">Status:</td>
                      <td align="left" width="150"><?php print $ticket_row["status"]; ?></td>
                    </tr>
                    <tr>
                      <td align="left">Phone:</td>
                      <td align="left"><?php print $ticket_row["phone"]; ?></td>
                      <td align="left">Category:</td>
                      <td align="left"><?php print $cat_row[1]; ?></td>
                    </tr>
                    <tr>
                      <td align="left">Email:</td>
                      <td align="left"><?php print $ticket_row["email"]; ?></td>
                      <td align="left">Priority:</td>
                      <td align="left"><?php print $pri; ?></td>
                    </tr>
                    <tr>
                      <td align="left">Subject:</td>
                      <td align="left" colspan="3"><?php print stripslashes($ticket_row["subject"]); ?></td>
                    </tr>
                  </table>
               </td>
             </tr>
           </table>
        </td>
      </td>
    </table>
    <br>
    <?php
    $msg_res = mysql_query("select * from messages where ticket = ".$ticket_row["ID"]." order by timestamp ASC;");
    while ($msg_row = mysql_fetch_array($msg_res)) {
        ?>  
        <table class="box" align="center" cellspacing="0" cellpadding="0" width="500" border=0>
          <tr>
            <td class="boxtitle" align="left" width="150">Original Message</td><td align="right" width="350" class="boxtitle"><?php print date("l, F j Y \a\\t h:i a", $msg_row["timestamp"]); ?></td>
          </tr>
          <tr>
            <td align="center" colspan="2">
              <table class="box" align="center" cellspacing="0" cellpadding="4" width="100%" border=0>
                <tr>
                  <td align="left">
                  <?php 
                  $buffer = nl2br($msg_row["message"]);
                  $buffer = str_replace("\'", "'", $buffer);
                  $buffer = str_replace('\"', '"', $buffer);
                  print ($buffer); 
                  ?>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table><br>
        <?php
        $answers_res = mysql_query("select answers.*, reps.name from answers left join reps on answers.rep=reps.ID where reference = ".$msg_row["ID"]." order by timestamp ASC;");
        while ($answer_row = mysql_fetch_array($answers_res)) {
            $count++;
            ?>
            <table class="box" align="center" cellspacing="0" cellpadding="0" width="500" border=0>
              <tr>
                <td class="boxtitle" align="left" width="150">Response <?php echo $count ?></td><td align="right" width="350" class="boxtitle"><?php print date("l, F j Y \a\\t h:i a", $answer_row["timestamp"]); ?></td>
              </tr>
              <tr>
                <td align="left" colspan="2">
                  <table class="box" align="center" cellspacing="0" cellpadding="4" width="100%" border=0>
                   <tr>
                     <td align="left">
                       <?php
                       $buffer = nl2br($answer_row["message"]);
                       $buffer = str_replace("\'", "'", $buffer);
                       $buffer = str_replace('\"', '"', $buffer);
                       print ($buffer); 
                       ?>
                     </td>
                   </tr>
                 </table>
                </td>
              </tr>
            </table><br>
            <?php
        }
        $lastid = $msg_row["ID"];
    }
    if (CheckSecurity("reply_ticket") == "true") {
        if ($ticket_row['status'] == "open") {
            $change_stat = "<input type=\"checkbox\" class=\"post\" name=\"close\"> Close Ticket";
        } else {
            $change_stat = "<input type=\"checkbox\" class=\"post\" name=\"open\"> Open Ticket";
        }
    } else {
        $change_stat = "&nbsp;";
    }
    ?>
    <br>
    <form action="view.php" method="POST">
    <table class="box" align="center" cellspacing="0" cellpadding="0" width="500" border=0>
    <tr>
        <td align="center" class="boxtitle" colspan="2">Reply to Ticket</td>
    </tr>
    <tr>
    <td>
    <table align="center" cellpadding="3" cellspacing="3" border="0">
    <tr>
        <td align="center" colspan="2">
        <input type="hidden" name="status" value="<?php echo $ticket_row["status"]?>">
        <input type="hidden" name="a" value="panswer">
        <input type="hidden" name="id" value="<?php echo $lastid; ?>">
        <br><textarea name="message" cols="70" rows="15" wrap="soft" style="background-color: #ffffff;"></textarea></td>
    </tr>
    <tr>
        <td width="300" align="center"><?php echo $change_stat?></td><td width="200" align="left"><input type="submit" class="button" value="Post Reply"></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    </form>
<center><a href="main.php?status=<?php echo $ticket_row["status"]?>">Back to main</a></center><br>
<?php
}

require("footer.php");

?>
