<?php
require("auth.php");

$page = substr(strrchr($_SERVER['HTTP_REFERER'],'/'),1);

if ($page == "index.php" or $page == "") $page = "main.php";

if (session_is_registered('email')) {
?>
<html>
<title>phpTickets <?php echo GetSetting('version')?></title>
<frameset rows="*,30" frameborder="no" border="1" framespacing="0">
  <frameset cols="153,*" frameborder="no" border="1" framespacing="0">
    <frame src="menu.php" scrolling="no" noresize  name="menu">
    <frame src="<?php echo $page?>" scrolling="auto" noresize name="main">
  </frameset>
  <frame src="stat.php" scrolling="no" noresize name="stat">
</frameset>
</html>
<?php
exit;
}
?>
