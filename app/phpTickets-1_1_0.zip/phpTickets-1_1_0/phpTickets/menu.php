<?php
require("auth.php");
?>
<div align="center">
<table bgcolor="#ffffff" border="0" cellpadding="4" cellspacing="3" width="150">
  <tr>
    <td valign="top" width="150">
      <table class="box" border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="boxtitle">phpTickets Menu</td>
        </tr>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_open.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="main.php?status=open" class="menuitem" target="main">Open Tickets</a><br>
          </td>
        </tr>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_closed.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="main.php?status=closed" class="menuitem" target="main">Closed Tickets</a><br>
          </td>
        </tr>
<?php
if (CheckSecurity("create_ticket") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_create.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="create.php" class="menuitem" target="main">Create Ticket</a><br>
          </td>
        </tr>
<?php
}
if (CheckSecurity("search_tickets") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_search.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="search.php" class="menuitem" target="main">Search Tickets</a><br>
          </td>
        </tr>
<?php
}
if (CheckSecurity("add_users") == "true" or CheckSecurity("remove_users") == "true" or CheckSecurity("update_users") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_users.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="users.php" class="menuitem" target="main">Manage Users</a><br>
          </td>
        </tr>
<?php
}
if (CheckSecurity("add_categories") == "true" or CheckSecurity("remove_categories") == "true" or CheckSecurity("update_categories") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_accounts.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="pops.php" class="menuitem" target="main">Pop Accounts</a><br>
          </td>
        </tr>
<?php
}
if (CheckSecurity("update_settings") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_settings.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="settings.php" class="menuitem" target="main">Settings</a><br>
          </td>
        </tr>
<?php
}
if (CheckSecurity("update_security") == "true") {
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_security.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="security.php" class="menuitem" target="main">Security</a><br>
          </td>
        </tr>
<?php
}
?>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="17" width="4"><img src="images/icon_logout.gif" width="16" height="16" align="absmiddle"><img src="images/spacer.gif" height="1" width="4"><a href="logout.php" class="menuitem" target="_top">Logout</a><br>
          </td>
        </tr>
        <tr>
          <td class="box_menu_cell">
            <img src="images/spacer.gif" height="3" width="2">
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</div>
<?php
require("footer.php");
?>
