<?php
session_start();

// If sessions is expired, send to login and exit
if (mktime() > $_SESSION['sesstime'] or $_SESSION['sesstime'] == "") {
        session_destroy();
        ?>
        <center>Your Session has expired!</center><br>
        <center><a href="index.php" target="_top">Click Here</a> to log in again</center>
        <SCRIPT LANGUAGE="JavaScript">
        top.document.location.href = "index.php";
        </SCRIPT>
        <?php
        exit;
}

// Send to login if not registered in some way
if (!session_is_registered("user_level")) {
    header("Location: index.php");
    exit;
}

// Get the current running script with no path info
$script = substr(strrchr($_SERVER['SCRIPT_FILENAME'],'/'),1);

// Bring in all necessary include files
require("mysql_fns.php");
require("config.inc.php");
require("tickets.inc.php");
if ($script <> "reload.php") require("header.php");

// Establish initial connection to database
$db = new db();
$dbh = $db->connect($db_host,$db_user,$db_pass,$db_db);

?>
