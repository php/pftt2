<?php

require("auth.php");
print "<body bgcolor=#FFFFFF>";

if (isset($_POST['ticket_category'])) {
    if (CheckSecurity("create_ticket") == "true") {
        if ($_SESSION['user_level'] == "3") {
            $email = $_SESSION['email'];
        } else {
            $email = $_POST['ticket_email'];
        }
        $ticket = CreateTicket($_POST['ticket_subject'], $_POST['ticket_name'], $email, $_POST['ticket_category'], $_POST['ticket_phone'], $_POST['ticket_pri'], $_POST['ticket_message']);
        if ($ticket == false)
            mail (GetSetting("trouble_email"), "{TROUBLE} ".$_POST['ticket_subject'], "[ERROR: CreateTicket failed]\n".$_POST['ticket_message'], "From: ".$_POST['ticket_name']."\nReply-To: ".$email);
        else {
            if (!PostMessage($ticket, $_POST['ticket_message'])) {
                mail (GetSetting("trouble_email"), "{TROUBLE} ".$_POST['ticket_subject'], "[ERROR: PostMessage failed].\n".$_POST['ticket_message'], "From: ".$_POST['ticket_name']."\nReply-To: ".$_POST['ticket_email']);
            }   
        }
        if ($ticket) { 
            print "<center>A support ticket has been created (#$ticket).</center>";
            print "<center><a href=view.php?a=vticket&id=" . $ticket . ">Click Here</a> to view ticket.";
            ?>
            <SCRIPT LANGUAGE="JavaScript">
            document.location.href = "view.php?a=vticket&id=<?php echo $ticket?>";
            </SCRIPT>
            <?php

        } else {  
            // It did not work but the message has been sent to $trouble_email...
            print "We will get back to you shortly.";
        } 
    } else {
        print "<center>You are not authorized to perform this operation.</center>\n";
    }
} else {
?>
<h3 align="center">Create Ticket</h3>
<form action="create.php" method="POST">
<table align="center" cellpadding=3 cellspacing=0>
<tr><td>&nbsp;</td></tr>
<tr>
 <td align="right"><strong>Full Name:</strong></td>
 <td><input type="text" name="ticket_name" size="25"></td>
</tr>
<?php
if (session_is_registered("rep")) {
    print '<tr>';
    print '<td align="right"><strong>Email Address:</strong></td>';
    print '<td><input type="text" name="ticket_email" size="25" value=""></td>';
    print '</tr>';
} else {
//    print '<input type="hidden" name="ticket_email" value="'.$_SESSION['email'].'">';
}
?>
<tr>
 <td align="right"><strong>Phone:</strong></td>
 <td><input type="text" name="ticket_phone" size="25" value=""></td>
</tr>
<tr>
 <td align="right"><strong>Subject:</strong></td>
 <td><input type="text" name="ticket_subject" size="35"></td>
</tr>
<tr>
 <td align="right" valign="top"><strong>Message:</strong></td>
 <td><textarea name="ticket_message" cols="35" rows="6"></textarea></td>
</tr>
<?php
$cat_res = $db->query($dbh,"select id,name from categories;");
if (mysql_num_rows($cat_res) > 0) {
?>
<tr>
 <td align="right" valign="top">POP Account:</td>
 <td><select name="ticket_category">
<?php
while ($cat_row = mysql_fetch_array($cat_res)) {
    print " <option value=\"$cat_row[0]\">".$cat_row[1]."</option>\n";
}
?>
 </select></td>
</tr>
<?php
}
?>
<tr>
 <td align="right"><strong>Priority:</strong></td>
 <td>
  <select name="ticket_pri">
  <option value="1">Low</option>
  <option value="2" selected>Normal</option>
  <option value="3">High</option>
  </select>
 </td>
</tr>
<tr>
 <td colspan="2" align="center"><br><input type="submit" class="button" value="Create Ticket"></td>
</tr>
</table>
</form>

<?php
}

require("footer.php");

?>
