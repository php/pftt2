<?php

require("auth.php");

print "<body>";

if (session_is_registered("rep")) {
    $statbar = $_SESSION['rep'];
} else {
    $statbar = "Guest - ".$_SESSION['email'];
}
?>
<table border=0 cellpadding=0 cellspacing=0 width="100%" align="center">
<tr>
<td align="center" width="50%" class="boxtitle">Logged in as: <?php echo $statbar?></td>
<td align="center" width="50%" class="boxtitle">phpTickets - Version <?php echo GetSetting('version')?></td>
</tr>
</table>
<?php

require("footer.php");

?>

