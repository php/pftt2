<?php
$PHORUM["DATA"]["LANG"]["example_language"]["HelloWorld"] = "Salut le Monde!";
?>
