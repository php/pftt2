<?php defined("SYSPATH") or die("No direct script access.") ?>
<? echo Kohana_Exception::text($e), "\n";

