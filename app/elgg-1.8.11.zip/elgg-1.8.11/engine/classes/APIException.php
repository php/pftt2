<?php

/**
 * API Exception Stub
 *
 * Generic parent class for API exceptions.
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class APIException extends Exception {}
