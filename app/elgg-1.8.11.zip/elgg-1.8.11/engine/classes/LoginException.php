<?php
/**
 * Login Exception Stub
 *
 * Generic parent class for login exceptions.
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class LoginException extends Exception {}
