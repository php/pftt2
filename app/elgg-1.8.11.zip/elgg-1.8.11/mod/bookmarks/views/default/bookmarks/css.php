.elgg-icon-bookmark {
	background: transparent url(<?php echo elgg_get_site_url();?>mod/bookmarks/graphics/bookmark.gif);
}