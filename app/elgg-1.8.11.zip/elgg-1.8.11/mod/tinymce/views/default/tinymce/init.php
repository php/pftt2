<?php
/**
 * Initialize the TinyMCE script
 */

elgg_load_js('tinymce');
elgg_load_js('elgg.tinymce');