<?php
///////////////////////////////////////////////////////////////////////////////////////
// PHPmotion                                                http://www.phpmotion.com //
///////////////////////////////////////////////////////////////////////////////////////
// License: You are not to sell or distribute this software without permission       //
// Help and support please visit http://www.phpmotion.com                            //
// Copyright reserved                                                                //
///////////////////////////////////////////////////////////////////////////////////////
include_once ('classes/config.php');

$base_site = 'http://' . $_SERVER['SERVER_NAME'] . '/index.php';

echo "<br />";
echo "<br />";
echo "<br />";

echo "<center><h2>Access Forbidden!</h2>";
echo "<br />";
echo "</center>";

?>