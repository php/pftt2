<?php

$admin_logout = 'Logout';
$disabled = 'Disabled';
$lang_pictures = 'Pictures';
$lang_active = 'Active';
$lang_suspended = 'Suspended';
$lang_pending = 'Pending';
$lang_promoted = 'Promoted';

?>