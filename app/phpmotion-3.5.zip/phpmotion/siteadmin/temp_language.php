<?php

$admin_logout = 'Logout';
$disabled = 'Disabled';


?>