<?php
error_reporting (0);
///////////////////////////////////////////////////////////////////////////////////////
// PHPmotion                                                http://www.phpmotion.com //
///////////////////////////////////////////////////////////////////////////////////////
// License: You are not to sell or distribute this software without permission       //
// Help and support please visit http://www.phpmotion.com                            //
// Copyright reserved                                                                //
///////////////////////////////////////////////////////////////////////////////////////

$reserved_names = array(
				'test',
				'tester',
				'demo',
				'phpmotion',
				'phpmotion ver 2',
				'phpmotion ver 3',
				'phpmotion version 2',
				'phpmotion version 3',
				'version 2',
				'version 3',
				'admin',
				'administrator',
				'webmaster',
				'root',
				$config['site_name']
				);

/*

add in any adult words above or any names you wish to exclude from registration

when adding in a word you must follow the same syntax as seen above in the array

so you would add the word enclosed in single quotes with an comma at the end
but there is not any comma used after the last entry !!

*/


?>