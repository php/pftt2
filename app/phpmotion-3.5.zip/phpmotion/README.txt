-------------------------
Installation Instructions
-------------------------

Visit - http://wiki.phpmotion.com/InstallingV3