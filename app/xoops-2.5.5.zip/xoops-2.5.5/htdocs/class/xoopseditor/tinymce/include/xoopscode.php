<?php
/**
 *  TinyMCE adapter for XOOPS
 *
 * @copyright       The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license         http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package         class
 * @subpackage      editor
 * @since           2.3.0
 * @author          Laurent JEN <dugris@frxoops.org>
 * @version         $Id: xoopscode.php 8066 2011-11-06 05:09:33Z beckmi $
 */

if (!defined("XOOPS_ROOT_PATH")) { die("XOOPS root path not defined"); }

// Add your code here to check acces by groups

return true;
?>