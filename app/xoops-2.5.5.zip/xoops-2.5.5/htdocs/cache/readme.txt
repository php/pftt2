Just kept for backward compat.
It is recommended to point the folder to xoops_data/caches/smarty_cache/ with symlink.