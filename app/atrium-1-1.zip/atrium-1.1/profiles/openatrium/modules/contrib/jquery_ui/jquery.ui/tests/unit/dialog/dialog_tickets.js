/*
 * dialog_tickets.js
 */
(function($) {

module("dialog: tickets");

})(jQuery);
