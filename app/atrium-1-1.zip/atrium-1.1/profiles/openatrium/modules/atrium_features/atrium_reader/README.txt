Atrium Reader
-------------

Atrium Reader is a simple RSS/Atom feed reader for Open Atrium. Atrium Reader
requires Open Atrium 1.0-beta4 or greater.