<p>Se utilizzate un template, questo messaggio verr&agrave; posto nella posizione del segnaposto [CONTENT] nel vostro template.</p>
<p>inoltre a [CONTENT], puoi aggiungere [FOOTER] e [SIGNATURE] per inserire le informazioni nella riga a pi� di pagina e la firma del messaggio, ma sono opzionali.</p>
