<p>Je kunt zoveel bijlages aan je bericht toevoegen als je wilt, maar het nummer dat je hier ziet
is vastgelegd in jouw configuratie.</p>
<p><b>Let op:</b> Bijlages worden ingesloten in HTML emails, bij tekst emails zal er een link naar de website toegevoegd worden.</p>
<p>Het beschrijvings-veld wordt enkel in tekst emails gebruikt.</p>