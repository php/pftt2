<p>Als je een template gebruikt, dan zal het bericht worden geplaatst waar de placeholder [CONTENT] staat in je template.</p>
<p>Bijkomend bij [CONTENT], kan je [FOOTER] en [SIGNATURE] gebruiken om footer informatie en de handtekening van het bericht mee te sturen. Deze zijn optioneel.</p>
