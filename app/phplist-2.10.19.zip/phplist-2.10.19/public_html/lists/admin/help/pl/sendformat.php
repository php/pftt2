Je�li sformatowano wiadomo�� przy u�yciu HTML,
nalezy wskaza� jak ma by� wys�ana:<br />
<ul>
<li><b>HTML</b> - HTML z ukrytym tekstem tylko do u�ytkownik�w, kt�rzy wskazali, �e chc� odbiera� wiadomo�ci w formacie HTML, a tekstowe do wszystkich innych</li>
<li><b>tekst</b> - tylko tekstowe do wszystkich</li>
<!-- li><b>text and HTML</b> - One big email that contains both the HTML and the text only format.</li> -->
<li><b>PDF</b> - Wiadomo�� tekstowa jako za��cznik PDF</li>
<li><b>tekst and PDF</b> - jedna wiadomo�� zawieraj�ca tekstow� tre�� z za��cznikiem PDF</li>
</ul>

<b>Uwaga:</b> wersja PDF wn�dzie konwersj� tre�ci tekstowej a nie HTML.