<p>Je�li u�ywasz szblonu, wiadomo�c zostanie wstawiona w miejscu symbolu [CONTENT] u�ytego w szablonie.</p>
<p>Opr�cz [CONTENT], mo�esz doda� [FOOTER] oraz [SIGNATURE] aby wstawi� stopk� i podpis wiadomo�ci, jednak jest to opcjonalne.</p>
