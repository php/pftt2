<p>Annyi mellékletet csatol az üzenethez, amennyit csak tetszik, az itt látható mennyiség azonban
a konfigurációban van meghatározva.</p>
<p><b>Megjegyzés:</b> A HTML-formátumú e-mailek tartalmazzák a mellékleteket, a szöveges formátumú e-mailekhez a webhelyre mutató hivatkozásként kerülnek hozzáadásra</p>
<p>A leírás mező csak a szöveges üzenetekben lesz használatban</p>