<b>Üzenet zárolása</b>
<p>Zárolhat egy üzenetet, vagyis a jelzett dátum és időpont előtt nem kerül elküldésre.
Alapértelmezésként ma 0:00 órára állított lesz, tehát azonnal küldésre kerül. </p>
<p><b>Megjegyzés</b>: a zárolás az üzenet küldésének kezdő időpontjára van hatással.
Ez nem azt jelenti, hogy az üzenetek éppenséggel meg is fognak érkezni abban az időpontban a felhasználók postaládáiba.
</p>