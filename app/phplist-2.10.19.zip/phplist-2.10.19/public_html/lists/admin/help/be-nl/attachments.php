<p>U kan zoveel bijlages aan het bericht toevoegen als u wil, maar een beheerder kan dit beperken om overbelasting van de server te voorkomen.
Dit is vastgelegd in de configuratie en is momenteel is dit aantal beperkt tot het getal dat u hier ziet.</p>
<p><b>Let op:</b> Bijlages worden ingesloten in HTML emails, bij tekst emails zal er een link naar de website toegevoegd worden.</p>
<p>Het beschrijvings-veld wordt enkel in tekst emails gebruikt.</p>
