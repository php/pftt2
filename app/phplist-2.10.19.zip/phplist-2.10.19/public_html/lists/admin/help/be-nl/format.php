<h3>Formaat van het bericht</h3>
Als u "auto detectie" gebruikt, dan zal het bericht worden ingesteld als HTML van zodra er een HTML tag (&lt; ... &gt;) in voorkomt.
</p><p><b>Het is veilig om dit aangevinkt te laten als "Auto detectie"</b></p><p>
Als u niet zeker bent dat "auto detectie" werkt en het bericht dat je maakt moet in HTML stijl zijn, kies dan voor "HTML".
Externe links naar bronnen (vb afbeeldingen) hebben de volledige URL nodig, startend met http:// (niet zoals de template afbeeldingen).
Voor de rest ben je volledig verantwoordelijk over het formaat van de tekst.
<p>Als u het bericht als pure tekst wilt verzenden, vink dan "Tekst" aan.
</p><p>
Deze informatie wordt gebruikt om de pure tekst versie van een HTML bericht of een HTML versie van een pure tekst bericht te maken.
Dit formaat zal er als volgt uitzien:<br/>
Origineel is HTML -&gt; tekst<br/>
<ul>
<li><b>Vette</b> tekst zal ingesloten zitten tussen <b>*-tekens</b>, <b>scheve</b> tekst with <b>/-tekens</b></li>
<li>Links rond tekst zullen worden vervangen door de tekst, gevolgd door de URL tussen haakjes</li>
<li>Grote blokken tekst zullen worden verdeeld bij kolom 70</li>
</ul>
Origineel is Tekst -&gt; HTML<br/>
<ul>
<li>Dubbele nieuwe lijnen zullen worden vervangen door een &lt;p&gt; (paragraaaf)</li>
<li>Enkele nieuwe lijnen zullen worden vervangen door een &lt;br /&gt; (line break)</li>
<li>Email addressen zullen klikbaar gemaakt worden</li>
<li>URLs zullen klikbaar worden. URLs mogen in de volgende vorm staan:<br/>
<ul><li>http://een.website.url/pad/naar/eenbestand.html
<li>www.websiteurl.be
</ul>
De aangemaakte links zullen de stylesheet class "url" hebben en target "_blank".
</ul>
<b>Opgelet</b>: als je aanduid dat je bericht Tekst-enkel is maart je plakt HTML tekst in de editor, dan zal er Tekst-enkel HTML worden verstuurd naar gebruikers die enkel Tekst emails ontvangen.
