Deze optie staat het systeem toe om automatisch een nieuw bericht aan te maken
dat een exacte kopie is van het huidige bericht, vastgelegd bij het interval dat je aanduid.
Als u deze optie gebruikt, dan is het belangrijk om de "plannings" (of embargo) optie ook te gebruiken, anders
zal je bericht constant worden verzonden, wat verzenden van veel berichten die hetzelfde zijn naar de gebruikers veroorzaakt.
