<p>If you use a template, this message will be placed in the location of the [CONTENT] placeholder in your template.</p>
<p>Additionally to [CONTENT], you can add [FOOTER] and [SIGNATURE] to insert the footer information and the signature of the message, but they are optional.</p>
