<p>L&#432;u &yacute; khi k&#7871;t h&#7907;p c&aacute;c thu&#7897;c t&iacute;nh:</p>
<ul>
  <li>K&#7871;t h&#7907;p c&aacute;c thu&#7897;c t&iacute;nh s&#7869; kh&ocirc;ng thay &#273;&#7893;i th&ocirc;ng tin v&#7873; ng&#432;&#7901;i d&ugrave;ng nh&#432;ng s&#7869; g&#7897;p t&#7845;t c&#7843; th&agrave;nh m&#7897;t thu&#7897;c t&iacute;nh. Thu&#7897;c t&iacute;nh &#273;&#7847;u ti&ecirc;n  (theo th&#7913; t&#7921; b&#7841;n th&#7845;y trong trang) s&#7869; &#273;&#432;&#7907;c gi&#7919; l&#7841;i.<br>
  </li>
  <li>B&#7841;n ch&#7881; k&#7871;t h&#7907;p c&aacute;c thu&#7897;c t&iacute;nh c&oacute; c&ugrave;ng ki&#7875;u<br>
  </li>
  <li>Khi k&#7871;t h&#7907;p, gi&aacute; tr&#7883; c&#7911;a thu&#7897;c t&iacute;nh &#273;&#7847;u ti&ecirc;n s&#7869; &#273;&#432;&#7907;c gi&#7919; l&#7841;i n&#7871;u c&oacute;, n&#7871;u kh&ocirc;ng n&oacute; s&#7869; b&#7883; ghi &#273;&egrave; b&#7903;i c&aacute;c thu&#7897;c t&iacute;nh b&#7883; k&#7871;t h&#7907;p. &#272;i&#7873;u n&agrave;y c&oacute; th&#7875; l&agrave;m m&#7845;t d&#7919; li&#7879;u trong tr&#432;&#7901;ng h&#7907;p c&#7843; hai thu&#7897;c t&iacute;nh &#273;&#7873;u c&oacute; gi&aacute; tr&#7883;.<br>
  </li>
  <li>N&#7871;u b&#7841;n k&#7871;t h&#7907;p thu&#7897;c t&iacute;nh c&oacute; ki&#7875;u <i>checkbox</i> th&igrave; thu&#7897;c t&iacute;nh m&#7899;i s&#7869; l&agrave; nh&oacute;m <i>checkbox</i> <br>
  </li>
  <li>Thu&#7897;c t&iacute;nh m&agrave; b&#7883; k&#7871;t h&#7907;p v&agrave;o thu&#7897;c t&iacute;nh kh&aacute;c s&#7869; b&#7883; x&oacute;a sau khi k&#7871;t h&#7907;p.</li>
</ul>
