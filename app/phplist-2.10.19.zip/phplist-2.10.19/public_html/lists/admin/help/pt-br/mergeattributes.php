<p>Notas sobre a fus&atilde;o de atributos.</p>
<p>Fundir atributos significa que os valores para os usu&aacute;rios ser&atilde;o os mesmo, mas que os atributos que eles tenham ser&atilde;o fundidos em um &uacute;nico. O atributo que prevalecer&aacute; &eacute; o primeiro (de acordo com a lista, como voc&ecirc; pode ver nesta p&aacute;gina).</p>
<ul>
<li>Voc&ecirc; s&oacute; pode fundir atributos de mesmo tipo</li>
<li>Quando voc&ecirc; usa esta op&ccedil;&atilde;o, o valor do primeiro atributo ser&aacute; mantido se existir, caso contr&aacute;rio ele ser&aacute; substitu&iacute;do pelo valor do atributo que est&aacute; sendo mesclado. Isso pode causar a perda de dados no caso de ambos atributos poss&iacute;rem diferentes valores. </li>
<li>Se voc&ecirc; funde atributos do tipo <i>marcar caixa</i> o resultado da fus&atilde;o de atributos ser&aacute; do tipo <i>marcar grupo de caixas</i>.</li>
<li>Os atributos que est&atilde;o sendo fundidos em um outro, ser&atide;o apagados depois da fus&atilde;o.</li>
</ul>
