<p>Puede agregar tantos archivos adjuntos como desee, pero el n&uacute;mero que 
  aqu&iacute; aparece es definido en la configuraci&oacute;n.</p>
<p><b>Nota:</b> Los archivos adjuntos ser&aacute;n inclu&iacute;dos en mensajes 
  con formato HTML, y en los mensajes con formato texto plano ser&aacute;n agregados 
  como un enlace al sitio web para descargarlos.</p>
<p>El campo de descripci&oacute;n ser&aacute; utilizado solamente en mensajes 
  en formato texto plano.</p>