Si este mensaje ha sido formateado como HTML, indique c&oacute;mo quiere enviarlo:<br />
<ul>
<li><b>HTML</b> - HTML a los usuarios que han escogido la opci&oacute;n de recibir correo HTML, y texto plano a todos los dem&aacute;s</li>
<li><b>texto plano</b> - Texto plano a todo el mundo</li>
<li><b>texto plano y HTML</b> - Un correo m&aacute;s voluminoso que contenga tanto la versi&oacute;n HTML como la de texto plano (el correo es mayor pero es m&aacute;s probable que funcione adecuadamente para todos)</li>
<li><b>PDF</b> - El texto del mensaje enviado como adjunto en formato PDF</li>
<li><b>texto plano y PDF</b> - Un correo con el mensaje en texto plano, m&aacute;s un adjunto en formato PDF</li>
</ul>

<b>Nota:</b> La versi&oacute;n PDF se hace a partir del texto plano, no del HTML.
