<p>Wenn Sie eine Sperrfrist setzen, so wird die Nachricht nicht vor dem angegeben Datum/Zeitpunkt versendet.
Standardm&auml;ssig wird die Sperrfrist auf das heutige Datum und den Zeitpunkt 00:00 Uhr gesetzt, was bedeutet, dass die Nachricht sofort versendet wird (keine Sperrfrist).</p>

<p><b>Bitte beachten Sie</b>: Die Sperrfrist beeinflusst nur den Zeitpunkt, an dem der Versand einer Nachricht beginnt.
Dies bedeutet nicht, dass die Nachricht zu diesem Zeitpunkt in der Inbox des Empf&auml;ngers ankommt.</p>