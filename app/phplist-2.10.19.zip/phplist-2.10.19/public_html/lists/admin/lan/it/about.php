<?php

$lan = array(
  'Developers' => 'Sviluppatori',
  'Contributors' => 'Contributi speciali',
  'Translations' => 'Traduzione',
  'Portions of the system include' => 'Portions of the system include',
  'thankseveryone' => 'Gli sviluppatori desiderano ringraziare i molti che hanno contribuito, che hanno aiutato a cercare bug, che hanno fornito i loro suggerimenti, donazioni, richieste di funzionalit&agrave; aggiuntive, gli sponsor, i traduttori e tutti gli altri contributi.',


  # use this tag to give your own name(s), so you are listed in the "About" page
  # for credits for this particular translation
  'credits for this translation' => 'Martina Picardi e Lorenzo Bruschetti, staff di <a href="http://www.hosting-linux.biz">Hosting-Linux</a>',

  # new in 2.10.1
  'Documentation' => 'Documentazione',
);

?>
