<?php
$lan = array( 
 'you only have privileges to view this page, not change any of the information' => 'I tuoi privilegi ti consentono di visualizzare questa pagina ma non di apportarvi modifiche',
 'no such User' => 'Nessun utente',
 'view' => 'Visualizza',
 'user is Blacklisted since' => 'L\'utente appartiene alla blacklist da',
 'messages sent to this user' => 'messaggi inviati a questo utente',
 'are you sure you want to delete this user from the blacklist' => 'Sei sicuro di voler cancellare questo utente dalla blacklist',
 'it should only be done with explicit permission from this user' => 'Questa operazione dovrebbe essere fatta unicamente con il consenso dell\'utente',
 'remove User from Blacklist' => 'Rimuovi utente dalla Blacklist',
 'user subscription history' => 'Storico iscrizioni utente ',
 'no details found' => 'Nessun dettaglio trovato',
 'messages sent to this user' => 'Messaggi inviati a questo utente',
 'ip' => 'ip',
 'date' => 'data',
 'summary' => 'sommario',
 'detail' => 'dettagli',
 'info' => 'info',
 'blacklist info' => 'Blacklist Info',
 'value' => 'valore',
 'subscription history' => 'Storico iscrizioni', 
 'clicks' => 'clicks',

 # new in 2.9.5
  'viewed' => 'visualizzato',
  'responsetime' => 'tempo di risposta',
  'average' => 'media',
 
);
?>
