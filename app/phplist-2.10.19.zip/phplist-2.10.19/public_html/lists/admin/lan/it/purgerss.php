<?php

$lan = array(
'Purge RSS items from database' => 'Elimina elementi RSS dal database',
'Enter the number of days to go back purging entries' => 'Immetti il numero di giorni da cui far partire l\'eliminazione',
'%d RSS items purged' => '%d Elementi RSS eliminati',

'Sorry, only super users can purge RSS items from the database' => 'Spiacente, solo super utenti possono eliminare elementi RSS dal database',
);
?>
