<?php

$lan = array(
'Click Details for a URL' => 'Dettagli dei click per URL',
'URL Click Statistics' => 'Statistiche dei click per URL',
'firstclick' => 'primoclick',
'latestclick' => 'ultimotclick',
'clicks' => 'clicks',
'clickrate' => 'percentualeclick',
'clicks' => 'clicks',
'msg' => 'msg',
'who' => 'chi',
'view users' => 'visualizza utenti',
'You do not have access to this page' => 'Non sei autorizzato ad accedere a questa pagina',
'Select URL to view' => 'Seleziona URL da visualizzare',
'Available URLs' => 'URL disponibili',
'sent' => 'inviato',
'unique clicks' => 'singoli clicks',
'unique clickrate' => 'percentuale singoli clicks',
);
?>
