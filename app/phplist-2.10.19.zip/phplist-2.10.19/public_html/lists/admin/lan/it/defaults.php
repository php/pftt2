<?php 
$lan = array(

  "loading" => "Caricamento..",
  "done" => "Fatto",
  "name_empty" => "Il nome non può essere cancellato:",
  "name_not_unique" => "Il nome non &egrave; abbastanza univoco",
  "continue" => "Continua",
  'add' => 'Aggiungi',

);
?>
