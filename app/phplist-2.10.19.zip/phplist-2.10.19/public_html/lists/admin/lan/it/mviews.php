<?php

$lan = array(
  'You do not have access to this page' => 'Non hai accesso a questa pagina',
  'Select Message to view' => 'Seleziona un messaggio da visualizzare',
  'Available Messages' => 'Messaggi disponibili',
  'views' => 'visualizzazioni',
  'rate' => 'percentuale',
  'View Details for a Message' => 'Visualizzaziona dettagli per un messaggio',
  'Subject' => 'Oggetto',
  'Entered' => 'Inserito',
  'Message Open Statistics' => 'Statistiche aperte del messaggio',
  'Listing user %d to %d' => 'Elenca utenti da %d a %d',
  'Entries' => 'Voci',
  'firstview' => 'prima visualizzazione',
  'lastview' => 'ultima visualizzazione',
  'views' => 'visualizzazioni',
  'responsetime' => 'tempo di risposta',
  'sec' => 'sec',

  # for 2.10.2
'there are currently no messages to view' => 'Al momento non ci sono messaggi da visualizzare',
);

?>
