<?php

$lan = array(
  'List Bounce Rules' => 'Mostra le regole del rimbalzo',
  'rulesexistwarning' => 'Le regole del rimbalzo sono gi&agrave; state definite per il tuo sistema. 
    Fai attenzione nel generarne altre, perch&eacute; potrebbero interferire con quelle esistenti',
  'norulesyet' => 'Non ci sono regole definite. 
    Puoi selezionare "Genera regole rimbalzo" per generare automaticamente le regole dai rimbalzi esistenti. Quest\'operazione potrebbe riguardare molte regole, e potrebbe essere necessario controllarle e attivarle. Le regole potrebbero comunque non essere applicate a ogni singolo rimbalzo, e potrebbe essere necessario aggiungere nuove regole ai nuovi rimbalzi',
  'Generate Bounce Rules' => 'Genera regole rimbalzo',
  'Check Current Bounce Rules' => 'Controlla le regole correnti',
);

?>
