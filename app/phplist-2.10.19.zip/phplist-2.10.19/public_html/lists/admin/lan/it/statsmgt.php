<?php

$lan = array(
  'View Clicks by URL' => 'Visualizza click per URL',
  'View Clicks by Message' => 'Visualizza click per messaggio',

 # new in 2.9.5
  'View Opens by Message' => 'Visualizza aperture per messaggio',
  'Domain Statistics' => 'Statistiche dominio',
);
?>
