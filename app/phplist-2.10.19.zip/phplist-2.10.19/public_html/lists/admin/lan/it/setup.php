<?php
$lan = array(

  'initialise_database' => 'Inizializza Database',
  'change_admin_passwd' => 'Cambia password amministratore',
  'config_gral_values' => 'Configura Valori Generali',
  'config_attribs' => 'Configura Attributi',
  'create_lists' => 'Crea Liste',
  'create_subscr_pages' => 'Crea Pagine di Iscrizione',
  'go_there' => 'Vai',

);
?>
