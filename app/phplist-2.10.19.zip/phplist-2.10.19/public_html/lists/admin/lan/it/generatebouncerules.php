<?php

$lan = array(
  'Process Next Batch' => 'Processa il prossimo gruppo',
  'Process Killed by other process' => 'Processo interrotto da un altro processo',
  'Hmm, duplicate entry, ' => 'Hmm, voce doppia, ',
  'new rules found' => 'trovate nuove regole',
  'bounces not matched' => 'rimbalzi non corrispondenti',
  'bounces matched to existing rules' => 'rimbalzi associati alle regole esistenti',
‾
);

?>
