<?php 
$lan = array(
  "NoAttr" => "Attributo non esistente:",
  "AddNew" => "Aggiungi nuovo",
  "SureToDeleteAll" => "Sei sicuro di voler eliminare tutti i record?",
  "DelAll" => "Elimina tutti",
  "ReplaceAllWith" => "In alternativa puoi sostituire tutti i valori con un altro:",
  "ReplaceWith" => "Sostituisci con",
  "TooManyToList" => "* Troppi da elencare, dipendenze totali:",
  "TooManyErrors" => "* Troppi errori, esco",
  "Delete" => "cancella",
  "Default" => "(predefinito)",
  "changeorder" => "cambia ordine",
  "cannotdelete" => "inpossibile eliminare ",
  "dependentrecords" => "I seguenti recordi dipendono da questo valore<br />
    Modifica i record per non utilizzare questo attributo di valore e prova di nuovo.",
  "addnew" => "Aggiungi nuovo",
  "oneperline" => "Uno per linea",
  "deleteandreplace" => 'Elimina e Sostituisci',
  
  
);
?>
