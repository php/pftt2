<?php
$lan = array(
 'Deleting' => 'Cancellazione',
 'Done' => 'Fatto',
 'RSS source' => 'sorgente RSS',
 'delete' => 'cancella',
 'n/a' => 'n/a',
 'No lists available, use Add to add one' => 'nessuna lista disponibile, usa Aggiungi per crearne una',
 'No' => 'no',
 'Name' => 'nome',
 'Order' => 'ordine',
 'Functions' => 'funzioni',
 'Active' => 'attiva',
 'Owner' => 'proprietario',
 'Save Changes' => 'salva modifiche',
 'Add a list' => 'aggiungi una lista',
 'members' => 'membri',
 '(view items)' => '(visualizza elementi)',
 'edit' => 'modifica',
 'view members' => 'visualizza membri',
);
?>
