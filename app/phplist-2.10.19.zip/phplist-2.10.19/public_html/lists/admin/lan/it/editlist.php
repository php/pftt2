<?php
$lan = array(
 'You do not have enough priviliges to view this page' => 'Non hai sufficienti privilegi per visualizzare questa pagina',
 'Members of this list' => 'Membri di questa lista',
 'Record Saved' => 'Record Salvato',
 'List name' => 'Nome della lista',
 'Check this box to make this list active (listed)' => 'Spunta questa casella per rendere la lista attiva (listed)',
 'Order for listing' => 'Ordine per la lista',
 'Subject Prefix' => 'Prefisso dell\'oggetto',
 'Owner' => 'Proprietario',
 'RSS Source' => 'Sorgente RSS',
 'List Description' => 'Descrizione della lista',
 'View Items' => 'Vedi Elementi',
 'Save' => 'Salva',
 'validate' => 'valida',
);
?>
