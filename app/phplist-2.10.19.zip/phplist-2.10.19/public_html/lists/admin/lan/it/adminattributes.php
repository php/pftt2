<?php 
$lan = array(
  'SaveChanges' => 'Salva Modifiche',
  'NameNotEmpty' => 'Il campo Nome non può essere vuoto:',
  'NameNotUnique' => 'Il nome &egrave; abbastanza univoco',
  'ExistingAttr' => 'Attributi esistenti:',
  'NoAttrYet' => 'Nessun attributo ancora definito<br/>',
  'Attribute' => 'Attributo:',
  'Delete' => 'Cancella',
  'Name' => 'Nome:',
  'Type' => 'Tipo:',
  'DValue' => 'Valore predefinito:',
  'OrderListing' => 'Ordine in lista:',
  'IsAttrRequired' => 'Questo attributo &egrave; richiesto?:',
  'AddAttr' => 'Aggiungi un nuovo attributo:',
);
?>
