<?php

$lan = array(
'Add new admin' => 'Aggiungi un nuovo Amministratore',
'Administrators' => 'Amministratori',
'Find an admin' => 'Trova un amministratore',
'Administrators' => 'Amministratori',
'Show' => 'Mostra',
'Show' => 'Mostra',
'Show' => 'Mostra',
'Add new admin' => 'Aggiungi un nuovo Amministratore',
'Import list of admins' => 'Importa una lista di Amministratori',
'Deleting' => 'Cancello',
'Done' => 'Fatto',
'Admin added' => 'Amministratore aggiunto',
'Listing admin' => 'Mostra lista Amministratori',
'Listing admin 1 to 50' => 'Mostra lista Amministratori da 1 a 50',
'found' => 'trovato',

);

?>
