<?php

$lan = array(
'Sorry, this page can only be used by super admins' => 'Spiacente, questa pagina pu&ograve; essere utilizzata solamente da un Super Amministratore',
'Mass unconfirm email addresses' => 'Deconferma tutti gli indirizzi email',
'Paste the emails to mark unconfirmed in this box, and click continue' => 'Incolla le email da segnalare come non cofermate in questo box e clicca su "continua"',
'Continue' => 'Continue',
'All done, %d emails processed, %d emails marked unconfirmed<br/>' => 'Tutto fatto, %d email processate, %d email segnate come non confermate<br/>',
);
?>