<?php

$lan = array(
  'PHPList Users' => 'Utenti PHPList',
  'on' => 'nella lista', # as in Member of a list (user A on list B)
  'List Membership' => 'Lista Membri',
  'No Lists' => 'Nessuna Lista',
);

?>
