<?php

$lan = array(
  'Process Next %d' => 'Processa il prossimo %d',
  'No match' => 'Nessuna corrispondenza',
  'bounces did not match any current active rule' => 'ai rimbalzi non corrisponde nessuna regola attualmente attiva',
  'bounce matched current active rules' => 'il rimbalzo è associato ad una regola attualmente attiva',
);
?>
