<?php
$lan = array(
  "Deleting" => "Cancellazione",
  "Done" => "Fatto",
  "No template have been defined" => "Non &egrave; stato definito alcun template",
  "Existing templates" => "templates esistenti",
  "View" => "Visualizza",
  "Edit" => "Modifica",
  'delete' => 'Cancella',
  "Add new Template" => "Aggiungi nuovo template",
  'ID' => 'ID',
  'Default' => 'Predefinito',
  '# imgs' => '# img',

);
?>
