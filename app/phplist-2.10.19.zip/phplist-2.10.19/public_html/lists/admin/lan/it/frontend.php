<?php

$lan = array(
'Please indicate how often you want to receive messages' => 'Per favore indica con che frequenza vuoi ricevere messaggi',
 'Email is blacklisted, so request for confirmation has been sent.' => 'L\'utente è nella blacklist, la richiesta di conferma &egrave; stata inviata.',
   'If user confirms subscription, they will be removed from the blacklist.'=> 'Se l\'utente conferma l\'iscrizione, sar&agrave; rimosso dalla blacklist',
//  'YouAreBlacklisted' => 'La tua email &egrave; nella nostra "Black List", poich&eacute; abbiamo ricevuto la tua richiesta di non mandarti pi&ugrave; email. <br/>
//L\'unica email che il sistema ti invier&agrave; &egrave; la richiesta di conferma e cliccando il link contenuto in essa sarai rimosso dalla nostra blacklist continuando a ricevere le nostre newsletters.'
);

?>
