<?php

$lan = array(
  'users' => 'Utenti',
  'control' => 'Controlla valori per',
  'userattributes' => 'Attributi utente',
  'reconcile' => 'Riconcilia utenti',
  'check' => 'Controlla per utenti',
  'import' => 'Importa utenti',
  'export' => 'Esporta utenti',
  'mass unconfirm users' => 'De-conferma tutti gli utenti'
);
