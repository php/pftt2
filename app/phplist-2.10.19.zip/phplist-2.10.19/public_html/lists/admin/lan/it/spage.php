<?php 
$lan = array(

  'subscribe pages' => 'Pagine di Iscrizione',
  'deleted' => 'Eliminato',
  'add_new' => 'Aggiungi nuovo',
  'title' => 'titolo',
  'edit' => 'modifica',
  'del' => 'canc',
  'view' => 'visualizza',
  'status' => 'stato',
  'owner' => 'proprietario',
  'default' => 'predefinito',
  'active' => 'attivo',
  'not active' => 'non attivo',

);
?>
