<?php

$lan = array(
  'existingusers' => "Utenti esistenti",
  'nonexistingusers' => "Utenti non esistenti",
  'existcheckintro' => 'Pagina per controllare l\'esistenza dell\'utente nel database',
  'whatistype' => 'Quale tipo di informazione vuoi controllare',
  "foreignkey" => "Chiave esterna",
  "email" => "Email",
  "continue" => "Continua",
  "pastevalues" => "Incolla i valori da controllare in questo box, uno per riga",


  # new in 2.10.1
  'key' => 'chiave',
  'passwd' => 'passwd',
);

?>
