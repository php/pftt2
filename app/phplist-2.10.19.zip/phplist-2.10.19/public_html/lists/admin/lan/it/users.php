<?php

$lan = array(
'Delete will delete user and all listmemberships' => 'L\'opzione Cancella elimer&agrave; tutti l\'utente e tutte le liste di appartenenza',
'%s users apply' => '%s richiesta utenti',
'Users marked <span class="highlight">red</span> are unconfirmed' => 'Gli utenti marcati con colore <span class="highlight">rosso</span> non sono confermati',
'Show only unconfirmed users' => 'Mostra soltanto utenti non confermati',
'Show only blacklisted users' => 'Mostra soltanto utenti appartenenti alla Blacklist',
'email' => 'email',
'bouncecount' => 'conteggio rimbalzi',
'entered' => 'immesso',
'modified' => 'modificato',
'foreignkey' => 'chiave esterna',
'Sort by' => 'Ordina per',
'desc' => 'descr',
'asc' => 'asc',
'Go' => 'Vai',
'Find a user' => 'Trova un utente',
'Email' => 'Email',
'Foreign Key' => 'Chiave esterna',
'reset' => 'azzera',
'Download all users as CSV file' => 'Scarica tutti gli utenti in un file CSV',
'Add a User' => 'Aggiungi Utente',
'confirmed' => 'conferma',
'bl l' => 'bl l', # as in black listed (but then as short as possible)
'del' => 'canc',
'key' => 'chiave',
'msgs' => 'msg', # meaning messages
'rss' => 'rss',
'rss freq' => 'freq rss', # meaning rss frequency
'bncs' => 'rimbalzi', # meaning bounces
'No users apply' => 'Nessuna richiesta utenti',
'Your privileges for this page are insufficient' => 'I tuoi privilegi per questa pagina non sono sufficienti',
'Delete will delete user from the list' => 'L\'opzione Cancella canceller&agrave; l\'utente dalla lista',
'deleting' => 'cancellazione',
'Done' => 'Fatto',
'User added' => 'Utente aggiunto',
'Add this user' => 'Aggiungi questo utente',
'Click on a link to use the corresponding public subscribe page to add this user:' => 'Clicca su un link per utilizzare la corrispondente pagina di iscrizione pubblica per aggiungere questo utente:',
'Click this link to use the public subscribe page to add this user:' => 'Clicca questo link per utilizzare la pagina di iscrizione pubblica per aggiungere questo utente:',
'Listing user %d to %d' => 'Elenco utenti da %d a %d',
'last sent' => 'ultimo inviato',


);

?>
