<?php
$lan = array(
 'This page can only be called from the commandline' => 'Questa pagina pu&ograve; essere richiamata solo da linea di comando',
 'Getting and Parsing the RSS sources' => 'Ottengo e analizzo le fonti RSS',
 'Rss Errors' => 'Errori RSS',
 'Rss Results' => 'Risultati RSS',
 'Rss Failure report' => 'Rapporto RSS fallito',
 'Parsing' => 'Analisi',
 'ok' => 'ok',
 'failed' => 'fallito',
 'Process Killed by other process' => 'Processo interrotto da un altro processo',
 'items' => 'articoli',
 'new items' => 'nuovi articoli',
'Nothing to do' => 'Niente da fare',
);
?>
