<?php

$lan = array(
'User Click Statistics' => 'Statistiche click utenti',
'User Click Details for a Message' => 'Dettagli click utente per messaggio',
'User Click Details for a URL' => 'Dettagli click utente per URL',
'User Click Details for a URL in a message' => 'Dettagli click utente per URL nel messaggio',
'User Click Details for a message' => 'Dettagli click utente per messaggio',
'Subject' => 'Oggetto',
'Entered' => 'Immesso',
'Sent' => 'Inviato',
'firstclick' => 'primoclick',
'latestclick' => 'ultimoclick',
'clicks' => 'clicks',
'clickrate' => 'frequenzaclick',
'message' => 'messaggio',
'Invalid Request' => 'Richiesta non valida',
'You do not have access to this page' => 'Non sei abilitato ad accedere a questa pagina',
'User Click Details' => 'Dettagli click utente',
'sent' => 'inviato',
'unique clicks' => 'click unici',
);
?>
