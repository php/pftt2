<?php
$lan = array(
  'Creating tables' => 'Creazione tabelle',
  'Initialising table' => 'Inizializzazione tabelle',
  'Table already exists' => 'La tabella esiste gi&agrave;',
  'failed' => 'fallito',
  'ok' => 'ok',
  'failed' => 'fallito',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' => 'Lista di prova. Se lasci disattivata questa lista e aggiungi te stesso ai membri, puoi usarla per provare un messaggio. Se il messaggio &egrave; corretto, puoi inviarlo alle altre liste.',
  'Success' => 'Successo',
  'Tell us about it' => 'Raccontaci',
  'Please make sure to read the file README.security that can be found in the zip file.' => 'Per favore assicurati di leggere il file README.security che trovi nell\'archivio.',
//one sentence: make sure to .. subscribe to announcements
  'Please make sure to' => 'Per favore assicurati di',
  'subscribe to the announcements list' => 'iscriviti alla lista degli annunci',
  'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => 'per assicurarti di effettuare l\'update quando &egrave; disponibile una nuova versione.
    A volte vengono trovati problemi di sicurezza, e questo rende importante l\'aggiornamento. Il traffico di questa lista &egrave; molto basso.',
//one sentence: 'continue with ... phplist setup?
  'Continue with' => 'Continua con',
  'PHPlist Setup' => 'PHPlist Setup',
//one sentence: 'maybe you want to... upgrade... instead?
  'Maybe you want to' => 'Forse vuoi',
  'Upgrade' => 'effettuare l\'upgrade',
  'instead?' => 'invece?',
  'Force Initialisation' => 'Forza l\'inizializzazione',
  '(will erase all data!)' => '(ci&ograve; canceller&agrave; tutti i dati!)',
  'Checklist for Installation' => 'Checklist per l\'installazione',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' => 'Lista di prova. Se lasci disattivata questa lista e aggiungi te stesso ai membri, puoi usarla per provare un messaggio. Se il messaggio &egrave; corretto, puoi inviarlo alle altre liste.',
  'to make sure you are updated when new versions come out. Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => 'per assicurarti di effettuare l\'update quando &egrave; disponibile una nuova versione.
    A volte vengono trovati problemi di sicurezza, e questo rende importante l\'aggiornamento. Il traffico di questa lista &egrave; molto basso.',

  # new in 2.10.1
  'List for testing.' => 'Lista di prova.',



);
?>
