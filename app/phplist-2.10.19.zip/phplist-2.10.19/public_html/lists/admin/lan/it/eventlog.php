<?php
$lan = array(
 'Deleting' => 'Elimino',
 'Done' => 'Fatto',
 'events' => 'Eventi',
 'Listing' => 'Elenco',
 'to' => 'a',
 'Listing 1 to 50' => 'Elenco da 1 a 50',
 'Are you sure you want to delete all events older than 2 months?' => 'Sei sicuro di voler eliminare tutti gli eventi più vecchi di 2 mesi?',
 'Delete all (&gt; 2 months old)' => 'Elimina tutti (&gt; di 2 mesi)',
 'Are you sure you want to delete all events matching this filter?' => 'Sei sicuro di voler eliminare tutti gli eventi che corrispondono ai parametri di questo filtro?',
 'Delete all' => 'Elimina tutti',
 'No events available' => 'Nessun evento disponibile',
 'Filter' => 'Filtro',
 'Exclude filter' => 'Escludi filtro',
 'del' => 'canc', # as in short for delete
 'date' => 'data',
 'message' => 'messaggio', 
 'events' => 'eventi',
 'page' => 'pagina',
);
?>
