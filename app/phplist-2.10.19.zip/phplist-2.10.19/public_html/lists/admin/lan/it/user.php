<?php

$lan = array(
'Delete will delete user and all listmemberships' => 'Cliccando Cancella verr&agrave; cancellato l\'utente e tutta la lista dei membri',
'No Lists' => 'Nessuna Lista',
'update page' => 'aggiorna pagina',
'unsubscribe page' => 'pagina di cancellazione iscrizione',
'History' => 'Storico',
'User Details' => 'Dettagli utente',
'You only have privileges to view this page, not change any of the information' => 'I tuoi privilegi ti consentono soltanto di visualizzare questa pagina, e non di modificarne le informazioni',
'Delete will delete user from the list' => 'Cliccando Cancella l\'utente verr&agrave; cancellato dalla lista',
'User added to group' => 'L\'utente &egrave; stato aggiunto al gruppo',
'User added to list %s' => 'L\'utente &egrave; stato aggiunto alla lista %s',
'Changes saved' => 'Modifiche salvate',
'Deleting' => 'Cancellazione',
'Done' => 'Fatto',
'No such User' => 'Nessun Utente',
'Add a new User' => 'Aggiungi nuovo utente',
'encrypted' => 'criptato',
'Save Changes' => 'Salva modifiche',
'User is blacklisted. No emails will be sent to this user' => 'L\'utente &egrave; nella Blacklist. Nessuna email verr&agrave; inviata a questo utente',
'Mailinglist Membership' => 'Membri Mailinglist',
'Group Membership' => 'Membri dei gruppi',
'Please select the groups this user is a member of' => 'Prego, selezionare i gruppi a cui appartiene questo utente',

# added 2.10.0
'ID' => 'ID',
'Email' => 'Email',
'Is this user confirmed' => 'Questo utente &egrave; confermato',
'Is this user blacklisted' => 'Questo utente appartiene alla Blacklist',
'Number of bounces on this user' => 'Numero di rimbalzi per questo utente',
'Entered' => 'Immesso',
'Last Modified' => 'Ultimo modificato',
'Unique ID for User' => 'ID unico per utente',
'Send this user HTML emails' => 'Invia email in HTML a questo utente',
'Which page was used to subscribe' => 'Quale pagina &egrave; stata utilizzata per l\'iscrizione',
'RSS Frequency' => 'Frequenza RSS',
'Last time password was changed' => 'Ultima volta che la password &egrave; stata cambiata',
'Is this account disabled?' => 'Questo account &egrave; disabilitato?',
'Additional data' => 'Dati aggiuntivi',
'Foreign Key' => 'Chiave esterna',

'Error adding user, please check that the user exists' => 'Errore nell\'aggiungere questo utente, prego controllare che l\'utente esista',

);
?>
