<?php

$lan = array(
  'Number of %s rules: %d' => 'Numero di %s regole: %d',
  'active' => 'attivo',
  'candidate' => 'candidato',
  'Bounce Regular Expressions' => 'Espressioni regolari del rimbalzo',
  'rule' => 'regola',
  'expression' => 'espressione',
  'action' => 'azione',
  '#bncs' => '#bncs',
  'tag' => 'tag',
  'order' => 'ordina',
  'del' => 'canc',
  'with tagged rules: ' => 'con regole taggate: ',
  'delete' => 'cancella',
  'make inactive' => 'rendi inattivo',
  'Save Changes' => 'Salva modifiche',
  'add a new rule' => 'aggiungi nuova regola',
  'Regular Expression' => 'Espressione Regolare',
  'Memo for this rule' => 'Memo per questa regola',
  'Add new Rule' => 'Aggiungi nuova regola',
  'make active' => 'rendi attivo',
  'No Rules found' => 'Nessuna regola trovata',
  'match' => 'abbina',
  'That rule exists already' => 'Questa regola esiste gi&agrave;',
);

?>
