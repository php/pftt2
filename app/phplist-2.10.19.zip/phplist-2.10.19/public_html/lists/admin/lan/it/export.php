<?php




$lan = array(
  "Export" => "Esporta",
  "ExportOnList" => "PHPList Esporta su %s da %s a %s (%s).csv",
  "ExportFromval" => "PHPList Esporta da %s a %s (%s).csv",
  "ListMembership" => "Elenca membri",
  "ExportOn" => "<h4>Esporta utenti su %s</h4>",
  "DateFrom" => "Data Da:",
  "DateTo" => "Data A:",
  "DateToUsed" => "Quali date bisogna usare:",
  "WhenSignedUp" => "Quando si sono iscritti",
  "WhenRecordChanged" => "Quando il record &egrave; stato modificato",
  "SelectColToIn" => "Seleziona le colonne da includere nell\'esportazione",

  # new in 2.10.1
  'When they subscribed to' => 'Quando si sono iscritti a',
);
?>
