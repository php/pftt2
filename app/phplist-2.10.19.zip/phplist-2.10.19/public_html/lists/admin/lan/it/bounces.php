<?php
$lan = array(
  'done' => 'Fatto',
  'bounces' => 'rimbalzi',
  'to' => 'a',
  'listing' => 'Elenco',
  'are you sure you want to delete all bounces older than 2 months' => 'sei sicuro di voler cancellare tutti i rimbalzi pi&ugrave; vecchi di 2 mesi?',
   'delete all processed (&gt; 2 months old)' => 'cancella tutti quelli processati (&gt; di 2 mesi)',
 'are you sure you want to delete all bounces,\\n even the ones that have not been processed' => 'sei sicuro di voler cancellare tutti i rimbalzi,\\n anche quelli non ancora processati?',
  'delete all' => 'Cancella tutto',
   'are you sure you want to reset all counters' => 'Sei sicuro di voler resettare tutti i conteggi',
  'reset bounces' => 'Azzera rimbalzi',
  'delete' => 'Cancella',
  'deleting' => 'Cancellazione',
  'no unprocessed bounces available' => 'Nessun rimbalzo non processato disponibile',
  'message' => 'Messaggio',
  'user' => 'Utente',
  'date' => 'Data',
  'show' => 'Mostra',
  'unknown' => 'Sconosciuto',
  'system message' => 'Messaggio di sistema',
  
  ### new in 2.9.5
    'are you sure you want to delete all unidentified bounces older than 2 months' => 'sei sicuro di voler cancellare tutti i rimbalzi non identificati pi&ugrave; vecchi di due mesi',
  'delete all unidentified (&gt; 2 months old)'  => 'cancella tutti i non identificati (&gt; di 2 mesi)', 
);
?>
