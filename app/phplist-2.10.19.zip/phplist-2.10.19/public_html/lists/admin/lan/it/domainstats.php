<?php

$lan = array(
  'Top 50 domains with more than 5 emails' => 'Primi 50 domini con pi&ugrave; di 5 email',
  'num' => 'num',
);
?>
