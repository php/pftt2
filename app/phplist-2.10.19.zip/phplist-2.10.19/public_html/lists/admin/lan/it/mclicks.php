<?php

$lan = array(
'Message Click Statistics' => 'Statistiche dei click sul messaggio',
'firstclick' => 'firstclick',
'latestclick' => 'latestclick',
'clicks' => 'clicks',
'Click Details for a Message' => 'Dettagli dei click per un Messaggio',
'Subject' => 'Oggetto',
'Entered' => 'Inserito',
'sent' => 'Inviato',
'clickrate' => 'Clickrate',
'unique clicks' => 'click unici',
'unique clickrate' => 'clickrate unico',
'who' => 'chi',
'view users' => 'vedi utenti',
'Select Message to view' => 'Selezione un messaggio da visualizzare',
'Available Messages' => 'Messaggi Disponibili',
'You do not have access to this page' => 'Non hai accesso a queta pagina',

# for 2.10.2
'there are currently no messages to view' => 'Al momento non ci sono messaggi da visualizzare',
);
?>