<?php

$lan = array(
 'Updating the regular expression of this rule caused an Sql conflict<br/>This is probably because there is already a rule like that. Do you want to delete this rule instead?' => 'L\'aggiornamento dell\'espressione regolare per questa regola ha causato un conflitto SQL<br/>&Egrave; possibile che esista gi&agrave; una regola con le stesse caratteristiche. Vuoi cancellare questa regola??',
  'Yes' => 'S&igrave;',
  'No' => 'No',
  'back to list of bounce rules' => 'Torna alla lista delle regole',
  'Regular Expression' => 'Espressione regolare',
  'Created By' => 'Creato da',
  'Action' => 'Azione',
  'Status' => 'Stato',
  'Select Status' => 'Seleziona stato',
  'Memo for this rule' => 'Memo per questa regola',
  'Save Changes' => 'Salva cambiamenti',
  'related bounces' => 'rimbalzi collegati',
  'no related bounces found' => 'non sono stati trovati rimbalzi collegati',
  'and more, %d in total' => 'e ancora, %d in totale',
);

?>
