<?php

$lan = array(
'Message Click Statistics' => 'Bericht Klik Statistieken',
'firstclick' => 'eersteklik',
'latestclick' => 'laatsteklik',
'clicks' => 'klikken',
'Click Details for a Message' => 'Klik op Details voor een bericht',
'Subject' => 'Onderwerp',
'Entered' => 'Binnengegaan',
'sent' => 'Verzonden',
'clickrate' => 'Klikrate',
'unique clicks' => 'unieke klikken',
'unique clickrate' => 'unieke klikrate',
'who' => 'wie',
'view users' => 'bekijk gebruikers',
'Select Message to view' => 'Selecteer het te bekijken bericht',
'Available Messages' => 'Beschikbare berichten',
'You do not have access to this page' => 'Je hebt geen toegang tot deze pagina',

# for 2.10.2
'there are currently no messages to view' => 'Er zijn momenteel geen berichten te bekijken',
);
?>