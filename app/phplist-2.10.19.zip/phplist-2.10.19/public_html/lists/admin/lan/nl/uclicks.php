<?php

$lan = array(
'Click Details for a URL' => 'Klik Details voor een URL',
'URL Click Statistics' => 'URL Klik Statistieken',
'firstclick' => 'eersteklik',
'latestclick' => 'laatsteklik',
'clicks' => 'klikken',
'clickrate' => 'klikrate',
'clicks' => 'klikken',
'msg' => 'ber',
'who' => 'wie',
'view users' => 'bekijk gebruikers',
'You do not have access to this page' => 'Je hebt geen toegang tot deze pagina',
'Select URL to view' => 'Selecteer URL om te bekijken',
'Available URLs' => 'Beschikbare URLs',
'sent' => 'verzonden',
'unique clicks' => 'unieke klikken',
'unique clickrate' => 'unieke klikrate',
);
?>