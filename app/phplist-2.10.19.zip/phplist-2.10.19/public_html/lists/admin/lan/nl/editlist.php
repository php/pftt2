<?php
$lan = array(
 'You do not have enough priviliges to view this page' => 'U heeft niet de nodige rechten om de pagina te betreden',
 'Members of this list' => 'Leden van deze lijst',
 'Record Saved' => 'Raport opgeslagen',
 'List name' => 'Naam v/d lijst',
 'Check this box to make this list active (listed)' => 'Selecteer deze box om de lijst actef te maken (vermeld)',
 'Order for listing' => 'Volgorde voor vermelding',
 'Subject Prefix' => 'Onderwerp Voorvoegsel',
 'Owner' => 'Eigenaar',
 'RSS Source' => 'RSS Bron',
 'List Description' => 'Vermeld beschrijving',
 'View Items' => 'Bekijk Items',
 'Save' => 'Sla op',
 'validate' => 'valideer',
);
?>
