<?php

$lan = array(
'User Click Statistics' => 'User-Klick-Statistik',
'User Click Details for a Message' => 'User-Klicks f&uuml;r eine Nachricht',
'User Click Details for a URL' => 'User-Klicks f&uuml;r eine URL',
'User Click Details for a URL in a message' => 'User-Klicks f&uuml;r eine URL in einer Nachricht',
'User Click Details for a message' => 'User-Klicks f&uuml;r eine Nachricht',
'Subject' => 'Betreff',
'Entered' => 'Eingegeben',
'Sent' => 'Gesendet',
'firstclick' => 'Erster Klick',
'latestclick' => 'Letzter Klick',
'clicks' => 'Klicks',
'clickrate' => 'Klickrate',
'message' => 'Nachricht',
'Invalid Request' => 'Ung&uuml;ltiger Request',
'You do not have access to this page' => 'Sie haben keine Zugriffsberechtigung f&uuml;r diese Seite.',
'User Click Details' => 'User-Clicks',
'sent' => 'Gesende',
'unique clicks' => 'Unique Clicks',
);
?>