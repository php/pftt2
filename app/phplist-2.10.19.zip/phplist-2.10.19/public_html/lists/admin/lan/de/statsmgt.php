<?php

$lan = array(
  'View Clicks by URL' => 'Klicks pro URL anzeigen',
  'View Clicks by Message' => 'Klicks pro Nachricht anzeigen',

 # new in 2.9.5
  'View Opens by Message' => 'Ge&ouml;ffnete Nachrichten anzeigen',
  'Domain Statistics' => 'Domain-Statistik',
);
?>