<?php

# language stuff for login is in the common file

$lan = array(
);
?>