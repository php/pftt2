<?php

$lan = array(
  'existingusers' => "Existierende Abonnenten",
  'nonexistingusers' => "Nicht existierende Abonnenten",
  'existcheckintro' => 'Seite um die Existenz von Abonnenten in der Datenbank zu pr&uuml;fen.',
  'whatistype' => '<b>Datenbankfeld</b>',
  "foreignkey" => "Fremdschl&uuml;ssel",
  "email" => "E-Mail-Adresse",
  "continue" => "Pr&uuml;fen",
  "pastevalues" => "<br /><b>Werte (1 Wert pro Zeile)</b>",
);

?>