<?php
$lan = array(
 'Deleting' => 'L&ouml;sche',
 'Done' => 'Erledigt',
 'RSS source' => 'RSS-Quellcode',
 'delete' => 'Liste l&ouml;schen',
 'n/a' => 'n/a',
 'No lists available, use Add to add one' => 'Keine Listen vorhanden.',
 'No' => 'Nr.',
 'Name' => 'Name',
 'Order' => 'Position',
 'Functions' => 'Funktionen',
 'Active' => 'Aktiv',
 'Owner' => 'Besitzer',
 'Save Changes' => 'Speichern',
 'Add a list' => 'Neue Liste',
 'members' => 'Abonnenten',
 '(view items)' => '(Elemente anzeigen)',
 'edit' => 'Liste bearbeiten',
 'view members' => 'Abonnenten bearbeiten',
);
?>
