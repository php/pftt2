<?php
$lan = array(
  'Creating tables' => 'Erzeuge Tabellen',
  'Initialising table' => 'Initialisiere Tabelle',
  'Table already exists' => 'Tabelle existiert bereits',
  'failed' => 'fehlgeschlagen',
  'ok' => 'OK',
  'failed' => 'fehlgeschlagen<br />',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' =>
  	'Test-Liste. Wenn Sie diese Liste nicht aktivieren und sich selbst als Abonnent eintragen, dann k&ouml;nnen Sie diese Liste benutzen,
	um eine Nachricht zu testen. Falls die Nachricht Ihren Vorstellungen entspricht, k&ouml;nnen Sie sie an andere Listen versenden.',
  'Success' => 'Erfolg',
  'Tell us about it' => 'Sagen Sie es uns.',
  'Please make sure to read the file README.security that can be found in the zip file.' =>
  	'Bitte lesen Sie die Datei README.security, die im ZIP-Archiv enthalten ist.',
//one sentence: make sure to .. subscribe to announcements
  'Please make sure to' => 'Bitte abonnieren Sie unseren',
  'subscribe to the announcements list' => 'Newsletter',
  'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade.
	Traffic on the list is very low.' =>
	'um &uuml;ber Updates informiert zu werden.
    Updates sind wichtig, weil sie allf&auml;llige Sicherheitsprobleme beheben.
	Sie werden dadurch nur sehr wenige Mails erhalten.',
//one sentence: 'continue with ... phplist setup?
  'Continue with' => 'Weiter mit',
  'PHPlist Setup' => 'PHPlist Setup',
//one sentence: 'maybe you want to... upgrade... instead?
  'Maybe you want to' => 'M&ouml;chten Sie stattdessen ein',
  'Upgrade' => 'Datenbank-Upgrade',
  'instead?' => 'durchf&uuml;hren?<br />&nbsp;&nbsp;',
  'Force Initialisation' => 'Initialisierung erzwingen',
  '(will erase all data!)' => '(Dadurch werden s&auml;mtliche Daten in der Datenbank unwiederruflich gel&ouml;scht!)',
  'Checklist for Installation' => 'Checkliste f&uuml;r die Installation',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' =>
  	'Test-Liste. Wenn Sie diese Liste nicht aktivieren und sich selbst als Abonnent eintragen, dann k&ouml;nnen Sie diese Liste benutzen,
	um eine Nachricht zu testen. Falls die Nachricht Ihren Vorstellungen entspricht, k&ouml;nnen Sie sie an andere Listen versenden.',
  'to make sure you are updated when new versions come out. Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' =>
  	'um &uuml;ber Updates informiert zu werden.
    Updates sind wichtig, weil sie allf&auml;llige Sicherheitsprobleme beheben.
	Sie werden dadurch nur sehr wenige Mails erhalten.',
);
?>