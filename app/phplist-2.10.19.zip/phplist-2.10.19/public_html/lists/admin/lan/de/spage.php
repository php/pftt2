<?php 
$lan = array(

  'subscribe pages' => 'ID',
  'deleted' => 'Gel&ouml;scht',
  'add_new' => 'Neue Anmeldeseite',
  'title' => 'Titel',
  'edit' => 'Bearbeiten',
  'del' => 'L&ouml;schen',
  'view' => 'Anzeigen',
  'status' => 'Status',
  'owner' => 'Besitzer',
  'default' => 'Default',
  'active' => 'aktiv',
  'not active' => 'inaktiv',

);
?>