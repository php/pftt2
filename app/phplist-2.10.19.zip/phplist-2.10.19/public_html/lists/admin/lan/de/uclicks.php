<?php

$lan = array(
'Click Details for a URL' => 'Klick-Details f&uuml;r eine URL',
'URL Click Statistics' => 'URL-Klick-Statistik',
'firstclick' => 'Erster Klick',
'latestclick' => 'Letzter Klick',
'clicks' => 'Klicks',
'clickrate' => 'Klickrate',
'clicks' => 'Klicks',
'msg' => 'Nachricht',
'who' => 'Wer',
'view users' => 'Benutzer anzeigen',
'You do not have access to this page' => 'Sie haben keine Zugrifssberechtigung f&uuml;r diese Seite.',
'Select URL to view' => 'URL ausw&auml;hlen',
'Available URLs' => 'Verf&uuml;gbare URLs',
'sent' => 'Gesendet',
'unique clicks' => 'Unique Clicks',
'unique clickrate' => 'Unique Clickrate',
);
?>