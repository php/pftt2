<?php
$lan = array(
 'you only have privileges to view this page, not change any of the information'
 	=> 'Aufgrund Ihrer Zugriffsrechte d&uuml;rfen Sie diese Seite zwar sehen, aber keine Daten &auml;ndern.',
 'no such User' => 'Abonnent existiert nicht',
 'view' => 'Anzeigen',
 'user is Blacklisted since' => 'Abonnent steht auf der Blacklist seit',
 'messages sent to this user' => 'Nachrichten, die an diesen Abonnenten gesendet wurden',
 'are you sure you want to delete this user from the blacklist'
 	=> 'Sind Sie sicher, dass Sie diesen Abonnenten von der Blacklist l&ouml;schen wollen',
 'it should only be done with explicit permission from this user'
 	=> 'Sie sollten dies nur mit ausdr&uuml;cklicher Zustimmung dieses Abonnenten tun',
 'remove User from Blacklist'
 	=> 'Abonnente von Blacklist l&ouml;schen',
 'user subscription history' => '<br />History der abonnierten Listen',
 'no details found' => 'Keine Details vorhanden',
 'messages sent to this user' => 'Nachrichten wurden bisher an diesen Abonnenten gesendet',
 'ip' => 'IP',
 'date' => 'Datum',
 'summary' => 'Zusammenfassung',
 'detail' => 'Details',
 'info' => 'Info',
 'blacklist info' => 'Blacklist-Info',
 'value' => 'Wert',
 'subscription history' => 'Eintrag', 
 'clicks' => 'Klicks',

 # new in 2.9.5
  'viewed' => 'betrachtet',
  'responsetime' => 'Antwortzeit',
  'average' => 'Durchschnitt',
 
);
?>