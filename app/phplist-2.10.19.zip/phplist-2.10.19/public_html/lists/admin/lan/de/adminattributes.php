<?php 
$lan = array(
  'SaveChanges' => 'Speichern',
  'NameNotEmpty' => 'Name darf nicht leer sein:',
  'NameNotUnique' => 'Name ist nicht eindeutig',
  'ExistingAttr' => 'Bestehende Attribute:',
  'NoAttrYet' => 'Es wurden noch keine Attribute definiert.<br /><br />',
  'Attribute' => 'Attribut ID ',
  'Delete' => 'L&ouml;schen',
  'Name' => 'Name',
  'Type' => 'Typ',
  'DValue' => 'Vorgabewert',
  'OrderListing' => 'Position',
  'IsAttrRequired' => 'Eingabe zwingend (Pflichtfeld)',
  'AddAttr' => 'Neues Attribut',
);
?>