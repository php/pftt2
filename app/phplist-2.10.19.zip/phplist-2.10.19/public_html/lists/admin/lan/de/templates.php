<?php
$lan = array(
  "Deleting" => "L&ouml;sche",
  "Done" => "Abgeschlossen",
  "No template have been defined" => "Keine Templates vorhanden",
  "Existing templates" => "Name",
  "View" => "Anzeigen",
  "Edit" => "Bearbeiten",
  'delete' => 'L&ouml;schen',
  "Add new Template" => "Neues Template",
  'ID' => 'ID',
  'Default' => 'Default',
  '# imgs' => '# Bilder',

);
?>