<?php

$lan = array(
  'users' => 'Abonnenten',
  'control' => '<br /><b>Funktionen</b>',
  'userattributes' => 'Attribute',
  'reconcile' => 'Abonnenten bereinigen',
  'check' => 'Abonnenten pr&uuml;fen',
  'import' => 'Abonnenten importieren',
  'export' => 'Abonnenten exportieren',
);
