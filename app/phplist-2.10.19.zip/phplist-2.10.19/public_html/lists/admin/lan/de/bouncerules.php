<?php

$lan = array(
  'Number of %s rules: %d' => 'Anzahl %s Regeln: %d',
  'active' => 'Aktive Regeln',
  'candidate' => 'Regel-Kandidaten',
  'Bounce Regular Expressions' => 'Regel',
  'rule' => 'Regel',
  'expression' => 'Regular Expression',
  'action' => 'Massnahme',
  '#bncs' => '#bncs',
  'tag' => 'Markiert',
  'order' => 'Position',
  'del' => 'L&ouml;schen',
  'with tagged rules: ' => '<h4>Aktionen f�r markierte Regeln</h4>',
  'delete' => 'L&ouml;schen',
  'make inactive' => 'Deaktivieren',
  'Save Changes' => 'Speichern',
  'add a new rule' => '<h4>Neue Regel anlegen</h4>',
  'Regular Expression' => 'Regular Expression',
  'Memo for this rule' => 'Kommentar zu dieser Regel',
  'Add new Rule' => 'Regel anlegen',
  'make active' => 'aktivieren',
  'No Rules found' => '<br /><strong>Keine Regeln gefunden</strong>',
  'match' => 'match',
  'That rule exists already' => '<span class="error">Es existiert bereits eine Regel mit dieser Regular Expression.</span>',
);

?>
