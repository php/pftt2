<?php 
$lan = array(

  'initialise_database' => 'Datenbank initialisieren',
  'change_admin_passwd' => 'Administrator-Passwort &auml;ndern',
  'config_gral_values' => 'Konfiguration vornehmen',
  'config_attribs' => 'Attribute definieren',
  'create_lists' => 'Listen anlegen',
  'create_subscr_pages' => 'Anmeldeseiten anlegen',
  'go_there' => 'Gehe zu',

);
?>