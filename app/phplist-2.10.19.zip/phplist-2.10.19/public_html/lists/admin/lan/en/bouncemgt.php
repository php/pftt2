<?php

$lan = array(
  'List Bounce Rules' => 'List Bounce Rules',
  'rulesexistwarning' => 'You have already defined bounce rules in your system. 
    Be careful with generating new ones, because these may interfere with the ones that exist.',
  'norulesyet' => 'You currently have no rules defined. 
    You can click "Generate Bounce Rules" in order to auto-generate rules from your existing bounces. 
    This will results in a lot of rules which you will need to review and activate. 
    It will however, not catch every single bounce, so it will be necessary to add new rules over 
    time when new bounces come in.',
  'Generate Bounce Rules' => 'Generate Bounce Rules',
  'Check Current Bounce Rules' => 'Check Current Bounce Rules',
);

?>
