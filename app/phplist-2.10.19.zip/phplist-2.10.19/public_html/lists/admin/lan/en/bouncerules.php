<?php

$lan = array(
  'Number of %s rules: %d' => 'Number of %s rules: %d',
  'active' => 'active',
  'candidate' => 'candidate',
  'Bounce Regular Expressions' => 'Bounce Regular Expressions',
  'rule' => 'rule',
  'expression' => 'expression',
  'action' => 'action',
  '#bncs' => '#bncs',
  'tag' => 'tag',
  'order' => 'order',
  'del' => 'del',
  'with tagged rules: ' => 'with tagged rules: ',
  'delete' => 'delete',
  'make inactive' => 'make inactive',
  'Save Changes' => 'Save Changes',
  'add a new rule' => 'add a new rule',
  'Regular Expression' => 'Regular Expression',
  'Memo for this rule' => 'Memo for this rule',
  'Add new Rule' => 'Add new Rule',
  'make active' => 'make active',
  'No Rules found' => 'No Rules found',
  'match' => 'match',
  'That rule exists already' => 'That rule exists already',
);

?>
