<?php

$lan = array(
  'You do not have access to this page' => 'You do not have access to this page',
  'Select Message to view' => 'Select Message to view',
  'Available Messages' => 'Available Messages',
  'views' => 'views',
  'rate' => 'rate',
  'View Details for a Message' => 'View Details for a Message',
  'Subject' => 'Subject',
  'Entered' => 'Entered',
  'Message Open Statistics' => 'Message Open Statistics',
  'Listing user %d to %d' => 'Listing user %d to %d',
  'Entries' => 'Entries',
  'firstview' => 'firstview',
  'lastview' => 'lastview',
  'views' => 'views',
  'responsetime' => 'responsetime',
  'sec' => 'sec',

  # for 2.10.2
'there are currently no messages to view' => 'There are currently no messages to view',
);

?>
