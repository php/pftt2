<?php

$lan = array(
'Delete will delete user and all listmemberships' => 'Delete will delete user and all listmemberships',
'%s users apply' => '%s users apply',
'Users marked <span class="highlight">red</span> are unconfirmed' => 'Users marked <span class="highlight">red</span> are unconfirmed',
'Show only unconfirmed users' => 'Show only unconfirmed users',
'Show only blacklisted users' => 'Show only blacklisted users',
'email' => 'email',
'bouncecount' => 'bouncecount',
'entered' => 'entered',
'modified' => 'modified',
'foreignkey' => 'foreignkey',
'Sort by' => 'Sort by',
'desc' => 'desc',
'asc' => 'asc',
'Go' => 'Go',
'Find a user' => 'Find a user',
'Email' => 'Email',
'Foreign Key' => 'Foreign Key',
'reset' => 'reset',
'Download all users as CSV file' => 'Download all users as CSV file',
'Add a User' => 'Add a User',
'confirmed' => 'confirmed',
'bl l' => 'bl l', # as in black listed (but then as short as possible)
'del' => 'del',
'key' => 'key',
'msgs' => 'msgs', # meaning messages
'rss' => 'rss',
'rss freq' => 'rss freq', # meaning rss frequency
'bncs' => 'bncs', # meaning bounces
'No users apply' => 'No users apply',
'Your privileges for this page are insufficient' => 'Your privileges for this page are insufficient',
'Delete will delete user from the list' => 'Delete will delete user from the list',
'deleting' => 'deleting',
'Done' => 'Done',
'User added' => 'User added',
'Add this user' => 'Add this user',
'Click on a link to use the corresponding public subscribe page to add this user:' => 'Click on a link to use the corresponding public subscribe page to add this user:',
'Click this link to use the public subscribe page to add this user:' => 'Click this link to use the public subscribe page to add this user:',
'Listing user %d to %d' => 'Listing user %d to %d',
'last sent' => 'last sent',


);

?>