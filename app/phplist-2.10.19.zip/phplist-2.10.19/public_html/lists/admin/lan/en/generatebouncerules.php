<?php

$lan = array(
  'Process Next Batch' => 'Process Next Batch',
  'Process Killed by other process' => 'Process Killed by other process',
  'Hmm, duplicate entry, ' => 'Hmm, duplicate entry, ',
  'new rules found' => 'new rules found',
  'bounces not matched' => 'bounces not matched',
  'bounces matched to existing rules' => 'bounces matched to existing rules',
);

?>
