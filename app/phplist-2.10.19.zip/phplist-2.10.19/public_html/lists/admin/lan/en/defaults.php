<?php 
$lan = array(

  "loading" => "Loading",
  "done" => "Done",
  "name_empty" => "Name cannot be empty:",
  "name_not_unique" => "Name is not unique enough",
  "continue" => "Continue",
  'add' => 'Add',

);
?>