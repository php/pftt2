<?php




$lan = array(
  "Export" => "Export",
  "ExportOnList" => "PHPList Export on %s from %s to %s (%s).csv",
  "ExportFromval" => "PHPList Export from %s to %s (%s).csv",
  "ListMembership" => "List Membership",
  "ExportOn" => "<h4>Export users on %s</h4>",
  "DateFrom" => "Date From:",
  "DateTo" => "Date To:",
  "DateToUsed" => "What date needs to be used:",
  "WhenSignedUp" => "When they signed up",
  "WhenRecordChanged" => "When the record was changed",
  "SelectColToIn" => "Select the columns to include in the export",

  # new in 2.10.1
  'When they subscribed to' => 'When they subscribed to',
);
?>