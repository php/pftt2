<?php

$lan = array(
  'PHPList Users' => 'PHPList Users',
  'on' => 'on', # as in Member of a list (user A on list B)
  'List Membership' => 'List Membership',
  'No Lists' => 'No Lists',
);

?>