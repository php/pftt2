<?php
$lan = array(
 'Deleting' => 'Deleting',
 'Done' => 'Done',
 'RSS source' => 'RSS source',
 'delete' => 'delete',
 'n/a' => 'n/a',
 'No lists available, use Add to add one' => 'No lists available, use Add to add one',
 'No' => 'No',
 'Name' => 'Name',
 'Order' => 'Order',
 'Functions' => 'Functions',
 'Active' => 'Active',
 'Owner' => 'Owner',
 'Save Changes' => 'Save Changes',
 'Add a list' => 'Add a list',
 'members' => 'Members',
 '(view items)' => '(View Items)',
 'edit' => 'edit',
 'view members' => 'view members',
);
?>
