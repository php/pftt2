<?php

$lan = array(
'Click Details for a URL' => 'Click Details for a URL',
'URL Click Statistics' => 'URL Click Statistics',
'firstclick' => 'firstclick',
'latestclick' => 'latestclick',
'clicks' => 'clicks',
'clickrate' => 'clickrate',
'clicks' => 'clicks',
'msg' => 'msg',
'who' => 'who',
'view users' => 'view users',
'You do not have access to this page' => 'You do not have access to this page',
'Select URL to view' => 'Select URL to view',
'Available URLs' => 'Available URLs',
'sent' => 'sent',
'unique clicks' => 'unique clicks',
'unique clickrate' => 'unique clickrate',
);
?>