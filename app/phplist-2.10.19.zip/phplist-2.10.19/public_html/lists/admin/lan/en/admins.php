<?php

$lan = array(
'Add new admin' => 'Add new admin',
'Administrators' => 'Administrators',
'Find an admin' => 'Find an admin',
'Administrators' => 'Administrators',
'Show' => 'Show',
'Show' => 'Show',
'Show' => 'Show',
'Add new admin' => 'Add new admin',
'Import list of admins' => 'Import list of admins',
'Deleting' => 'Deleting',
'Done' => 'Done',
'Admin added' => 'Admin added',
'Listing admin' => 'Listing admin',
'Listing admin 1 to 50' => 'Listing admin 1 to 50',
'found' => 'found',

);

?>