<?php

$lan = array(
  'Please indicate how often you want to receive messages' => 'Please indicate how often you want to receive messages',
  'Email is blacklisted, so request for confirmation has been sent.' => 'User is blacklisted, so request for confirmation has been sent.',
  'If user confirms subscription, they will be removed from the blacklist.' => 'If user confirms subscription, they will be removed from the blacklist.',
//  'YouAreBlacklisted' => 'Your email is listed in our "Black List", which means that you have requested us never to send you any more newsletters. <br/>
//The only email this system will send is the request for confirmation and if you click the link in the email that you will receive, you will be removed from our blacklist, and continue to receive our newsletters.'
);

?>