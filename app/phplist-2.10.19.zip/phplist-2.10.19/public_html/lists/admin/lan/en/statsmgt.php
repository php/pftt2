<?php

$lan = array(
  'View Clicks by URL' => 'View Clicks by URL',
  'View Clicks by Message' => 'View Clicks by Message',

 # new in 2.9.5
  'View Opens by Message' => 'View Opens by Message',
  'Domain Statistics' => 'Domain Statistics',
);
?>