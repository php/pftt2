<?php 
$lan = array(
  'SaveChanges' => 'Save Changes',
  'NameNotEmpty' => 'Name cannot be empty:',
  'NameNotUnique' => 'Name is not unique enough',
  'ExistingAttr' => 'Existing attributes:',
  'NoAttrYet' => 'No Attributes have been defined yet<br/>',
  'Attribute' => 'Attribute:',
  'Delete' => 'Delete',
  'Name' => 'Name:',
  'Type' => 'Type:',
  'DValue' => 'Default Value:',
  'OrderListing' => 'Order of Listing:',
  'IsAttrRequired' => 'Is this attribute required?:',
  'AddAttr' => 'Add a new Attribute:',
);
?>