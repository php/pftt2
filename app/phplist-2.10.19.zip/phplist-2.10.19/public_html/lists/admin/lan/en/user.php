<?php

$lan = array(
'Delete will delete user and all listmemberships' => 'Delete will delete user and all listmemberships',
'No Lists' => 'No Lists',
'update page' => 'update page',
'unsubscribe page' => 'unsubscribe page',
'History' => 'History',
'User Details' => 'User Details',
'You only have privileges to view this page, not change any of the information' => 'You only have privileges to view this page, not change any of the information',
'Delete will delete user from the list' => 'Delete will delete user from the list',
'User added to group' => 'User added to group',
'User added to list %s' => 'User added to list %s',
'Changes saved' => 'Changes saved',
'Deleting' => 'Deleting',
'Done' => 'Done',
'No such User' => 'No such User',
'Add a new User' => 'Add a new User',
'encrypted' => 'encrypted',
'Save Changes' => 'Save Changes',
'User is blacklisted. No emails will be sent to this user' => 'User is blacklisted. No emails will be sent to this user',
'Mailinglist Membership' => 'Mailinglist Membership',
'Group Membership' => 'Group Membership',
'Please select the groups this user is a member of' => 'Please select the groups this user is a member of',

# added 2.10.0
'ID' => 'ID',
'Email' => 'Email',
'Is this user confirmed' => 'Is this user confirmed',
'Is this user blacklisted' => 'Is this user blacklisted',
'Number of bounces on this user' => 'Number of bounces on this user',
'Entered' => 'Entered',
'Last Modified' => 'Last Modified',
'Unique ID for User' => 'Unique ID for User',
'Send this user HTML emails' => 'Send this user HTML emails',
'Which page was used to subscribe' => 'Which page was used to subscribe',
'RSS Frequency' => 'RSS Frequency',
'Last time password was changed' => 'Last time password was changed',
'Is this account disabled?' => 'Is this account disabled?',
'Additional data' => 'Additional data',
'Foreign Key' => 'Foreign Key',

'Error adding user, please check that the user exists' => 'Error adding user, please check that the user exists',

);
?>