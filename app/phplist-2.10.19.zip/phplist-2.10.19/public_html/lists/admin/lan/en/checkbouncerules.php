<?php

$lan = array(
  'Process Next %d' => 'Process Next %d',
  'No match' => 'No match',
  'bounces did not match any current active rule' => 'bounces did not match any current active rule',
  'bounce matched current active rules' => 'bounce matched current active rules',
);
?>
