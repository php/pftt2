<?php

$lan = array(
  'existingusers' => "Existing Users",
  'nonexistingusers' => "Non Existing Users",
  'existcheckintro' => 'Page to check the existance of users in the database',
  'whatistype' => 'What is the type of information you want to check',
  "foreignkey" => "Foreign Key",
  "email" => "Email",
  "continue" => "Continue",
  "pastevalues" => "Paste the values to check in this box, one per line",


  # new in 2.10.1
  'key' => 'key',
  'passwd' => 'passwd',
);

?>