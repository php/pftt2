<?php
$lan = array(
  "Deleting" => "Deleting",
  "Done" => "Done",
  "No template have been defined" => "No template have been defined",
  "Existing templates" => "Existing templates",
  "View" => "View",
  "Edit" => "Edit",
  'delete' => 'Delete',
  "Add new Template" => "Add new Template",
  'ID' => 'ID',
  'Default' => 'Default',
  '# imgs' => '# imgs',

);
?>