<?php
$lan = array(
 'This page can only be called from the commandline' => 'This page can only be called from the commandline',
 'Getting and Parsing the RSS sources' => 'Getting and Parsing the RSS sources',
 'Rss Errors' => 'Rss Errors',
 'Rss Results' => 'Rss Results',
 'Rss Failure report' => 'Rss Failure report',
 'Parsing' => 'Parsing',
 'ok' => 'ok',
 'failed' => 'failed',
 'Process Killed by other process' => 'Process Killed by other process',
 'items' => 'items',
 'new items' => 'new items',
'Nothing to do' => 'Nothing to do',
);
?>
