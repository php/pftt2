<?php
$lan = array(

  'initialise_database' => 'Initialise Database',
  'change_admin_passwd' => 'Change Admin Password',
  'config_gral_values' => 'Configure General Values',
  'config_attribs' => 'Configure Attributes',
  'create_lists' => 'Create Lists',
  'create_subscr_pages' => 'Create Subscribe Pages',
  'go_there' => 'Go there',

);
?>