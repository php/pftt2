<?php

$lan = array(
  'Updating the regular expression of this rule caused an Sql conflict<br/>This is probably because there is already a rule like that. Do you want to delete this rule instead?' => 'Updating the regular expression of this rule caused an Sql conflict<br/>This is probably because there is already a rule like that. Do you want to delete this rule instead?',
  'Yes' => 'Yes',
  'No' => 'No',
  'back to list of bounce rules' => 'back to list of bounce rules',
  'Regular Expression' => 'Regular Expression',
  'Created By' => 'Created By',
  'Action' => 'Action',
  'Status' => 'Status',
  'Select Status' => 'Select Status',
  'Memo for this rule' => 'Memo for this rule',
  'Save Changes' => 'Save Changes',
  'related bounces' => 'related bounces',
  'no related bounces found' => 'no related bounces found',
  'and more, %d in total' => 'and more, %d in total',
);

?>
