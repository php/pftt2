<?php

$lan = array(
'User Click Statistics' => 'User Click Statistics',
'User Click Details for a Message' => 'User Click Details for a Message',
'User Click Details for a URL' => 'User Click Details for a URL',
'User Click Details for a URL in a message' => 'User Click Details for a URL in a message',
'User Click Details for a message' => 'User Click Details for a message',
'Subject' => 'Subject',
'Entered' => 'Entered',
'Sent' => 'Sent',
'firstclick' => 'firstclick',
'latestclick' => 'latestclick',
'clicks' => 'clicks',
'clickrate' => 'clickrate',
'message' => 'message',
'Invalid Request' => 'Invalid Request',
'You do not have access to this page' => 'You do not have access to this page',
'User Click Details' => 'User Click Details',
'sent' => 'sent',
'unique clicks' => 'unique clicks',
);
?>