<?php

$lan = array(
  'users' => 'Users',
  'control' => 'Control values for',
  'userattributes' => 'User Attributes',
  'reconcile' => 'Reconcile Users',
  'check' => 'Check for Users',
  'import' => 'Import Users',
  'export' => 'Export Users',
  'mass unconfirm users' => 'Mass Unconfirm Users'
);
