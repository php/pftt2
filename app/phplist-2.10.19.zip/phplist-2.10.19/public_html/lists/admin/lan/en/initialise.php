<?php
$lan = array(
  'Creating tables' => 'Creating tables',
  'Initialising table' => 'Initialising table',
  'Table already exists' => 'Table already exists',
  'failed' => 'failed',
  'ok' => 'ok',
  'failed' => 'failed',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' => 'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.',
  'Success' => 'Success',
  'Tell us about it' => 'Tell us about it',
  'Please make sure to read the file README.security that can be found in the zip file.' => 'Please make sure to read the file README.security that can be found in the zip file.',
//one sentence: make sure to .. subscribe to announcements
  'Please make sure to' => 'Please make sure to',
  'subscribe to the announcements list' => 'subscribe to the announcements list',
  'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => 'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.',
//one sentence: 'continue with ... phplist setup?
  'Continue with' => 'Continue with',
  'PHPlist Setup' => 'PHPlist Setup',
//one sentence: 'maybe you want to... upgrade... instead?
  'Maybe you want to' => 'Maybe you want to',
  'Upgrade' => 'Upgrade',
  'instead?' => 'instead?',
  'Force Initialisation' => 'Force Initialisation',
  '(will erase all data!)' => '(will erase all data!)',
  'Checklist for Installation' => 'Checklist for Installation',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' => 'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.',
  'to make sure you are updated when new versions come out. Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => 'to make sure you are updated when new versions come out. Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.',

  # new in 2.10.1
  'List for testing.' => 'List for testing.',



);
?>