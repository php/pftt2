<?php

$lan = array(
'Message Click Statistics' => 'Message Click Statistics',
'firstclick' => 'firstclick',
'latestclick' => 'latestclick',
'clicks' => 'clicks',
'Click Details for a Message' => 'Click Details for a Message',
'Subject' => 'Subject',
'Entered' => 'Entered',
'sent' => 'Sent',
'clickrate' => 'Clickrate',
'unique clicks' => 'unique clicks',
'unique clickrate' => 'unique clickrate',
'who' => 'who',
'view users' => 'view users',
'Select Message to view' => 'Select Message to view',
'Available Messages' => 'Available Messages',
'You do not have access to this page' => 'You do not have access to this page',

# for 2.10.2
'there are currently no messages to view' => 'There are currently no messages to view',
);
?>