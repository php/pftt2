<?php
$lan = array(
 'You do not have enough priviliges to view this page' => 'You do not have enough priviliges to view this page',
 'Members of this list' => 'Members of this list',
 'Record Saved' => 'Record Saved',
 'List name' => 'List name',
 'Check this box to make this list active (listed)' => 'Check this box to make this list active (listed)',
 'Order for listing' => 'Order for listing',
 'Subject Prefix' => 'Subject Prefix',
 'Owner' => 'Owner',
 'RSS Source' => 'RSS Source',
 'List Description' => 'List Description',
 'View Items' => 'View Items',
 'Save' => 'Save',
 'validate' => 'validate',
);
?>
