<?php

$lan = array(
'Sorry, this page can only be used by super admins' => 'Sorry, this page can only be used by super admins',
'Mass unconfirm email addresses' => 'Mass unconfirm email addresses',
'Paste the emails to mark unconfirmed in this box, and click continue' => 'Paste the emails to mark unconfirmed in this box, and click continue',
'Continue' => 'Continue',
'All done, %d emails processed, %d emails marked unconfirmed<br/>' => 'All done, %d emails processed, %d emails marked unconfirmed<br/>',
);
?>