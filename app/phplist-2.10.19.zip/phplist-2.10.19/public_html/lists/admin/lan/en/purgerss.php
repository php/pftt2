<?php

$lan = array(
'Purge RSS items from database' => 'Purge RSS items from database',
'Enter the number of days to go back purging entries' => 'Enter the number of days to go back purging entries',
'%d RSS items purged' => '%d RSS items purged',

'Sorry, only super users can purge RSS items from the database' => 'Sorry, only super users can purge RSS items from the database',
);
?>