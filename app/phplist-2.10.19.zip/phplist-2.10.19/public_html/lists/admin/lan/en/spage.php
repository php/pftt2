<?php 
$lan = array(

  'subscribe pages' => 'Subscribe Pages',
  'deleted' => 'Deleted',
  'add_new' => 'Add a new one',
  'title' => 'title',
  'edit' => 'edit',
  'del' => 'del',
  'view' => 'view',
  'status' => 'status',
  'owner' => 'owner',
  'default' => 'default',
  'active' => 'active',
  'not active' => 'not active',

);
?>