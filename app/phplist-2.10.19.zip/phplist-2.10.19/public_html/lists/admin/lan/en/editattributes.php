<?php 
$lan = array(
  "NoAttr" => "No such attribute:",
  "AddNew" => "add new",
  "SureToDeleteAll" => "Are you sure you want to delete all records?",
  "DelAll" => "delete all",
  "ReplaceAllWith" => "Alternatively you can replace all values with another one:",
  "ReplaceWith" => "Replace with",
  "TooManyToList" => "* Too many to list, total dependencies:",
  "TooManyErrors" => "* Too many errors, quitting",
  "Delete" => "delete",
  "Default" => "(default)",
  "changeorder" => "change order",
  "cannotdelete" => "Cannot delete ",
  "dependentrecords" => "The Following record(s) are dependent on this value<br />
    Update the record(s) to not use this attribute value and try again",
  "addnew" => "add new",
  "oneperline" => "one per line",
  "deleteandreplace" => 'Delete and Replace',
  
  
);
?>