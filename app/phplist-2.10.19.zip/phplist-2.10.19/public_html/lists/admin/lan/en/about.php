<?php

$lan = array(
  'Developers' => 'Developers',
  'Contributors' => 'Contributors',
  'Translations' => 'Translations',
  'Portions of the system include' => 'Portions of the system include',
  'thankseveryone' => 'The developers wish to thank the many contributors to this system, who have helped out with bug reports, suggestions, donations, feature requests, sponsoring, translations and many other contributions.',


  # use this tag to give your own name(s), so you are listed in the "About" page
  # for credits for this particular translation
  'credits for this translation' => '',

  # new in 2.10.1
  'Documentation' => 'Documentation',
);

?>