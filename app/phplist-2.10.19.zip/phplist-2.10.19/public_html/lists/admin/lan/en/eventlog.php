<?php
$lan = array(
 'Deleting' => 'Deleting',
 'Done' => 'Done',
 'events' => 'events',
 'Listing' => 'Listing',
 'to' => 'to',
 'Listing 1 to 50' => 'Listing 1 to 50',
 'Are you sure you want to delete all events older than 2 months?' => 'Are you sure you want to delete all events older than 2 months?',
 'Delete all (&gt; 2 months old)' => 'Delete all (&gt; 2 months old)',
 'Are you sure you want to delete all events matching this filter?' => 'Are you sure you want to delete all events matching this filter?',
 'Delete all' => 'Delete all',
 'No events available' => 'No events available',
 'Filter' => 'Filter',
 'Exclude filter' => 'Exclude filter',
 'del' => 'del', # as in short for delete
 'date' => 'date',
 'message' => 'message', 
 'events' => 'Events',
 'page' => 'page',
);
?>
