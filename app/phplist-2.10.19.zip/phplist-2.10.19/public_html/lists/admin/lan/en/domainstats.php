<?php

$lan = array(
  'Top 50 domains with more than 5 emails' => 'Top 50 domains with more than 5 emails',
  'num' => 'num',
);
?>