<?php
$lan = array( 
 'you only have privileges to view this page, not change any of the information' => 'You only have privileges to view this page, not change any of the information',
 'no such User' => 'No such User',
 'view' => 'View',
 'user is Blacklisted since' => 'User is Blacklisted since',
 'messages sent to this user' => 'messages sent to this user',
 'are you sure you want to delete this user from the blacklist' => 'Are you sure you want to delete this user from the blacklist',
 'it should only be done with explicit permission from this user' => 'It should only be done with explicit permission from this user',
 'remove User from Blacklist' => 'Remove User from Blacklist',
 'user subscription history' => 'User Subscription History',
 'no details found' => 'No details found',
 'messages sent to this user' => 'messages sent to this user',
 'ip' => 'ip',
 'date' => 'date',
 'summary' => 'summary',
 'detail' => 'detail',
 'info' => 'info',
 'blacklist info' => 'Blacklist Info',
 'value' => 'value',
 'subscription history' => 'Subscription History', 
 'clicks' => 'clicks',

 # new in 2.9.5
  'viewed' => 'viewed',
  'responsetime' => 'responsetime',
  'average' => 'average',
 
);
?>