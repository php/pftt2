<?php
$lan = array (
  'Creating tables' => '建立資料表中',
  'Initialising table' => '組態資料表中',
  'Table already exists' => '資料表已經存在',
  'failed' => '錯誤',
  'ok' => '完成',
  'List for testing. If you don\'t make this list active and add yourself as a member, you can use this list to test a message. If the message comes out ok, you can resend it to other lists.' => '測試的電子報，如果您沒有啟用這個電子報且將自己加入成會員，您可以用這個電子報來測試發送功能。如果信件成功寄出，您接著可以正式將電子報寄出',
  'Success' => '成功',
  'Tell us about it' => '回報問題',
  'Please make sure to read the file README.security that can be found in the zip file.' => '請記得閱讀 README.security 檔案中的說明，解壓縮後就可以找到',
  'Please make sure to' => '請記得',
  'subscribe to the announcements list' => '訂閱我們的公告電子報',
  'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => 'to make sure you are updated when new versions come out.
    Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.',
  'Continue with' => '繼續',
  'PHPlist Setup' => '安裝',
  'Maybe you want to' => '也許您想要',
  'Upgrade' => '升級',
  'instead?' => '代替？',
  'Force Initialisation' => '強制組態',
  '(will erase all data!)' => '(將會清除所有資料！)',
  'Checklist for Installation' => '安裝前的檢查',
  'to make sure you are updated when new versions come out. Sometimes security bugs are found which make it important to upgrade. Traffic on the list is very low.' => '可以確認您是否更新到最新版本，有時候會出現安全性漏洞需要升級，我們寄送信件的頻率並不高。',
  'List for testing.' => '測試列表',

);
?>