<?php
$lan = array (
  'Deleting' => '刪除中',
  'Done' => '完成',
  'events' => '事件',
  'Listing' => '列出',
  'to' => '到',
  'Listing 1 to 50' => '列出前50項',
  'Are you sure you want to delete all events older than 2 months?' => '您確定要刪除兩個月前的所有事件？',
  'Delete all (&gt; 2 months old)' => '全部刪除 （>2個月前）',
  'Are you sure you want to delete all events matching this filter?' => '您確定要刪除符合條件的所有事件？',
  'Delete all' => '全部刪除',
  'No events available' => '沒有事件',
  'Filter' => '規則',
  'Exclude filter' => '除外規則',
  'del' => '刪除',
  'date' => '日期',
  'message' => '訊息',
  'page' => '頁',

);
?>