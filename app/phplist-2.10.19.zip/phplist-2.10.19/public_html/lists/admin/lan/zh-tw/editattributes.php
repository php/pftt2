<?php
$lan = array (
  'NoAttr' => '沒有這個欄位：',
  'AddNew' => '新增',
  'SureToDeleteAll' => '您確定要刪除所有資料？',
  'DelAll' => '全部刪除',
  'ReplaceAllWith' => '另外您可以用另外一個值取代所有資料',
  'ReplaceWith' => '置換',
  'TooManyToList' => '* 太多項目了，依存關係總數：',
  'TooManyErrors' => '* 太多錯誤，關閉中',
  'Delete' => '刪除',
  'Default' => '(預設)',
  'changeorder' => '修改順序',
  'cannotdelete' => '無法刪除',
  'dependentrecords' => '下面資料與這個數值有依存關係<br />請移除他們的依存關係後重試',
  'addnew' => '新增',
  'oneperline' => '一行/個',
  'deleteandreplace' => '刪除與取代',

);
?>