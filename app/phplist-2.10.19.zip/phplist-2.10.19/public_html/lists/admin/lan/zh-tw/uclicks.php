<?php
$lan = array (
  'Click Details for a URL' => '網址點閱細節',
  'URL Click Statistics' => '網址點閱統計',
  'firstclick' => '第一次',
  'latestclick' => '最新一次',
  'clicks' => '次點選',
  'clickrate' => '點閱率',
  'msg' => '訊息',
  'who' => '使用者',
  'view users' => '檢視使用者',
  'You do not have access to this page' => '您沒有權限檢視這個頁面',
  'Select URL to view' => '選擇要瀏覽的網址',
  'Available URLs' => '可用的網址',
  'sent' => '已寄出',
  'unique clicks' => '不重複點閱次數',
  'unique clickrate' => '不重複點閱率',

);
?>