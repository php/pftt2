<?php
$lan = array (
  'PHPList Users' => '使用者',
  'on' => '在',
  'List Membership' => '列出會員',
  'No Lists' => '沒有資料',

);
?>