<?php
$lan = array (
  'You do not have enough priviliges to view this page' => '您沒有瀏覽這個頁面的權限',
  'Members of this list' => '這個電子報的訂閱者',
  'Record Saved' => '資料儲存了',
  'List name' => '電子報名稱',
  'Check this box to make this list active (listed)' => '勾選這個項目來啟用電子報 (列出的)',
  'Order for listing' => '電子報順序',
  'Subject Prefix' => '主題前置字元',
  'Owner' => '擁有者',
  'RSS Source' => 'RSS 來源',
  'List Description' => '電子報介紹',
  'View Items' => '瀏覽項目',
  'Save' => '儲存',
  'validate' => '驗證',

);
?>