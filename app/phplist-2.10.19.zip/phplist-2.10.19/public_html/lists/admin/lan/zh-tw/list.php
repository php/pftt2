<?php
$lan = array (
  'Deleting' => '刪除中',
  'Done' => '完成',
  'RSS source' => 'RSS 來源',
  'delete' => '刪除',
  'n/a' => '無',
  'No lists available, use Add to add one' => '沒有電子報，請點選新增',
  'No' => '無',
  'Name' => '名稱',
  'Order' => '順序',
  'Functions' => '功能',
  'Active' => '啟用',
  'Owner' => '擁有者',
  'Save Changes' => '儲存',
  'Add a list' => '新增電子報',
  'members' => '會員',
  '(view items)' => '(瀏覽項目)',
  'edit' => '編輯',
  'view members' => '瀏覽會員',

);
?>