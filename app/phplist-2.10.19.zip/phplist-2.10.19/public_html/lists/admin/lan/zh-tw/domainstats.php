<?php
$lan = array (
  'Top 50 domains with more than 5 emails' => '超過五個信箱的前五十個網域',
  'num' => '數量',

);
?>