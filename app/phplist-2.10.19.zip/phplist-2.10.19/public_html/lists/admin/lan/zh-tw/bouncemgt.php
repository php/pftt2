<?php
$lan = array (
  'List Bounce Rules' => '退信規則清單',
  'rulesexistwarning' => '您已經在系統中定義了退信規則，
    新增規則時請小心，因為這可能影響已經存在的規則。',
  'norulesyet' => '您目前沒有定義任何規則，
    您可以點選"產生退信規則"來自動從存在的退信中產生規則，
    這將會產生大量規則，您必須一一檢視、啟用。
    然而這並不表示它會自動擷取任何單一退信，當新的退信產生時您必須適時建立新規則。',
  'Generate Bounce Rules' => '產生退信規則',
  'Check Current Bounce Rules' => '檢查目前退信規則',

);
?>