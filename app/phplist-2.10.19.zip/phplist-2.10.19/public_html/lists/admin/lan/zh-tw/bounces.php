<?php
$lan = array (
  'done' => '完成',
  'bounces' => '退信',
  'to' => '到',
  'listing' => '清單',
  'are you sure you want to delete all bounces older than 2 months' => '您確定要刪除兩個月前的所有退信',
  'delete all processed (&gt; 2 months old)' => '刪除已處理的 (> 2 個月前)',
  'are you sure you want to delete all bounces,\n even the ones that have not been processed' => '您確定要刪除所有退信，n 即使是您還沒處理的部分',
  'delete all' => '全部刪除',
  'are you sure you want to reset all counters' => '您確定要重設所有指數',
  'reset bounces' => '重設退信',
  'delete' => '刪除',
  'deleting' => '刪除中',
  'no unprocessed bounces available' => '沒有未處理退信',
  'message' => '訊息',
  'user' => '使用者',
  'date' => '日期',
  'show' => '顯示',
  'unknown' => '未知',
  'system message' => '系統訊息',
  'are you sure you want to delete all unidentified bounces older than 2 months' => '您確定要刪除所有超過兩個月未處理的退信',
  'delete all unidentified (&gt; 2 months old)' => '刪除所有未處理退信 (> 2 個月)',

);
?>