<?php
$lan = array (
  'User Click Statistics' => '使用者點閱統計',
  'User Click Details for a Message' => '使用者信件點閱統計',
  'User Click Details for a URL' => '使用者網址點閱統計',
  'User Click Details for a URL in a message' => '使用者信件中網址點閱統計',
  'User Click Details for a message' => '使用者在信件中的點閱細節',
  'Subject' => '主旨',
  'Entered' => '輸入日期',
  'Sent' => '寄送日期',
  'firstclick' => '第一次',
  'latestclick' => '最新一次',
  'clicks' => '次點選',
  'clickrate' => '點閱率',
  'message' => '信件',
  'Invalid Request' => '錯誤的請求',
  'You do not have access to this page' => '您沒有權限存取這個頁面',
  'User Click Details' => '使用者點閱細節',
  'sent' => '寄送',
  'unique clicks' => '不重複點閱次數',

);
?>