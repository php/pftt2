<?php
$lan = array (
  'Purge RSS items from database' => '清除資料庫中的 RSS 項目',
  'Enter the number of days to go back purging entries' => '輸入要自動清除資料的天數',
  '%d RSS items purged' => '%d 個 RSS 項目清除了',
  'Sorry, only super users can purge RSS items from the database' => '抱歉，只有管理者能夠從資料庫中清除 RSS 項目',

);
?>