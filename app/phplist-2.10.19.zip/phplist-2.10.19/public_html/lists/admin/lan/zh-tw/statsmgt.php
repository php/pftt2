<?php
$lan = array (
  'View Clicks by URL' => '檢視網址點閱統計',
  'View Clicks by Message' => '檢視信件點閱次數',
  'View Opens by Message' => '檢視信件開啟次數',
  'Domain Statistics' => '網域統計',

);
?>