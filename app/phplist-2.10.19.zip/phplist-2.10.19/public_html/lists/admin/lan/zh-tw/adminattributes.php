<?php
$lan = array (
  'SaveChanges' => '儲存',
  'NameNotEmpty' => '名稱不能空白：',
  'NameNotUnique' => '名稱必須是唯一',
  'ExistingAttr' => '已經存在的欄位：',
  'NoAttrYet' => '目前尚未定義任何欄位<br/>',
  'Attribute' => '欄位：',
  'Delete' => '刪除',
  'Name' => '名稱：',
  'Type' => '類型：',
  'DValue' => '預設值：',
  'OrderListing' => '順序：',
  'IsAttrRequired' => '必填項目？',
  'AddAttr' => '新增欄位：',

);
?>