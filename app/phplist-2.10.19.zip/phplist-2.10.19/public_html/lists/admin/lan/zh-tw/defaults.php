<?php
$lan = array (
  'loading' => '讀取中',
  'done' => '完成',
  'name_empty' => '名稱不得為空白：',
  'name_not_unique' => '名稱不得重複',
  'continue' => '繼續',
  'add' => '新增',

);
?>