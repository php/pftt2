<?php
$lan = array (
  'Sorry, this page can only be used by super admins' => '抱歉，這個頁面只有管理員能夠瀏覽',
  'Mass unconfirm email addresses' => '批次取消信箱確認',
  'Paste the emails to mark unconfirmed in this box, and click continue' => '貼上希望標示為未確認的信箱，接著點選繼續',
  'Continue' => '繼續',
  'All done, %d emails processed, %d emails marked unconfirmed<br/>' => '全部完成，處理了 %d 個信箱， %d 個信箱標示為未確認<br/>',

);
?>