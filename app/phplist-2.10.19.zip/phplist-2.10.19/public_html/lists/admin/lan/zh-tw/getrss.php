<?php
$lan = array (
  'This page can only be called from the commandline' => '這個頁面只能夠從指令模式執行',
  'Getting and Parsing the RSS sources' => '取得與分析RSS來源',
  'Rss Errors' => 'Rss 錯誤',
  'Rss Results' => 'Rss 結果',
  'Rss Failure report' => 'Rss 錯誤報告',
  'Parsing' => '分析中',
  'ok' => '完成',
  'failed' => '錯誤',
  'Process Killed by other process' => '從其他程序處理刪除的',
  'items' => '項目',
  'new items' => '新增',
  'Nothing to do' => '沒有動作',

);
?>