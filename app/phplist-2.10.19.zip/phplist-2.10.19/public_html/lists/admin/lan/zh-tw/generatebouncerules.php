<?php
$lan = array (
  'Process Next Batch' => '處理下一批',
  'Process Killed by other process' => '處理程序被其他程序中止',
  'Hmm, duplicate entry, ' => '資料重複',
  'new rules found' => '找到新規則',
  'bounces not matched' => '不符合的退信',
  'bounces matched to existing rules' => '符合現有規則的退信',
  '0' => '‾',

);
?>