<?php
$lan = array (
  'checklist for installation' => '安裝檢查清單',
  'cannot be empty' => '不能空白',
  'editing' => '編輯中',
  'save changes' => '儲存',
  'edit' => '編輯',

);
?>