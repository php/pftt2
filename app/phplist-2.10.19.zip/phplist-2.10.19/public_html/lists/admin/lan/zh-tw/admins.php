<?php
$lan = array (
  'Add new admin' => '新增管理員',
  'Administrators' => '管理員',
  'Find an admin' => '搜尋',
  'Show' => '顯示',
  'Import list of admins' => '匯入管理員清單',
  'Deleting' => '刪除中',
  'Done' => '完成',
  'Admin added' => '管理員新增了',
  'Listing admin' => '列出管理員中',
  'Listing admin 1 to 50' => '列出前五十個管理員',
  'found' => '找到',

);
?>