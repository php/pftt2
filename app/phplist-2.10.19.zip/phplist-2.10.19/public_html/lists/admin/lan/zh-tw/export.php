<?php
$lan = array (
  'Export' => '匯出',
  'ExportOnList' => '匯出在 %s 從 %s 到 %s (%s).csv',
  'ExportFromval' => '匯出從 %s 到 %s (%s).csv',
  'ListMembership' => '列出訂閱會員',
  'ExportOn' => '<h4>匯出使用者在 %s</h4>',
  'DateFrom' => '日期自：',
  'DateTo' => '日期到：',
  'DateToUsed' => '要使用的日期：',
  'WhenSignedUp' => '當他們註冊時',
  'WhenRecordChanged' => '當這筆記錄異動時',
  'SelectColToIn' => '選擇希望匯出的欄位',
  'When they subscribed to' => '當他們訂閱',

);
?>