<?php
$lan = array (
  'Number of %s rules: %d' => '%s 規則的數量： %d',
  'active' => '啟用',
  'candidate' => '候選',
  'Bounce Regular Expressions' => '退信樣式比對',
  'rule' => '規則',
  'expression' => '描述',
  'action' => '動作',
  '#bncs' => '#退信',
  'tag' => '標籤',
  'order' => '順序',
  'del' => '刪除',
  'with tagged rules: ' => '選擇的規則：',
  'delete' => '刪除',
  'make inactive' => '停用',
  'Save Changes' => '儲存異動',
  'add a new rule' => '新增規則',
  'Regular Expression' => '樣式比對',
  'Memo for this rule' => '這個規則的備註',
  'Add new Rule' => '新增規則',
  'make active' => '啟用',
  'No Rules found' => '沒有任何規則',
  'match' => '符合',
  'That rule exists already' => '這個規則已經存在',

);
?>