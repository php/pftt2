<?php
$lan = array (
  'Updating the regular expression of this rule caused an Sql conflict<br/>This is probably because there is already a rule like that. Do you want to delete this rule instead?' => '更新這個規則的樣式比對造成資料庫的衝突 <br/>也許是已經有類似的規則存在，您是否要刪除這個規則？',
  'Yes' => '是',
  'No' => '否',
  'back to list of bounce rules' => '回到退信規則列表',
  'Regular Expression' => '樣式比對',
  'Created By' => '建立者',
  'Action' => '動作',
  'Status' => '狀態',
  'Select Status' => '選擇狀態',
  'Memo for this rule' => '這個規則的備註',
  'Save Changes' => '儲存異動',
  'related bounces' => '相關退信',
  'no related bounces found' => '沒有找到相關退信',
  'and more, %d in total' => '總計 %d ',

);
?>