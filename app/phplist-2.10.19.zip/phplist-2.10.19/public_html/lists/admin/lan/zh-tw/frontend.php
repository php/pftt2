<?php
$lan = array (
  'Please indicate how often you want to receive messages' => '請定義您希望收到訊息的頻率',
  'Email is blacklisted, so request for confirmation has been sent.' => '帳號在黑名單中，確認訊息已經寄出',
  'If user confirms subscription, they will be removed from the blacklist.' => '如果使用者透過信件確認，他們將會自黑名單中移除',
//  'YouAreBlacklisted' => '您的信箱歸類再我們的黑名單中，這意謂著您曾經要求我們不要再寄送任何信件給您。<br/>
//系統唯一會寄給您的信件就是收到您希望訂閱電子報的請求，只要您點選信件中的確認連結，您就會從黑名單中移除，也就能夠繼續收到我們為您準備的電子報。',

);
?>