<?php
$lan = array (
  'existingusers' => '已經存在的使用者',
  'nonexistingusers' => '不存在的使用者',
  'existcheckintro' => '<p>檢查使用者是否存在的頁面</p>',
  'whatistype' => '您希望檢查什麼類型的資訊',
  'foreignkey' => '外部鍵',
  'email' => 'Email',
  'continue' => '繼續',
  'pastevalues' => '將資料貼進這個區塊中來檢查，一行一筆資料',
  'key' => '索引',
  'passwd' => '密碼',

);
?>