<?php
$lan = array (
  'Deleting' => '刪除中',
  'Done' => '完成',
  'No template have been defined' => '沒有定義任何樣版',
  'Existing templates' => '已經存在的樣版',
  'View' => '瀏覽',
  'Edit' => '編輯',
  'delete' => '刪除',
  'Add new Template' => '新增樣版',
  'ID' => 'ID',
  'Default' => '預設',
  '# imgs' => '圖片編號',

);
?>