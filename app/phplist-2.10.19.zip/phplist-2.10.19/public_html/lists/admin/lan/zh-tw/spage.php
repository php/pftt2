<?php
$lan = array (
  'subscribe pages' => '訂閱頁面',
  'deleted' => '已刪除',
  'add_new' => '新增一個',
  'title' => '標題',
  'edit' => '編輯',
  'del' => '刪除',
  'view' => '瀏覽',
  'status' => '狀態',
  'owner' => '擁有者',
  'default' => '預設',
  'active' => '啟用',
  'not active' => '停用',

);
?>