<?php
$lan = array (
  'Developers' => '開發',
  'Contributors' => '貢獻',
  'Translations' => '翻譯',
  'Portions of the system include' => '系統 include 位置',
  'thankseveryone' => '開發人員希望藉此感激許多參與、貢獻的朋友，包括回報問題、建議、贊助、功能提議、翻譯與許多提供協助的朋友。',
  'credits for this translation' => 'Finjon Kiang | http://twpug.net/ ',
  'Documentation' => '文件',

);
?>