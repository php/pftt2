<?php
$lan = array (
  'Process Next %d' => '處理下一個 %d',
  'No match' => '沒有符合項目',
  'bounces did not match any current active rule' => '退信不符和目前任何啟用中的規則',
  'bounce matched current active rules' => '退信符合目前啟用中的規則',

);
?>