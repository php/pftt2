<?php
$lan = array (
  'initialise_database' => '初始化資料庫',
  'change_admin_passwd' => '修改管理者密碼',
  'config_gral_values' => '一般設定',
  'config_attribs' => '設定欄位',
  'create_lists' => '建立電子報',
  'create_subscr_pages' => '建立訂閱頁面',
  'go_there' => '點選這裡',

);
?>