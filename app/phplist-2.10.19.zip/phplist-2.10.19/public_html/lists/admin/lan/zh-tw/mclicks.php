<?php
$lan = array (
  'Message Click Statistics' => '信件點閱統計',
  'firstclick' => '第一次',
  'latestclick' => '最新一次',
  'clicks' => '次',
  'Click Details for a Message' => '信件點閱細節',
  'Subject' => '主旨',
  'Entered' => '進入',
  'sent' => '送出',
  'clickrate' => '點閱率',
  'unique clicks' => '不重複點閱次數',
  'unique clickrate' => '不重複點閱率',
  'who' => '使用者',
  'view users' => '瀏覽使用者',
  'Select Message to view' => '選擇要瀏覽的信件',
  'Available Messages' => '可以使用的信件',
  'You do not have access to this page' => '您沒有權限存取這個頁面',
  'there are currently no messages to view' => '目前沒有任何信件',

);
?>