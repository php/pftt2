<?php
$lan = array (
  'users' => '使用者',
  'control' => '控制值於',
  'userattributes' => '使用者欄位',
  'reconcile' => '大量修改使用者',
  'check' => '檢查使用者',
  'import' => '匯入使用者',
  'export' => '匯出使用者',
  'mass unconfirm users' => '大量重新確認使用者',

);
?>