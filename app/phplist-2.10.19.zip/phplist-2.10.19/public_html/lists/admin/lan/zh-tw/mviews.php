<?php
$lan = array (
  'You do not have access to this page' => '您沒有權限存取這個頁面',
  'Select Message to view' => '選擇要瀏覽的信件',
  'Available Messages' => '可以使用的信件',
  'views' => '次瀏覽',
  'rate' => '比率',
  'View Details for a Message' => '信件瀏覽細節',
  'Subject' => '主旨',
  'Entered' => '進入',
  'Message Open Statistics' => '信件開啟統計',
  'Listing user %d to %d' => '列出使用者 %d 到 %d',
  'Entries' => '筆資料',
  'firstview' => '第一次',
  'lastview' => '最新一次',
  'responsetime' => '回應時間',
  'sec' => '秒',
  'there are currently no messages to view' => '目前沒有任何信件',

);
?>