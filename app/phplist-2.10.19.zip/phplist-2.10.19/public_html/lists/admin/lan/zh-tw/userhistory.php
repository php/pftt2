<?php
$lan = array (
  'you only have privileges to view this page, not change any of the information' => '您只能夠瀏覽這個頁面，無法做任何修改',
  'no such User' => '沒有這個使用者',
  'view' => '瀏覽',
  'user is Blacklisted since' => '使用者被列為黑名單自',
  'messages sent to this user' => '送給這個使用者的訊息',
  'are you sure you want to delete this user from the blacklist' => '您確定要從黑名單中刪除這個使用者',
  'it should only be done with explicit permission from this user' => '您應該先徵詢過使用者的意願才進行這個動作',
  'remove User from Blacklist' => '從黑名單中移除使用者',
  'user subscription history' => '使用者訂閱記錄',
  'no details found' => '沒有詳細資訊',
  'ip' => 'ip',
  'date' => '日期',
  'summary' => '摘要',
  'detail' => '細節',
  'info' => '資訊',
  'blacklist info' => '黑名單資訊',
  'value' => '數值',
  'subscription history' => '訂閱記錄',
  'clicks' => '次點選',
  'viewed' => '次瀏覽',
  'responsetime' => '回應時間',
  'average' => '平均',

);
?>