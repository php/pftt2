// DE lang variables
// Edited 2005 by Nico Kruber

tinyMCELang['lang_insert_mosimage_desc']        = 'MosImage einf�gen';
tinyMCELang['lang_insert_mospagebreak_desc']    = 'MosPageBreak einf�gen';
tinyMCELang['lang_insert_mospagebreak_title']   = 'Einstellung f�r MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Seiten-Titel';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Inhaltsverzeichnis';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Heading';
tinyMCELang['lang_insert_mambo_title']          = 'Mambo Elemente Plugin';
