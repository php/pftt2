// PT_BR lang variables

tinyMCELang['lang_insert_mosimage_desc']   			= 'Inserir MosImage'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Inserir MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_title']   = 'Configura��es do MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'T�tulo da p�gina';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Tabela de Conte�dos';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Heading';
tinyMCELang['lang_insert_mambo_title']     			= 'Plugin de elementos do Mambo';
