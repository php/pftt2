// UK lang variables

tinyMCELang['lang_insert_mosimage_desc']   			= 'Ins�rer une MosImage'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Ins�rer un MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_title']   = 'R�glage pour MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Titre de la page';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Table des mati�res';
tinyMCELang['lang_insert_mambo_title']     			= 'Elements de plugin Mambo';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Heading';
