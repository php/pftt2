// ***********************************************************************
// ** Title.........:    TinyMCE_EXP_1.2 polish lang. Image Manager Dialog, Image Manager
// ** Version.......:    1.0
// ** Author........:    Stefan Wajda <zwiastun@zwiastun.net>, Diabl0/MAO Group, http://www.mao.pl
// ** Filename......:    pl.js (polish language file)
// ** Last changed..:    8 Feb 2005
// ***********************************************************************/

tinyMCELang['lang_insert_mosimage_desc']   			= 'Wstaw grafik�'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Wstaw podzia� strony';
tinyMCELang['lang_insert_mospagebreak_title']   = 'Ustawienia podzia�u stron';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Tytu� strony';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Spis tre�ci';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Heading';
tinyMCELang['lang_insert_mambo_title']     			= 'Wtyczki Mambo';
