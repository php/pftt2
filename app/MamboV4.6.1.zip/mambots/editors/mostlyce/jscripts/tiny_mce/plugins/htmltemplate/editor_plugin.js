// Tiny MCE Template Plugin

/* Import plugin specific language pack */ 
tinyMCE.importPluginLanguagePack('htmltemplate', 'en');

function TinyMCE_htmltemplate_getControlHTML(control_name) {
	switch (control_name) { 
		case "htmltemplate":
			return '<img id="{$editor_id}htmltemplate" src="{$pluginurl}/images/htmltemplate.gif" title="{$lang_htmltemplate_desc}" width="20" height="20" class="mceButtonNormal" onmouseover="tinyMCE.switchClass(this,\'mceButtonOver\');" onmouseout="tinyMCE.restoreClass(this);" onmousedown="tinyMCE.restoreAndSwitchClass(this,\'mceButtonDown\');" onclick="tinyMCE.execInstanceCommand(\'{$editor_id}\',\'mceHTMLTemplate\');" />';
	} 
	return ''; 
} 
function TinyMCE_htmltemplate_execCommand(editor_id, element, command, user_interface, value) {
	switch (command) {
  		case "mceHTMLTemplate":
				var template = new Array();
				template['file']	= '../../plugins/htmltemplate/htmltemplate.php'; // Relative to theme
				template['width']  = 450;
				template['height'] = 420;
				var HTMLtemplate = "";
				tinyMCE.openWindow(template, {editor_id : editor_id, HTMLtemplate: HTMLtemplate, resizable : "yes", scrollbars : "no", mceDo : 'insert'});
		 	return true;
	}

	// Pass to next handler in chain
	return false;
}
function TinyMCE_htmltemplate__insertContent(content) {

	// Insert cleaned content
		tinyMCE.execCommand("mceAddUndoLevel");
		tinyMCE.execCommand("mceInsertContent", false, content);
}

