/**
* @version $Id: fi.js,v 1.1 2005/09/16 19:39:58 msuominen Exp $
* Finnish language file for mosCE 1.0
* Creator: Finnish Joomla! translation team
* Homepage: http://www.joomlaportal.fi
* Author: Markku Suominen <admin@joomlaportal.fi> 
*/

tinyMCELang['lang_insert_mosimage_desc']   			= 'Lis�� MosImage'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Lis�� MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_title']   = 'MosPageBreak asetukset';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Sivun otsikko';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Sis�llysluettelo';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Otsikko';
tinyMCELang['lang_insert_mambo_title']     			= 'Mambo plugin-elementti';
