// UK lang variables

tinyMCELang['lang_insert_mosimage_desc']   			= 'Insert MosImage'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Insert MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_title']   = 'Settings for MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Page Title';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Table of Contents';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Heading';
tinyMCELang['lang_insert_mambo_title']     			= 'Mambo elements plugin';
