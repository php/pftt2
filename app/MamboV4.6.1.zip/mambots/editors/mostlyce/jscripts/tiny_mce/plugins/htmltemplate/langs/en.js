// UK lang variables
tinyMCELang['lang_htmltemplate_desc'] = 'Insert HTML Template';
tinyMCELang['lang_htmltemplate_title'] = 'Select HTML Template to insert.';
