// nl lang variables

tinyMCELang['lang_insert_mosimage_desc']   			= 'Invoegen MosImage'
tinyMCELang['lang_insert_mospagebreak_desc']    = 'Invoegen MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_title']   = 'Instellingen voor MosPageBreak';
tinyMCELang['lang_insert_mospagebreak_atext']   = 'Pagina titel';
tinyMCELang['lang_insert_mospagebreak_ctext']   = 'Inhoudsopgave';
tinyMCELang['lang_insert_mospagebreak_btext']   = 'Kopregel';
tinyMCELang['lang_insert_mambo_title']     			= 'Mambo elementen plugin';
