<?php
/**
* @package Mambo Open Source
* @copyright (C) 2005 - 2006 Mambo Foundation Inc.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*
* Mambo was originally developed by Miro (www.miro.com.au) in 2000. Miro assigned the copyright in Mambo to The Mambo Foundation in 2005 to ensure
* that Mambo remained free Open Source software owned and managed by the community.
* Mambo is Free Software 
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
?>

Changelog:
------------
This is a non-exhaustive (but still near complete) changelog for
Mambo 4.6, including beta and release candidate versions.
Our thanks to all those people who've contributed bug reports and
code fixes.

Legend:

# -> Bug Fix
+ -> Addition
! -> Change
- -> Removed
! -> Note

-------------------- 4.6.1 Release -------------------------------------

r749 | neilt | 2006-10-04 13:15:07 -0600 (Wed, 04 Oct 2006) | 1 line

# bug fix : incorrectly assigned variable causing php notices - #FS121
------------------------------------------------------------------------
r745 | cauld | 2006-10-03 15:40:42 -0600 (Tue, 03 Oct 2006) | 1 line

! Removing the old DROP TABLES option during install.  This is not really 
an option since you have to drop tables before creating new ones.  Just 
altered the way the BACKUP TABLES option works.
------------------------------------------------------------------------
r744 | neilt | 2006-10-03 06:06:58 -0600 (Tue, 03 Oct 2006) | 1 line

# Bug fix : Pathway clone bug, link becomes a pathway - FS#106
------------------------------------------------------------------------
r743 | cauld | 2006-10-02 17:26:25 -0600 (Mon, 02 Oct 2006) | 1 line

# Fixing a few installation bugs found during an internal QA audit
------------------------------------------------------------------------
r741 | cauld | 2006-10-01 20:10:21 -0600 (Sun, 01 Oct 2006) | 1 line

# FS-108 - Fixes 6 array_merge warnings that are present on a fresh install 
with no content.
------------------------------------------------------------------------
r740 | cauld | 2006-10-01 17:07:08 -0600 (Sun, 01 Oct 2006) | 1 line

! Updating the Banner module & component to change the alt tag change from 
"Advertisement" to "Banner".  The old text was causing banners to be 
automatically blocked by some ad blockers.
------------------------------------------------------------------------
r739 | cauld | 2006-09-28 15:21:24 -0600 (Thu, 28 Sep 2006) | 1 line

# Fixing <span> issue in function makePathway
------------------------------------------------------------------------
r738 | neilt | 2006-09-28 11:39:07 -0600 (Thu, 28 Sep 2006) | 1 line

# Fix for some cross scripting bugs. FS#95
------------------------------------------------------------------------
r737 | adi | 2006-09-27 00:23:45 -0600 (Wed, 27 Sep 2006) | 1 line

include PHP 5 compatibility file
------------------------------------------------------------------------
r736 | adi | 2006-09-27 00:22:58 -0600 (Wed, 27 Sep 2006) | 1 line

added new file to provide missing functionality for older version of php
------------------------------------------------------------------------
r734 | cauld | 2006-09-26 20:46:25 -0600 (Tue, 26 Sep 2006) | 2 lines

# Adding a getEscaped call for $passwd in the LoginUser function
# Updating mosGetParam to utilize addslashes for added security
------------------------------------------------------------------------
r733 | neilt | 2006-09-25 13:33:41 -0600 (Mon, 25 Sep 2006) | 1 line

+ initial workaround for FS#89 — Can not add menu when Mysql strict is on
------------------------------------------------------------------------
r732 | chanh | 2006-09-23 17:42:50 -0600 (Sat, 23 Sep 2006) | 1 line

Fix bug cause site go offline when MetaKeys reach beyond 256 chars.
------------------------------------------------------------------------
r731 | neilt | 2006-09-23 07:21:20 -0600 (Sat, 23 Sep 2006) | 1 line

# bug fix - Email cloak incorrectly parses emails URL that include ? 
------------------------------------------------------------------------
r729 | neilt | 2006-09-23 04:46:37 -0600 (Sat, 23 Sep 2006) | 1 line

# bug fix - numerous gets missing for backward compatibility - FS#85 
------------------------------------------------------------------------
r728 | ninekrit | 2006-09-22 02:34:07 -0600 (Fri, 22 Sep 2006) | 1 line

#removed fixed encoding line 354 for support all encoding
------------------------------------------------------------------------
r727 | neilt | 2006-09-21 12:42:10 -0600 (Thu, 21 Sep 2006) | 1 line

# Bug fix — Declaration dropped bug, removed unused css - FS#58
------------------------------------------------------------------------
r726 | neilt | 2006-09-21 12:17:17 -0600 (Thu, 21 Sep 2006) | 1 line

# Bug Fix - missing / in check() function FS#90
------------------------------------------------------------------------
r725 | neilt | 2006-09-21 07:33:49 -0600 (Thu, 21 Sep 2006) | 1 line

# bug fix - missing declaration
------------------------------------------------------------------------
r724 | neilt | 2006-09-20 07:57:33 -0600 (Wed, 20 Sep 2006) | 1 line

# WebLinks email message not sent to admin bug fixed FS#76
------------------------------------------------------------------------
r723 | neilt | 2006-09-20 04:08:13 -0600 (Wed, 20 Sep 2006) | 1 line

# Bug fix for error message when there are no weblinks FS#88
------------------------------------------------------------------------
r722 | neilt | 2006-09-20 03:54:16 -0600 (Wed, 20 Sep 2006) | 1 line

# bug fix for login/out messages FS#82
------------------------------------------------------------------------
r721 | adi | 2006-09-18 20:09:06 -0600 (Mon, 18 Sep 2006) | 1 line

fix incorrect br tag. FS#87
------------------------------------------------------------------------
r719 | neilt | 2006-09-18 09:08:45 -0600 (Mon, 18 Sep 2006) | 1 line

file missed on earlier upload
------------------------------------------------------------------------
r718 | neilt | 2006-09-18 06:48:29 -0600 (Mon, 18 Sep 2006) | 1 line

+ Enhancements to comments component to fix bugs #FS72, #FS75
------------------------------------------------------------------------
r717 | cauld | 2006-09-17 12:27:50 -0600 (Sun, 17 Sep 2006) | 1 line

! Updating version.php & changelog.php

-------------------- 4.6 Release ---------------------------------------

r716 | cauld | 2006-09-17 12:19:53 -0600 (Sun, 17 Sep 2006) | 1 line

! Removing Mambo Raw SQL installation files and replacing with Mambo Lite SQL files.
------------------------------------------------------------------------
r715 | alwarren | 2006-09-14 23:03:21 -0600 (Thu, 14 Sep 2006) | 1 line

# FS#80 Fixed display of number of items checked in
------------------------------------------------------------------------
r714 | adi | 2006-09-14 19:05:36 -0600 (Thu, 14 Sep 2006) | 1 line

remove non utf-8 in locales.xml
------------------------------------------------------------------------
r711 | alwarren | 2006-09-14 11:18:07 -0600 (Thu, 14 Sep 2006) | 1 line

! FS#12 - Change menu manager radio buttons to checkboxes to allow multiple item selection
------------------------------------------------------------------------
r710 | alwarren | 2006-09-14 10:22:48 -0600 (Thu, 14 Sep 2006) | 2 lines

# FS#74 - Fixed problem with Itemid.
section/category links in content item were causing bad links
------------------------------------------------------------------------

r708 | gin | 2006-09-14 20:29:00

! some minor esthetical change in the form of the advanced search
(components/com_search/search.html.php)
------------------------------------------------------------------------
r707 | gin | 2006-09-14 16:36:00

# fixed the bug #77 noted by Mac in 2nd form's compilation during the new language creation
modfied the file includes\phpgettext\phpgettext.catalog.php

------------------------------------------------------------------------
r706 | gin | 2006-09-14 14:10:00

! Modified the component registration in a 2 step process with double e-mail
verification and some additional test
------------------------------------------------------------------------
r705 | alwarren | 2006-09-13 02:58:12 -0600 (Wed, 13 Sep 2006) | 1 line

FS#73 Change wording in comments mambot
------------------------------------------------------------------------
r704 | alwarren | 2006-09-13 02:41:03 -0600 (Wed, 13 Sep 2006) | 1 line

FS#54 Added spacers to toolbar in banner manager
------------------------------------------------------------------------
r703 | adi | 2006-09-12 23:34:45 -0600 (Tue, 12 Sep 2006) | 1 line

fix bug #63
------------------------------------------------------------------------
r702 | adi | 2006-09-12 23:15:12 -0600 (Tue, 12 Sep 2006) | 1 line

fix bug #57 & #64
------------------------------------------------------------------------
r701 | cauld | 2006-09-12 22:28:50 -0600 (Tue, 12 Sep 2006) | 1 line

! Updating MOS Rating to be a fully installable package for Mambo Raw
------------------------------------------------------------------------
r700 | cauld | 2006-09-12 17:01:15 -0600 (Tue, 12 Sep 2006) | 1 line

# Forgot to add the MOStlyDBAdmin classes folder on an earlier commit
------------------------------------------------------------------------
r699 | cauld | 2006-09-12 16:36:47 -0600 (Tue, 12 Sep 2006) | 1 line

! FS#60 — Modify News Feeds Items
------------------------------------------------------------------------
r698 | cauld | 2006-09-12 16:30:12 -0600 (Tue, 12 Sep 2006) | 1 line

# FS#55 — Update WebLinks Items
------------------------------------------------------------------------
r697 | cauld | 2006-09-12 16:17:48 -0600 (Tue, 12 Sep 2006) | 1 line

#  FS#53 — Change Banner Link
------------------------------------------------------------------------
r696 | cauld | 2006-09-12 16:11:52 -0600 (Tue, 12 Sep 2006) | 1 line

#  FS#68 — Help Screens Missing
------------------------------------------------------------------------
r695 | cauld | 2006-09-12 05:17:46 -0600 (Tue, 12 Sep 2006) | 1 line

! Pulling mosvote / MOS Rating from Mambo Raw edition
------------------------------------------------------------------------
r694 | cauld | 2006-09-11 23:38:01 -0600 (Mon, 11 Sep 2006) | 1 line

#  Fixing FS#69 — Absolute Path to MOStlyCE Template Directory
------------------------------------------------------------------------
r693 | cauld | 2006-09-11 23:30:28 -0600 (Mon, 11 Sep 2006) | 1 line

! Updating mostlyce admin xml file
------------------------------------------------------------------------
r692 | cauld | 2006-09-11 23:28:16 -0600 (Mon, 11 Sep 2006) | 5 lines

# Fixed MOStlyDBAdmin zip archive issue.  Was missing the zip.lib/php class.
! Updating directory listing on the universal installer screen
# Updating MOStlyCE Spellchecker plugin warning to notify user that CURL is now a requirement.
# Update VCard to prevent vcard link from displaying when contact has not been edited or where the contact params do not exist. (suggested by alwarren)
# Fixing some missing single quotes in some of the menu manager <script>alert code. This was causing a blank page when certain error conditions exist.  (suggested by alwarren)
------------------------------------------------------------------------
r691 | cauld | 2006-09-11 17:56:22 -0600 (Mon, 11 Sep 2006) | 1 line

# Changing install.php to us $mosConfig_lang = 'en' for configuration.php rather than 'english'.  Was causing issues with archive and create / modify dates.
------------------------------------------------------------------------
r690 | cauld | 2006-09-10 19:35:02 -0600 (Sun, 10 Sep 2006) | 2 lines

! Updating changelog.php
! Updating version.php
------------------------------------------------------------------------
r689 | cauld | 2006-09-10 19:08:23 -0600 (Sun, 10 Sep 2006) | 1 line

! Adding function mosLoadComponent back in to 4.6 based on 4.5.4 code.  
Looks like the function was dropped by mistake in the 4.6 core rewrite.
------------------------------------------------------------------------
r688 | neilt | 2006-09-08 12:21:44 -0600 (Fri, 08 Sep 2006) | 1 line

workarounds for $config_live_site problems on some linux hosts
------------------------------------------------------------------------
r687 | neilt | 2006-09-08 07:17:54 -0600 (Fri, 08 Sep 2006) | 1 line

# bugfix - hits not set to show as default in sql install
------------------------------------------------------------------------
r686 | neilt | 2006-09-08 04:36:52 -0600 (Fri, 08 Sep 2006) | 1 line

workaround to safemode gettext LANG/LC errors
------------------------------------------------------------------------
r685 | neilt | 2006-09-07 16:55:51 -0600 (Thu, 07 Sep 2006) | 1 line

makePathway span bug fixes - FS#51
------------------------------------------------------------------------
r684 | neilt | 2006-09-07 16:41:04 -0600 (Thu, 07 Sep 2006) | 1 line

minor code enhancements
------------------------------------------------------------------------
r683 | cauld | 2006-09-06 08:56:20 -0600 (Wed, 06 Sep 2006) | 1 line

! menubar.html.php html cleanup
------------------------------------------------------------------------
r682 | cauld | 2006-09-06 08:49:21 -0600 (Wed, 06 Sep 2006) | 1 line

# com_admin html cleanup on "check for updates"
------------------------------------------------------------------------
r681 | cauld | 2006-09-05 17:30:42 -0600 (Tue, 05 Sep 2006) | 2 lines

# Cleaning up the HTML in the Add-On installer to help it validate.
! Updating handleGlobals to protect against zend_hash_del_key_or_index hole
------------------------------------------------------------------------
r680 | cauld | 2006-09-05 16:22:41 -0600 (Tue, 05 Sep 2006) | 1 line

Applied all 4.5.4 SP2 fixes to the 4.6 branch were applicable.
------------------------------------------------------------------------
r679 | ninekrit | 2006-09-05 08:06:39 -0600 (Tue, 05 Sep 2006) | 1 line

update language variable for translation 
administrator/includes/pageNavigation.php:line 154,170
------------------------------------------------------------------------
r667 | neilt | 2006-08-30 11:41:39 -0600 (Wed, 30 Aug 2006) | 1 line

modifications to private messaging
------------------------------------------------------------------------
r666 | ninekrit | 2006-08-30 10:45:40 -0600 (Wed, 30 Aug 2006) | 1 line

+Update untranslated word 
------------------------------------------------------------------------
r665 | neilt | 2006-08-30 10:12:05 -0600 (Wed, 30 Aug 2006) | 1 line

bug fix : emails for private messages not sent to users when 'receive mail' ticked
------------------------------------------------------------------------
r664 | ninekrit | 2006-08-30 08:48:20 -0600 (Wed, 30 Aug 2006) | 1 line

Add <br />  line 40
------------------------------------------------------------------------
r663 | ninekrit | 2006-08-30 08:14:09 -0600 (Wed, 30 Aug 2006) | 1 line

FS#44 Menubar not traslations
------------------------------------------------------------------------
r662 | ninekrit | 2006-08-30 08:12:35 -0600 (Wed, 30 Aug 2006) | 1 line

FS#20,FS#44 edit language problem
------------------------------------------------------------------------
r660 | neilt | 2006-08-30 06:38:17 -0600 (Wed, 30 Aug 2006) | 1 line

adding CAPTCHA authentication to whats new
------------------------------------------------------------------------
r659 | cauld | 2006-08-29 23:12:38 -0600 (Tue, 29 Aug 2006) | 1 line

Another minor update to "What's New".
------------------------------------------------------------------------
r658 | cauld | 2006-08-29 22:56:43 -0600 (Tue, 29 Aug 2006) | 1 line

Updating the credits file to add Chanh as PM.  Also updating the 
"what's new" file for the 4.6 release.
------------------------------------------------------------------------
r657 | neilt | 2006-08-29 13:50:45 -0600 (Tue, 29 Aug 2006) | 1 line

help link and admin help modifications
------------------------------------------------------------------------
r656 | neilt | 2006-08-29 02:39:33 -0600 (Tue, 29 Aug 2006) | 1 line

minor sef bug fixes and code cleaning
------------------------------------------------------------------------
r655 | neilt | 2006-08-27 05:12:46 -0600 (Sun, 27 Aug 2006) | 1 line

fixed bug where archive form did not supply module id
------------------------------------------------------------------------
r654 | cauld | 2006-08-26 10:47:12 -0600 (Sat, 26 Aug 2006) | 1 line

Turning off comments in the sample Newsflash section by default.  Suggestion 
from Ricoflan.
------------------------------------------------------------------------
r653 | cauld | 2006-08-26 10:21:52 -0600 (Sat, 26 Aug 2006) | 1 line

Removing MamboLove entries from the sample data.
------------------------------------------------------------------------
r652 | cauld | 2006-08-26 10:11:46 -0600 (Sat, 26 Aug 2006) | 1 line

Fixing com_admin bug that was preventing help and preview template functions 
from working.  Left over from the new "Check from Updates" feature.
------------------------------------------------------------------------
r651 | cauld | 2006-08-26 09:34:47 -0600 (Sat, 26 Aug 2006) | 1 line

Fixed registration bug.  Warning messages were not displaying the correct 
string, but rather the defined constant name.
------------------------------------------------------------------------
r650 | chanh | 2006-08-24 16:54:33 -0600 (Thu, 24 Aug 2006) | 1 line

Fix for mysql 5 and remove duplicated code
------------------------------------------------------------------------
r649 | chanh | 2006-08-24 16:54:12 -0600 (Thu, 24 Aug 2006) | 1 line

Fix for mysql 5 and remove duplicated code
------------------------------------------------------------------------
r648 | neilt | 2006-08-24 11:06:01 -0600 (Thu, 24 Aug 2006) | 1 line

removed image upload on edit in banners as not adding to select list
------------------------------------------------------------------------
r647 | neilt | 2006-08-24 06:36:04 -0600 (Thu, 24 Aug 2006) | 1 line

captcha authentication added to contact component
------------------------------------------------------------------------
r646 | neilt | 2006-08-24 03:30:18 -0600 (Thu, 24 Aug 2006) | 1 line

Minor change to most read module to show hits
------------------------------------------------------------------------
r645 | cauld | 2006-08-23 22:29:08 -0600 (Wed, 23 Aug 2006) | 1 line

Updating the XML files for the components removed with Raw.  They were 
missing the CREATE TABLE statements and thus failing after install.
------------------------------------------------------------------------
r644 | cauld | 2006-08-23 19:23:54 -0600 (Wed, 23 Aug 2006) | 1 line

Pulling MOStlyDBAdmin out of Mambo Raw now that there is an installable 
package.
------------------------------------------------------------------------
r643 | neilt | 2006-08-23 01:43:51 -0600 (Wed, 23 Aug 2006) | 1 line

Bug fixes : Fixed double install message on module upload (FS#38). Fixed 
Comments component content item dropdown list disappearing behind other 
page content (FS#37).
------------------------------------------------------------------------
r642 | chanh | 2006-08-21 16:00:27 -0600 (Mon, 21 Aug 2006) | 1 line

Upgrade JSCookmenu to 2.0.1
------------------------------------------------------------------------
r641 | cauld | 2006-08-20 23:59:58 -0600 (Sun, 20 Aug 2006) | 1 line

Updating comments bot and component with new xml files based on those 
given to me by Neil.
------------------------------------------------------------------------
r640 | cauld | 2006-08-20 23:50:29 -0600 (Sun, 20 Aug 2006) | 1 line

Updating the MOStlyCE spellchecker plugin to the latest version, 1.0.2.
------------------------------------------------------------------------
r639 | cauld | 2006-08-20 23:46:53 -0600 (Sun, 20 Aug 2006) | 1 line

Checking in updated module xml files to allow for those removed in Raw to 
become fully installable / uninstallable modules.
------------------------------------------------------------------------
r638 | cauld | 2006-08-20 23:44:30 -0600 (Sun, 20 Aug 2006) | 1 line

Checking in updated mambot xml files to allow those removed with Raw to 
become fully installable / uninstallable mambots.
------------------------------------------------------------------------
r637 | cauld | 2006-08-20 23:41:33 -0600 (Sun, 20 Aug 2006) | 1 line

Adding com_weblink_items and weblink_items.xml.  This xml file was seperated 
from com_weblinks to allow weblinks to become a fully installable / uninstallable 
component.
------------------------------------------------------------------------
r636 | cauld | 2006-08-20 23:39:59 -0600 (Sun, 20 Aug 2006) | 1 line

Removing weblink_items.xml.  Will add back in under its own directory to 
allow weblinks to become a fully installable / uninstallable component.
------------------------------------------------------------------------
r635 | cauld | 2006-08-20 23:37:55 -0600 (Sun, 20 Aug 2006) | 1 line

Checking in updated admin component xml files to allow for fully installable 
components.  Focusing on those removed with Raw.
------------------------------------------------------------------------
r634 | cauld | 2006-08-20 10:40:45 -0600 (Sun, 20 Aug 2006) | 1 line

Clearing a few notices for the addon install
------------------------------------------------------------------------
r633 | cauld | 2006-08-20 10:32:00 -0600 (Sun, 20 Aug 2006) | 1 line

Adding the new one click Add-On Installer
------------------------------------------------------------------------
r632 | cauld | 2006-08-20 00:08:50 -0600 (Sun, 20 Aug 2006) | 1 line

Updating admin menus.  The new "addon installer" and "check for updates" 
features require php5+.  The options are now hidden in the menu when running 
php < 5.
------------------------------------------------------------------------
r631 | cauld | 2006-08-15 21:26:19 -0600 (Tue, 15 Aug 2006) | 1 line

Adding system menu entry for the "Check For Updates" feature
------------------------------------------------------------------------
r630 | cauld | 2006-08-15 21:24:45 -0600 (Tue, 15 Aug 2006) | 1 line

Checking in the new Mambo "Check For Updates" feature
------------------------------------------------------------------------
r629 | neilt | 2006-08-15 12:39:14 -0600 (Tue, 15 Aug 2006) | 1 line

bug fix for pollwindow.php error. (Flyspray #31)
------------------------------------------------------------------------
r628 | chanh | 2006-08-15 10:19:08 -0600 (Tue, 15 Aug 2006) | 1 line

add mosCreateMail for backward compatible per user feedback.
------------------------------------------------------------------------
r627 | cauld | 2006-08-07 22:54:18 -0600 (Mon, 07 Aug 2006) | 1 line

Mambo Raw changes
------------------------------------------------------------------------
r626 | cauld | 2006-08-07 22:39:43 -0600 (Mon, 07 Aug 2006) | 1 line

More changes for Mambo Raw
------------------------------------------------------------------------
r625 | cauld | 2006-08-07 17:26:47 -0600 (Mon, 07 Aug 2006) | 1 line

Adding Raw files to be used in building a raw core version of Mambo.
------------------------------------------------------------------------
r619 | neilt | 2006-08-02 09:02:53 -0600 (Wed, 02 Aug 2006) | 1 line

modification to retain comment text if captcha image misread
------------------------------------------------------------------------
r618 | neilt | 2006-07-31 05:43:43 -0600 (Mon, 31 Jul 2006) | 1 line

bug fix - Move Category Reports Errors (when category is empty) FS#22
------------------------------------------------------------------------
r617 | neilt | 2006-07-31 04:53:05 -0600 (Mon, 31 Jul 2006) | 1 line

bug fix - Load Module Positions Mambot Parameters Failure FS#7 
------------------------------------------------------------------------
r616 | neilt | 2006-07-29 13:20:21 -0600 (Sat, 29 Jul 2006) | 1 line

general *.html.php code tidy up
------------------------------------------------------------------------
r615 | neilt | 2006-07-29 11:00:02 -0600 (Sat, 29 Jul 2006) | 1 line

update of jscookmenu details
------------------------------------------------------------------------
r614 | neilt | 2006-07-29 06:33:32 -0600 (Sat, 29 Jul 2006) | 1 line

bug fix to userstate session to retain search, section, category and author 
values
------------------------------------------------------------------------
r613 | neilt | 2006-07-26 08:49:44 -0600 (Wed, 26 Jul 2006) | 1 line

Modifications to allow the display of static content in the frontpage component, 
adjustment of default admin list limit to 50
------------------------------------------------------------------------
r612 | neilt | 2006-07-25 06:34:33 -0600 (Tue, 25 Jul 2006) | 1 line

bug fixes to allow correct email submissions for weblinks and registration
------------------------------------------------------------------------
r611 | neilt | 2006-07-23 11:59:26 -0600 (Sun, 23 Jul 2006) | 1 line

small bug fixes
------------------------------------------------------------------------
r610 | neilt | 2006-07-18 06:39:51 -0600 (Tue, 18 Jul 2006) | 1 line

modification to remove redundant help icon (Flyspray FS#14)
------------------------------------------------------------------------
r609 | neilt | 2006-07-18 06:18:02 -0600 (Tue, 18 Jul 2006) | 1 line

bug fix to allow show/hide of section/category description and description 
image
------------------------------------------------------------------------
r608 | cauld | 2006-07-16 18:57:52 -0600 (Sun, 16 Jul 2006) | 1 line

Updating some sample content and adding a few new "other menu" items.
------------------------------------------------------------------------
r607 | cauld | 2006-07-16 18:56:47 -0600 (Sun, 16 Jul 2006) | 1 line

Updating admin help link.
------------------------------------------------------------------------
r606 | cauld | 2006-07-16 18:55:19 -0600 (Sun, 16 Jul 2006) | 1 line

Updating some embedded help items.
------------------------------------------------------------------------
r605 | cauld | 2006-07-16 13:14:36 -0600 (Sun, 16 Jul 2006) | 1 line

Updating mod_quickicon based on a suggested fix from Apree.  Changing from 
fixed sizing to percentages to help with the proper display of these icons.
------------------------------------------------------------------------
r604 | cauld | 2006-07-16 13:02:53 -0600 (Sun, 16 Jul 2006) | 1 line

Updating admin com_modules to clear warnings.
------------------------------------------------------------------------
r603 | cauld | 2006-07-16 13:00:44 -0600 (Sun, 16 Jul 2006) | 1 line

Updating the post installation survey so that it hyperlinks to the security 
signup form rather than emails a specific email address.
------------------------------------------------------------------------
r602 | cauld | 2006-07-16 12:58:50 -0600 (Sun, 16 Jul 2006) | 1 line

Removing basic TinyMCE editor in favor of the new default MOStlyCE editor 
based on TinyMCE.
------------------------------------------------------------------------
r601 | neilt | 2006-07-16 02:52:05 -0600 (Sun, 16 Jul 2006) | 1 line

removal of reserved words from comments component
------------------------------------------------------------------------
r600 | cauld | 2006-07-12 23:10:15 -0600 (Wed, 12 Jul 2006) | 1 line

updating changelog.php
------------------------------------------------------------------------
r599 | chanh | 2006-07-12 15:17:48 -0600 (Wed, 12 Jul 2006) | 1 line

Upgrade to JSCookMenu v1.4.4. to fix menu show to the extreme left in IE7.
------------------------------------------------------------------------
r598 | neilt | 2006-07-12 06:47:20 -0600 (Wed, 12 Jul 2006) | 1 line

configuration changes for captcha security
------------------------------------------------------------------------
r597 | neilt | 2006-07-12 03:59:15 -0600 (Wed, 12 Jul 2006) | 1 line

fixed contact form send and vcard download issues
------------------------------------------------------------------------
r596 | neilt | 2006-07-11 06:14:10 -0600 (Tue, 11 Jul 2006) | 1 line

captcha code moved into the core to allow for more global inclusion. 
Administration configuration amended to enable or disable
------------------------------------------------------------------------
r595 | ninekrit | 2006-07-09 20:52:07 -0600 (Sun, 09 Jul 2006) | 1 line

Update Thai Language
------------------------------------------------------------------------
r593 | neilt | 2006-07-07 12:06:17 -0600 (Fri, 07 Jul 2006) | 1 line

Updated ttf fonts to GPL
------------------------------------------------------------------------
r592 | neilt | 2006-07-07 11:48:38 -0600 (Fri, 07 Jul 2006) | 1 line

spam fix font files added
------------------------------------------------------------------------
r591 | neilt | 2006-07-07 11:47:27 -0600 (Fri, 07 Jul 2006) | 1 line

Comments component spam protection and fonts updated with new GPL version 
3.4 and small session enhancements
------------------------------------------------------------------------
r590 | neilt | 2006-07-07 01:59:57 -0600 (Fri, 07 Jul 2006) | 1 line

New comments component and mambot uploaded along with language files, help 
files and modifications to the SQL install
------------------------------------------------------------------------
r589 | chanh | 2006-07-06 12:20:44 -0600 (Thu, 06 Jul 2006) | 1 line

The textarea box is too small when not using WYSIWYG editor so make it a 
little bigger for ease of editing.
------------------------------------------------------------------------
r588 | cauld | 2006-07-04 15:41:33 -0600 (Tue, 04 Jul 2006) | 1 line

Fixing menu manager message displayed when multiple menu items were removed.  
Was not displaying the total, but rather each item.
------------------------------------------------------------------------
r587 | cauld | 2006-07-04 15:25:31 -0600 (Tue, 04 Jul 2006) | 1 line

Fixing broken com_trash multi-item selection for delete
------------------------------------------------------------------------
r586 | cauld | 2006-07-03 16:43:23 -0600 (Mon, 03 Jul 2006) | 1 line

Fixing a roothpath issue that was causing IIS to fail.

-------------------- 4.6 (RC2) Release ---------------------------------

r584 | cauld | 2006-07-02 14:02:19 -0600 (Sun, 02 Jul 2006) | 1 line

Fixing MySQL 5 params NOT NULL issue.  Allowing default to be NULL for 
components, modules, and mambots.  A broader fix will happen with v5.
------------------------------------------------------------------------
r583 | cauld | 2006-07-02 11:05:31 -0600 (Sun, 02 Jul 2006) | 1 line

Eliminating the use of realpath() to determine dynamic URLs.  This was 
creating issues with some shared host plans.
------------------------------------------------------------------------
r582 | cauld | 2006-06-22 22:17:06 -0600 (Thu, 22 Jun 2006) | 1 line

MOStlyCE config change to fix Javascript errors.  Now not loading several 
external plugins (ex) htmltemplate, mambo, etc.  These were not written for 
TinyMCE 2.x and therefore do not work.  Will have to revisit at a later time.
------------------------------------------------------------------------
r581 | cauld | 2006-06-22 21:32:32 -0600 (Thu, 22 Jun 2006) | 1 line

MOStlyCE Admin change to remove onclick config section.
------------------------------------------------------------------------
r580 | cauld | 2006-06-20 11:43:43 -0600 (Tue, 20 Jun 2006) | 1 line

turning off MOStlyCE compression by default until the compressor works in IE.
------------------------------------------------------------------------
r579 | csouza | 2006-06-20 05:54:04 -0600 (Tue, 20 Jun 2006) | 1 line

removing charset conversion button from language form
------------------------------------------------------------------------
------------------------------------------------------------------------
r577 | cauld | 2006-06-20 00:05:22 -0600 (Tue, 20 Jun 2006) | 1 line

adding some missing / unversioned MOStlyCE files
------------------------------------------------------------------------
r576 | cauld | 2006-06-20 00:01:27 -0600 (Tue, 20 Jun 2006) | 1 line

tweaking MOStlyCE based on the 4.5.4 MOStlyCE feedback in the forums
------------------------------------------------------------------------
r575 | cauld | 2006-06-19 23:17:39 -0600 (Mon, 19 Jun 2006) | 1 line

committing weblinks SQL injection fix
------------------------------------------------------------------------
r572 | cauld | 2006-06-18 11:53:59 -0600 (Sun, 18 Jun 2006) | 1 line

! changing mambo.sql to fix utf8 / mysql 5 issue with #__core_acl_aro.
------------------------------------------------------------------------
r571 | cauld | 2006-06-18 11:22:02 -0600 (Sun, 18 Jun 2006) | 1 line

! Turning off MOStlyCE compression by default since it doesn't work in IE.  
Adding warning to tip so users see why it is off.  OK and recommended for use with FF.
------------------------------------------------------------------------
r570 | neilt | 2006-06-18 04:04:34 -0600 (Sun, 18 Jun 2006) | 1 line

commit test
------------------------------------------------------------------------
r569 | chanh | 2006-06-17 22:47:09 -0600 (Sat, 17 Jun 2006) | 1 line

Make a comment commit on SG SVN to make sure the commit work
------------------------------------------------------------------------
r568 | cauld | 2006-06-17 19:13:30 -0600 (Sat, 17 Jun 2006) | 1 line

!test commit against Mambo's new SVN repository
------------------------------------------------------------------------
r567 | chanh | 2006-06-16 13:03:24 -0600 (Fri, 16 Jun 2006) | 1 line

Fix bug with STRICT_TRANS_TABLES cause installer to fail in mysql 5 when 
install module and mambot
------------------------------------------------------------------------
r566 | csouza | 2006-06-14 06:50:53 -0600 (Wed, 14 Jun 2006) | 1 line

updated brazilian portuguese glossary
------------------------------------------------------------------------
r565 | cauld | 2006-06-13 21:58:48 -0600 (Tue, 13 Jun 2006) | 1 line

!Changing format of CHANGELOG to use the SVN log.  Easier to maintain.
------------------------------------------------------------------------
r564 | cauld | 2006-06-13 21:17:10 -0600 (Tue, 13 Jun 2006) | 2 lines

!updating mostlyce.php and mostlyce.xml based on recent test for 454.  
Fixing paste plugin issue.
------------------------------------------------------------------------
r563 | csouza | 2006-06-11 10:05:40 -0600 (Sun, 11 Jun 2006) | 1 line

bug fix in language charset conversion
------------------------------------------------------------------------
r562 | csouza | 2006-06-10 11:37:53 -0600 (Sat, 10 Jun 2006) | 1 line

updated .pot templates
------------------------------------------------------------------------
r560 | csouza | 2006-06-07 02:35:31 -0600 (Wed, 07 Jun 2006) | 1 line

language - updated .pot templates
------------------------------------------------------------------------
r557 | csouza | 2006-06-07 02:21:25 -0600 (Wed, 07 Jun 2006) | 1 line

including italian, thai and brazilian portuguese language files for the rc. These should be installable.
------------------------------------------------------------------------
r556 | csouza | 2006-06-07 02:15:51 -0600 (Wed, 07 Jun 2006) | 1 line

internationalization modifications
------------------------------------------------------------------------
r555 | cauld | 2006-05-31 21:26:19 -0600 (Wed, 31 May 2006) | 4 lines

! removing all mentions of mamboforge and replacing with mamboxchange or something else like The Source.
! updating the support page to update links, add better wording, etc.
! updating version.php for RC2
------------------------------------------------------------------------
r554 | csouza | 2006-05-31 10:52:24 -0600 (Wed, 31 May 2006) | 1 line

minor tweaks to HTML_admin_misc::help() in admin.admin.html.php
------------------------------------------------------------------------
r553 | csouza | 2006-05-31 10:49:28 -0600 (Wed, 31 May 2006) | 1 line

replaced help files with xhtml compliant ones with title tag needed for help index
------------------------------------------------------------------------
r552 | csouza | 2006-05-30 17:38:18 -0600 (Tue, 30 May 2006) | 1 line

removed obsolete help screens
------------------------------------------------------------------------
r551 | csouza | 2006-05-30 17:35:27 -0600 (Tue, 30 May 2006) | 1 line

final installment of new and renamed help screens and component toolbars changed to reflect new naming.
------------------------------------------------------------------------
r550 | csouza | 2006-05-29 11:21:00 -0600 (Mon, 29 May 2006) | 1 line

first installment of new and renamed help screens and component toolbars changed to reflect new naming
------------------------------------------------------------------------
r549 | cauld | 2006-05-26 21:42:35 -0600 (Fri, 26 May 2006) | 2 lines

! Updated "What's new" & "Credits"
------------------------------------------------------------------------
r548 | cauld | 2006-05-26 20:05:58 -0600 (Fri, 26 May 2006) | 2 lines

+ Adding new site templates (Donated by Water&Stone, coded by Nalisa)
------------------------------------------------------------------------
r533 | csouza | 2006-05-22 08:32:01 -0600 (Mon, 22 May 2006) | 1 line

fixed some bugs caused by index.php cleanup
------------------------------------------------------------------------
r532 | csouza | 2006-05-21 03:41:05 -0600 (Sun, 21 May 2006) | 1 line

moved commented 'ErrorHandler' class in index.php to includes/core.classes.php
------------------------------------------------------------------------
r531 | cauld | 2006-05-20 18:54:45 -0600 (Sat, 20 May 2006) | 1 line

cauld:  (trivial) correcting a few spelling errors
------------------------------------------------------------------------
r530 | csouza | 2006-05-20 17:17:51 -0600 (Sat, 20 May 2006) | 1 line

corrected mambocore->rootpath in includes/core.classes.php and added phpdoc templates to undocumented classes
------------------------------------------------------------------------
r529 | csouza | 2006-05-20 15:01:36 -0600 (Sat, 20 May 2006) | 1 line

moved classes in index.php to includes/core.classes.php
------------------------------------------------------------------------
r528 | cauld | 2006-05-20 14:57:10 -0600 (Sat, 20 May 2006) | 1 line

cauld:  # Fixing a Offline bug which caused an error rather than the offline message when MySQL was down
------------------------------------------------------------------------
r524 | neilt | 2006-05-19 06:18:36 -0600 (Fri, 19 May 2006) | 1 line

general javascript and formatting bug fixes
------------------------------------------------------------------------
r523 | neilt | 2006-05-19 00:20:15 -0600 (Fri, 19 May 2006) | 1 line

Fixed Trac Ticket #86
------------------------------------------------------------------------
r521 | cauld | 2006-05-16 22:54:20 -0600 (Tue, 16 May 2006) | 1 line

cauld - # Rewrote uninstall_template() to fix bug where the wrong template dir was removed
------------------------------------------------------------------------
r520 | neilt | 2006-05-16 07:13:53 -0600 (Tue, 16 May 2006) | 1 line

Modification to center menubar labels
------------------------------------------------------------------------
r517 | neilt | 2006-05-16 06:05:37 -0600 (Tue, 16 May 2006) | 1 line

bug fix
------------------------------------------------------------------------
r516 | neilt | 2006-05-16 03:44:41 -0600 (Tue, 16 May 2006) | 1 line

minor bug fixes
------------------------------------------------------------------------
r515 | cauld | 2006-05-15 22:20:58 -0600 (Mon, 15 May 2006) | 1 line

cauld - fixing minor mis-spelling
------------------------------------------------------------------------
r514 | neilt | 2006-05-15 06:52:09 -0600 (Mon, 15 May 2006) | 1 line

inclusion of .message class in front end css
------------------------------------------------------------------------
r512 | cauld | 2006-05-14 17:16:29 -0600 (Sun, 14 May 2006) | 2 lines

cauld - Added the uploadfiles dir to the installation write permission check

------------------------------------------------------------------------
r511 | cauld | 2006-05-14 16:22:54 -0600 (Sun, 14 May 2006) | 1 line

cauld - missed a few weblink name changes.
------------------------------------------------------------------------
r510 | cauld | 2006-05-14 15:46:22 -0600 (Sun, 14 May 2006) | 1 line

cauld:  Standardized / Updated the label for New Feeds for the whole app (aka: Newsfeeds)
------------------------------------------------------------------------
r509 | cauld | 2006-05-14 15:14:22 -0600 (Sun, 14 May 2006) | 1 line

cauld:  Updated MOStlyCE spellchecker plugin tip
------------------------------------------------------------------------
r508 | cauld | 2006-05-14 14:48:05 -0600 (Sun, 14 May 2006) | 3 lines

! Updated the "What's New" help doc
! Standardized / Updated the label for Web Links for the whole app (aka: Weblinks)
------------------------------------------------------------------------
r507 | cauld | 2006-05-13 19:23:34 -0600 (Sat, 13 May 2006) | 7 lines

! Upgraded MOStlyCE's guts to TinyMCE 2.0.6.1 (bugs fixes, enhancements, etc)
+ Added a layers plugin to MOStlyCE and an experimental spellchecker plugin (works well in IE)
+ Added options in MOStlyCE Admin to control layer & spellchecker plugins
! Various other minor MOStlyCE tweaks and enhancements
------------------------------------------------------------------------
r506 | adi | 2006-05-13 00:03:27 -0600 (Sat, 13 May 2006) | 1 line

fix trac #85
------------------------------------------------------------------------
r505 | cauld | 2006-05-11 06:54:09 -0600 (Thu, 11 May 2006) | 1 line

cauld - fixing mambo.sql table prefix bug
------------------------------------------------------------------------
r504 | neilt | 2006-05-01 11:55:35 -0600 (Mon, 01 May 2006) | 1 line

Fixed errors occuring whilst copying empty sections - Trac #83
------------------------------------------------------------------------
r502 | cauld | 2006-04-30 14:57:33 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - Updating MOStlyCE Admin to handle the language file structure change.
------------------------------------------------------------------------
r500 | cauld | 2006-04-30 14:27:06 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - checking in tinymce 2.0.5.1
------------------------------------------------------------------------
r499 | cauld | 2006-04-30 13:02:06 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - For whatever reason the last time I tried to commit the new version of
the MOStlyCE mambot it disappeared.  Trying again.
------------------------------------------------------------------------
r497 | cauld | 2006-04-30 12:23:50 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - Removing old basic TinyMCE 2.0.1, will replace with TinyMCE 2.0.5.1.
Tons of enhancements and bug fixes.
------------------------------------------------------------------------
r496 | cauld | 2006-04-30 12:18:38 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - Rolling MOStlyCE Admin back to v1.5 since the Img & File mgr plugins have been pulled.
------------------------------------------------------------------------
r495 | cauld | 2006-04-30 12:10:47 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - Checking in MOStlyCE 1.7 mambot.  Now using TinyMCE 2.0.5.1.
The image mgr and file mgr plugins have been pulled for compatibility reasons.
------------------------------------------------------------------------
r494 | cauld | 2006-04-30 12:05:15 -0600 (Sun, 30 Apr 2006) | 1 line

cauld - Removing the old mostlyce install.  I will be bringing in a fresh
version with the most recent TinyMCE 2.0.5.1 guts.  I didn't want to deal with
new files vs deleted files, etc.  Just easier to replace the whole darn thing :)
------------------------------------------------------------------------
r493 | neilt | 2006-04-27 11:43:45 -0600 (Thu, 27 Apr 2006) | 1 line

Missing argument 6 for moscomponentusermanager() - Trac #81
------------------------------------------------------------------------
r492 | neilt | 2006-04-26 15:31:58 -0600 (Wed, 26 Apr 2006) | 2 lines

Fixed empty admin module bugs
Fixed bugs adding new content with no section / categories

-------------------- 4.6 (RC1) Release ---------------------------------

------------------------------------------------------------------------
r491 | csouza | 2006-04-23 16:43:10 -0600 (Sun, 23 Apr 2006) | 1 line

fix javascript language bugs and mosmenubar::help()
------------------------------------------------------------------------
r490 | cauld | 2006-04-23 10:39:53 -0600 (Sun, 23 Apr 2006) | 1 line

cauld - fixing Image Manager plugin image list bug.
------------------------------------------------------------------------
r489 | cauld | 2006-04-23 01:35:31 -0600 (Sun, 23 Apr 2006) | 1 line

cauld - Big commit here for the newly configured MOStlyCE Image & File Manager plugins.  Also contains the new MOStlyCE Admin tabs that go along with these.
------------------------------------------------------------------------
r488 | neilt | 2006-04-22 14:46:52 -0600 (Sat, 22 Apr 2006) | 1 line

non purged multiple session problems fixed. Trac #79
------------------------------------------------------------------------
r487 | counterpoint | 2006-04-22 02:49:01 -0600 (Sat, 22 Apr 2006) | 1 line

Further relaxation of Itemid check to avoid "not authorized" errors
------------------------------------------------------------------------
r486 | counterpoint | 2006-04-21 11:08:02 -0600 (Fri, 21 Apr 2006) | 1 line

Fix bug in showing "shortcut" icon
------------------------------------------------------------------------
r485 | counterpoint | 2006-04-21 07:10:48 -0600 (Fri, 21 Apr 2006) | 1 line

Modified search mambots to include correct Itemid and prevent search results from being blocked by "unauthorized access"
------------------------------------------------------------------------
r484 | cauld | 2006-04-20 12:37:58 -0600 (Thu, 20 Apr 2006) | 1 line

cauld - updating version.php for Monday's RC1 release.
------------------------------------------------------------------------
r483 | csouza | 2006-04-19 07:17:58 -0600 (Wed, 19 Apr 2006) | 1 line

Language Manager Javascript and bug fixes
------------------------------------------------------------------------
r482 | neilt | 2006-04-19 02:17:21 -0600 (Wed, 19 Apr 2006) | 1 line

addition of missing index.html files to numerous folders
------------------------------------------------------------------------
r481 | counterpoint | 2006-04-18 10:54:46 -0600 (Tue, 18 Apr 2006) | 1 line

Small bug fixes to text items
------------------------------------------------------------------------
r479 | counterpoint | 2006-04-16 09:27:34 -0600 (Sun, 16 Apr 2006) | 1 line

Patch installer and file permission bug fixes note.
------------------------------------------------------------------------
r478 | counterpoint | 2006-04-16 09:25:59 -0600 (Sun, 16 Apr 2006) | 2 lines

Patch installer and file handling bug fixes
------------------------------------------------------------------------
r477 | counterpoint | 2006-04-16 09:25:27 -0600 (Sun, 16 Apr 2006) | 1 line

Patch installer
------------------------------------------------------------------------
r475 | counterpoint | 2006-04-15 02:28:04 -0600 (Sat, 15 Apr 2006) | 1 line

Added code to put admin side custom modules into effect, not including RSS feeds.
------------------------------------------------------------------------
r474 | neilt | 2006-04-13 10:21:17 -0600 (Thu, 13 Apr 2006) | 1 line

Atom 1.0 changes
------------------------------------------------------------------------
r473 | counterpoint | 2006-04-13 10:18:01 -0600 (Thu, 13 Apr 2006) | 1 line

Modified to process the XML for language package installation.
------------------------------------------------------------------------
r472 | counterpoint | 2006-04-13 09:38:43 -0600 (Thu, 13 Apr 2006) | 1 line

Extended XML tags for installing language packages.
------------------------------------------------------------------------
r471 | neilt | 2006-04-13 07:29:26 -0600 (Thu, 13 Apr 2006) | 1 line

minor changes to dates and path
------------------------------------------------------------------------
r470 | neilt | 2006-04-13 04:02:43 -0600 (Thu, 13 Apr 2006) | 2 lines

Corrected declaration and assigning of 3 new field values
$item_created, $item_modified and $item_author
------------------------------------------------------------------------
r469 | neilt | 2006-04-13 03:52:39 -0600 (Thu, 13 Apr 2006) | 4 lines

Removal of depricated Atom0.3 syndication
Addition of Atom1.0 standards and RSS feed image
Modifications to language files
Trac #72
------------------------------------------------------------------------
r468 | cauld | 2006-04-12 23:11:44 -0600 (Wed, 12 Apr 2006) | 1 line

cauld - fixing mospagebreak to work with php 4 & 5
------------------------------------------------------------------------
r467 | csouza | 2006-04-12 21:55:19 -0600 (Wed, 12 Apr 2006) | 3 lines

Language fixes
export language functionality
italian language translations
------------------------------------------------------------------------
r464 | chanh | 2006-04-12 13:59:36 -0600 (Wed, 12 Apr 2006) | 1 line

Fix missing cid variable for backward compatible with 3PD component.
------------------------------------------------------------------------
r462 | cauld | 2006-04-11 23:47:58 -0600 (Tue, 11 Apr 2006) | 1 line

cauld - updating version.php with RC1 details
------------------------------------------------------------------------
r461 | cauld | 2006-04-11 23:45:32 -0600 (Tue, 11 Apr 2006) | 1 line

cauld - adding uploadfiles dir for MOStlyDBAdmin local restore function
------------------------------------------------------------------------
r460 | cauld | 2006-04-11 23:44:29 -0600 (Tue, 11 Apr 2006) | 1 line

cauld - Commenting out the containers component for now since we are about to
put out 4.6 RC1 and this is not ready.
------------------------------------------------------------------------
r458 | counterpoint | 2006-04-11 08:36:50 -0600 (Tue, 11 Apr 2006) | 1 line

Fixed problem with newly created menu not appearing; other minor bugs
------------------------------------------------------------------------
r456 | cauld | 2006-04-10 20:01:42 -0600 (Mon, 10 Apr 2006) | 1 line

cauld - Committing the last major revision of MOStlyCE for 4.6, version 1.6.
------------------------------------------------------------------------
r455 | cauld | 2006-04-10 19:55:50 -0600 (Mon, 10 Apr 2006) | 1 line

cauld - Checking in the last major revision of MOStlyCE Admin for 4.6, version 1.5.
------------------------------------------------------------------------
r454 | cauld | 2006-04-10 19:48:15 -0600 (Mon, 10 Apr 2006) | 1 line

cauld - Checking in updated overlib_mini.js.  We are running version 4.0 which is really old.
Updating us to the latest version 4.21.
------------------------------------------------------------------------
r453 | neilt | 2006-04-07 06:51:31 -0600 (Fri, 07 Apr 2006) | 1 line

Fixed problem with html in parameters textfield within the admin modules. Trac ticket #73
------------------------------------------------------------------------
r452 | neilt | 2006-04-07 06:30:18 -0600 (Fri, 07 Apr 2006) | 1 line

fixed missing close </tr> tags in admin module
------------------------------------------------------------------------
r450 | neilt | 2006-04-06 12:41:09 -0600 (Thu, 06 Apr 2006) | 1 line

Bug fixes within the Admin Modules
------------------------------------------------------------------------
r449 | counterpoint | 2006-04-05 12:41:48 -0600 (Wed, 05 Apr 2006) | 1 line

Modification to relax check on Itemid for components not having menu entries
------------------------------------------------------------------------
r448 | neilt | 2006-04-03 12:37:56 -0600 (Mon, 03 Apr 2006) | 1 line

Changed 2 labels in poll component to Question from Title
------------------------------------------------------------------------
r447 | counterpoint | 2006-04-03 11:51:53 -0600 (Mon, 03 Apr 2006) | 1 line

Modification to avoid over complex search and replace of #__ in database query strings
------------------------------------------------------------------------
r446 | counterpoint | 2006-04-03 07:47:34 -0600 (Mon, 03 Apr 2006) | 1 line

Small bug fixes and optimisation
------------------------------------------------------------------------
r445 | counterpoint | 2006-04-03 07:30:46 -0600 (Mon, 03 Apr 2006) | 1 line

Add user side of containers component (forgotten!)
------------------------------------------------------------------------
r444 | neilt | 2006-04-03 05:58:09 -0600 (Mon, 03 Apr 2006) | 1 line

Added The Source URL to weblinks, Mambo Foundation and The Source links to Other Menu
------------------------------------------------------------------------
r443 | neilt | 2006-04-03 05:51:01 -0600 (Mon, 03 Apr 2006) | 2 lines

Added The Source URL to weblinks (Trac #63)
Added Mambo Foundation and The Source links in Other Menu and changed title to show (Trac #71)
------------------------------------------------------------------------
r442 | counterpoint | 2006-04-03 02:46:54 -0600 (Mon, 03 Apr 2006) | 1 line

Bug fix uninstaller error with array merge
------------------------------------------------------------------------
r440 | cauld | 2006-04-02 20:40:16 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - Updating MOStlyDBAdmin.xml file
------------------------------------------------------------------------
r439 | cauld | 2006-04-02 17:33:27 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - Adding the new MOStlyDBAdmin component for db backup and restore functionality.
------------------------------------------------------------------------
r438 | cauld | 2006-04-02 15:34:16 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - Making a quick mod to the MOStlyCE $adminside check
------------------------------------------------------------------------
r437 | neilt | 2006-04-02 14:07:50 -0600 (Sun, 02 Apr 2006) | 1 line

incomplete <?php tag fixed in pathway.php
------------------------------------------------------------------------
r435 | cauld | 2006-04-02 13:37:55 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - Committing the MOStlyCE v1.4 Admin component (major overhaul)
------------------------------------------------------------------------
r434 | cauld | 2006-04-02 13:34:14 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - Commiting the MOStlyCE v1.5 mambot (major overhaul)
------------------------------------------------------------------------
r433 | cauld | 2006-04-02 13:27:50 -0600 (Sun, 02 Apr 2006) | 1 line

cauld - MOStlyCE work: removing imgmanager, filemanager, & preview plugins.
Also removed auth_mostlyce.php.
------------------------------------------------------------------------
r432 | counterpoint | 2006-04-01 01:30:03 -0700 (Sat, 01 Apr 2006) | 1 line

Add Mambo Containers admin side component.
------------------------------------------------------------------------
r431 | neilt | 2006-03-31 04:13:07 -0700 (Fri, 31 Mar 2006) | 1 line

changed admin to show advanced_mode as default
------------------------------------------------------------------------
r430 | adi | 2006-03-31 03:55:04 -0700 (Fri, 31 Mar 2006) | 1 line

fix bugs #8109
------------------------------------------------------------------------
r429 | neilt | 2006-03-30 12:19:21 -0700 (Thu, 30 Mar 2006) | 6 lines

Fixed mod_latest_content no content error
Fixed handlers in mod_latest_content
Corrected cases in mod_latest_content
Removed mod_latest_content fixed width limit in horizontal td case
Fixed bug in content.class.php getBlogSectionCount() not returning 0 count
Module mod_latest_content changed to default unpublished
------------------------------------------------------------------------
r428 | adi | 2006-03-29 01:20:05 -0700 (Wed, 29 Mar 2006) | 1 line

fixed bugs #8118
------------------------------------------------------------------------
r426 | neilt | 2006-03-28 12:09:32 -0700 (Tue, 28 Mar 2006) | 1 line

omission of echo in <?php T_('... statements
------------------------------------------------------------------------
r425 | counterpoint | 2006-03-27 09:09:50 -0700 (Mon, 27 Mar 2006) | 1 line

Optimisation and bug fix for ampersand processing in the universal installer.
------------------------------------------------------------------------
r424 | cauld | 2006-03-26 21:11:14 -0700 (Sun, 26 Mar 2006) | 1 line

cauld - updating security list email address on installation survey
------------------------------------------------------------------------
r423 | counterpoint | 2006-03-23 09:32:52 -0700 (Thu, 23 Mar 2006) | 1 line

Bug fix to stop foreach on null failure.
------------------------------------------------------------------------
r422 | counterpoint | 2006-03-22 11:41:29 -0700 (Wed, 22 Mar 2006) | 1 line

Optimisation of menu types handling, mostlyce.php request for template.  Fixed
admin side failure to consistently find session data.  Reorganised admin side to
ignore repeated logins.  Fixed offline check validation of admin session.
------------------------------------------------------------------------
r421 | counterpoint | 2006-03-22 01:29:54 -0700 (Wed, 22 Mar 2006) | 1 line

Hardening of contact component.
------------------------------------------------------------------------
r420 | counterpoint | 2006-03-22 01:29:28 -0700 (Wed, 22 Mar 2006) | 1 line

Optimisation of admin user and session management
------------------------------------------------------------------------
r419 | counterpoint | 2006-03-21 11:12:17 -0700 (Tue, 21 Mar 2006) | 1 line

Optimisation and modified document root discovery.
------------------------------------------------------------------------
r418 | counterpoint | 2006-03-21 11:11:00 -0700 (Tue, 21 Mar 2006) | 1 line

Changes to include index.php to establish the environment for editor popups.
Optimisation of requests for information about the current user's ACL status.
------------------------------------------------------------------------
r417 | counterpoint | 2006-03-21 11:06:53 -0700 (Tue, 21 Mar 2006) | 1 line

Optimisation, merging of mosDBTable and mosDBTableEntry methods.
------------------------------------------------------------------------
r416 | cauld | 2006-03-20 22:44:47 -0700 (Mon, 20 Mar 2006) | 1 line

cauld - Adding a donation icon to the new installation survey
------------------------------------------------------------------------
r415 | csouza | 2006-03-20 18:29:11 -0700 (Mon, 20 Mar 2006) | 1 line

changes to com_admin/admin.admin.html.php to grab local help files
------------------------------------------------------------------------
r413 | csouza | 2006-03-20 18:24:13 -0700 (Mon, 20 Mar 2006) | 1 line

changes to com_admin/admin.admin.html.php to grab local help files
------------------------------------------------------------------------
r412 | csouza | 2006-03-20 18:19:39 -0700 (Mon, 20 Mar 2006) | 1 line

changes to com_admin/admin.admin.html.php to grab local help files
------------------------------------------------------------------------
r411 | csouza | 2006-03-20 18:10:48 -0700 (Mon, 20 Mar 2006) | 1 line

changes to com_admin/admin.admin.html.php to grab local help files
------------------------------------------------------------------------
r410 | csouza | 2006-03-20 17:58:54 -0700 (Mon, 20 Mar 2006) | 1 line

mod to pull help screens locally
------------------------------------------------------------------------
r409 | csouza | 2006-03-20 17:22:21 -0700 (Mon, 20 Mar 2006) | 1 line

language stuff
------------------------------------------------------------------------
r408 | csouza | 2006-03-20 16:47:49 -0700 (Mon, 20 Mar 2006) | 1 line

language defaults in install4.php
------------------------------------------------------------------------
r406 | cauld | 2006-03-19 18:03:14 -0700 (Sun, 19 Mar 2006) | 1 line

cauld - Fixing MOStlyCE print plugin and disabling preview plugin in favor
own Mambo's preview option.
------------------------------------------------------------------------
r403 | csouza | 2006-03-19 13:41:39 -0700 (Sun, 19 Mar 2006) | 1 line

language manager
------------------------------------------------------------------------
r402 | counterpoint | 2006-03-19 07:32:34 -0700 (Sun, 19 Mar 2006) | 1 line

Extended new contact popup for linking to user, so as to show both full name and user name.
------------------------------------------------------------------------
r401 | counterpoint | 2006-03-19 03:28:33 -0700 (Sun, 19 Mar 2006) | 1 line

Recorded changes to restore functioning of popups.
------------------------------------------------------------------------
r400 | counterpoint | 2006-03-19 03:22:44 -0700 (Sun, 19 Mar 2006) | 1 line

Reinstate popup changes that had got lost
------------------------------------------------------------------------
r397 | cauld | 2006-03-16 23:19:47 -0700 (Thu, 16 Mar 2006) | 1 line

cauld - Bringing back MOStlyCE / TinyMCE 2.0.2 with fixed IE issue reported during Beta 1.
------------------------------------------------------------------------
r396 | cauld | 2006-03-16 22:57:17 -0700 (Thu, 16 Mar 2006) | 1 line

cauld - Removing mostlyce directory.  Reverting back to TinyMCE 2.0.2.
Too many issues with 2.0.4.  Fixed IE error without upgrading.
------------------------------------------------------------------------
r393 | counterpoint | 2006-03-14 14:59:44 -0700 (Tue, 14 Mar 2006) | 1 line

Tightened security
------------------------------------------------------------------------
r392 | counterpoint | 2006-03-14 14:59:00 -0700 (Tue, 14 Mar 2006) | 1 line

Mods to support new container component, and to secure RSS feeds.
------------------------------------------------------------------------
r391 | counterpoint | 2006-03-13 11:15:58 -0700 (Mon, 13 Mar 2006) | 1 line

Modified SEF code so that when SEO is switched off, URL still has ampersands encoded.
------------------------------------------------------------------------
r390 | counterpoint | 2006-03-13 11:15:11 -0700 (Mon, 13 Mar 2006) | 1 line

Reverted mosPathway makePathway, moved change into sefRelToAbs.  Modified error reporting
slightly to suppress errors during setup.
------------------------------------------------------------------------
r388 | cauld | 2006-03-12 12:39:31 -0700 (Sun, 12 Mar 2006) | 1 line

cauld - Changing end user installation survey to hand comments a bit differently.
Comments now go to feedback@mambo-foundation.org.
------------------------------------------------------------------------
r387 | cauld | 2006-03-12 12:03:29 -0700 (Sun, 12 Mar 2006) | 1 line

cauld - Fixing mostlyce.xml for IE contextmenu change
------------------------------------------------------------------------
r386 | cauld | 2006-03-12 12:00:28 -0700 (Sun, 12 Mar 2006) | 1 line

cauld - Adding IE fix for the MOStlyCE contextmenu plugin
------------------------------------------------------------------------
r385 | counterpoint | 2006-03-12 08:46:12 -0700 (Sun, 12 Mar 2006) | 1 line

Optimisation of mosDBTable move method.
------------------------------------------------------------------------
r384 | counterpoint | 2006-03-12 08:44:55 -0700 (Sun, 12 Mar 2006) | 1 line

Bug fixes
------------------------------------------------------------------------
r383 | counterpoint | 2006-03-12 08:43:56 -0700 (Sun, 12 Mar 2006) | 1 line

Hardened against misuse
------------------------------------------------------------------------
r382 | counterpoint | 2006-03-12 08:43:33 -0700 (Sun, 12 Mar 2006) | 1 line

Removed reliance on register_globals
------------------------------------------------------------------------
r380 | counterpoint | 2006-03-09 07:48:49 -0700 (Thu, 09 Mar 2006) | 1 line

Changes to mosDBTableEntry - not in live use - but needed for mosContainer development.
------------------------------------------------------------------------
r379 | cauld | 2006-03-08 22:54:56 -0700 (Wed, 08 Mar 2006) | 1 line

cauld - updating MOStlyCE xml file for TinyMCE 2.0.4 update
------------------------------------------------------------------------
r378 | cauld | 2006-03-08 22:51:54 -0700 (Wed, 08 Mar 2006) | 1 line

cauld - finishing MOStlyCE 1.5 / TinyMCE 2.0.4 upgrade
------------------------------------------------------------------------
r376 | cauld | 2006-03-08 22:01:09 -0700 (Wed, 08 Mar 2006) | 1 line

cauld - MOStlyCE Admin update to disable default compression
------------------------------------------------------------------------
r372 | cauld | 2006-03-08 21:27:28 -0700 (Wed, 08 Mar 2006) | 1 line

cauld - working on a mostlyce upgrade
------------------------------------------------------------------------
r371 | counterpoint | 2006-03-08 10:51:49 -0700 (Wed, 08 Mar 2006) | 1 line

Fix problem with mass chmod not recursing correctly
------------------------------------------------------------------------
r370 | counterpoint | 2006-03-08 10:51:22 -0700 (Wed, 08 Mar 2006) | 1 line

Fix access to Mambo configuration - cope in different contexts
------------------------------------------------------------------------
r369 | counterpoint | 2006-03-08 10:50:42 -0700 (Wed, 08 Mar 2006) | 1 line

Fix foreach failure on empty database results
------------------------------------------------------------------------
r363 | adi | 2006-03-06 19:42:01 -0700 (Mon, 06 Mar 2006) | 1 line

fix ticket #32
------------------------------------------------------------------------
r362 | adi | 2006-03-06 19:26:20 -0700 (Mon, 06 Mar 2006) | 1 line

fix typo
------------------------------------------------------------------------
r361 | cauld | 2006-03-06 07:02:33 -0700 (Mon, 06 Mar 2006) | 1 line

cauld - rechecking in gin's trash fix that was overwritten a while back
------------------------------------------------------------------------
r359 | adi | 2006-03-06 04:11:53 -0700 (Mon, 06 Mar 2006) | 1 line

fix ticket #31
------------------------------------------------------------------------
r357 | cauld | 2006-03-04 23:59:11 -0700 (Sat, 04 Mar 2006) | 1 line

cauld - updating version info for 4.6 public RC1
------------------------------------------------------------------------
r355 | cauld | 2006-03-04 23:54:55 -0700 (Sat, 04 Mar 2006) | 1 line

cauld - Adding new end user survey functionality to the last install screen
------------------------------------------------------------------------
r353 | counterpoint | 2006-03-02 10:26:20 -0700 (Thu, 02 Mar 2006) | 1 line

Bug fix - was reliant on register_globals.
------------------------------------------------------------------------
r352 | oziris | 2006-03-01 12:18:50 -0700 (Wed, 01 Mar 2006) | 1 line

Ticket #10 changing www.mamboserver.com to www.mambo-foundation.org
------------------------------------------------------------------------
r351 | oziris | 2006-03-01 11:57:37 -0700 (Wed, 01 Mar 2006) | 1 line

Ticket #8
------------------------------------------------------------------------
r350 | oziris | 2006-03-01 11:35:50 -0700 (Wed, 01 Mar 2006) | 1 line

Ticket #9
------------------------------------------------------------------------
r348 | cauld | 2006-03-01 07:35:46 -0700 (Wed, 01 Mar 2006) | 1 line

cauld - updating "Lost Password" error message to make it more clear that
both username and email address are required.
------------------------------------------------------------------------
r347 | adi | 2006-02-28 21:33:11 -0700 (Tue, 28 Feb 2006) | 1 line

ticket #46
------------------------------------------------------------------------
r346 | oziris | 2006-02-28 09:07:58 -0700 (Tue, 28 Feb 2006) | 1 line

updated calls to new help file names
------------------------------------------------------------------------
r345 | oziris | 2006-02-28 08:32:43 -0700 (Tue, 28 Feb 2006) | 1 line

Renamed help files so they don't contain 453 in the file name
------------------------------------------------------------------------
r342 | cauld | 2006-02-28 07:53:09 -0700 (Tue, 28 Feb 2006) | 1 line

cauld - Changing default MOStlyCE plugin layout based on suggestions from Water & Stone
------------------------------------------------------------------------
r341 | cauld | 2006-02-28 06:31:13 -0700 (Tue, 28 Feb 2006) | 1 line

cauld - Creating a empty files directory for use by MOStlyCE.  Uses this with
HTML templates and the file manager.  Closing Trac ticket #45.
------------------------------------------------------------------------
r339 | adi | 2006-02-27 21:48:46 -0700 (Mon, 27 Feb 2006) | 1 line

add mambo version info in administrator pages
------------------------------------------------------------------------
r338 | adi | 2006-02-27 03:55:24 -0700 (Mon, 27 Feb 2006) | 1 line

Trac Ticket #49
------------------------------------------------------------------------
r337 | adi | 2006-02-27 01:23:16 -0700 (Mon, 27 Feb 2006) | 1 line

fix makePathway() to correctly encode & entity into &amp;
------------------------------------------------------------------------
r336 | adi | 2006-02-26 23:14:05 -0700 (Sun, 26 Feb 2006) | 1 line

Trac Ticket #41
------------------------------------------------------------------------
r334 | adi | 2006-02-26 21:36:06 -0700 (Sun, 26 Feb 2006) | 1 line

add mod_latestcontent record
------------------------------------------------------------------------
r333 | adi | 2006-02-26 21:32:34 -0700 (Sun, 26 Feb 2006) | 1 line

add latest_content module
------------------------------------------------------------------------
r331 | cauld | 2006-02-25 12:49:00 -0700 (Sat, 25 Feb 2006) | 1 line

cauld - setting htmltemplate and caption to the list of auto started plugins within mostlyce
------------------------------------------------------------------------
r328 | cauld | 2006-02-25 12:28:09 -0700 (Sat, 25 Feb 2006) | 1 line

cauld - fixing a bug that caused the "Not Authorized" error when someone was trying to edit content from the frontend
------------------------------------------------------------------------
r327 | cauld | 2006-02-25 11:55:31 -0700 (Sat, 25 Feb 2006) | 1 line

cauld - correcting a mostlyce htmltemplate plugin issue
------------------------------------------------------------------------
r326 | cauld | 2006-02-25 11:54:12 -0700 (Sat, 25 Feb 2006) | 2 lines

cauld - correcting mostlyce config files for plugin changes
------------------------------------------------------------------------
r325 | cauld | 2006-02-25 11:03:32 -0700 (Sat, 25 Feb 2006) | 1 line

cauld - removing 4 unused mostlyce plugins
------------------------------------------------------------------------
r324 | cauld | 2006-02-25 10:57:35 -0700 (Sat, 25 Feb 2006) | 1 line

cauld - adding back in to old tinymce plugins that I removed before (caption & htmltemplate)
------------------------------------------------------------------------
r323 | oziris | 2006-02-24 13:57:52 -0700 (Fri, 24 Feb 2006) | 1 line

Updated for copyright notices.
------------------------------------------------------------------------
r322 | oziris | 2006-02-24 13:55:29 -0700 (Fri, 24 Feb 2006) | 1 line

Updated Copyright notices in XML files.
------------------------------------------------------------------------
r320 | counterpoint | 2006-02-24 09:46:13 -0700 (Fri, 24 Feb 2006) | 1 line

Improved (un)installer error handling. Modified session purge, making distinction between user side and admin side.
------------------------------------------------------------------------
r319 | counterpoint | 2006-02-23 04:30:16 -0700 (Thu, 23 Feb 2006) | 1 line

Bug fixes
------------------------------------------------------------------------
r316 | adi | 2006-02-22 23:25:01 -0700 (Wed, 22 Feb 2006) | 1 line

update mamboforge to mamboxchange
------------------------------------------------------------------------
r315 | konlong | 2006-02-22 06:31:46 -0700 (Wed, 22 Feb 2006) | 2 lines

Reference to undefined variable fixed in admin.menus.php function copyMenuSave
The use of the variable $and should be avoided in deference to $_and, $and gives an unknown token notice 8 files
------------------------------------------------------------------------
r314 | konlong | 2006-02-22 05:57:20 -0700 (Wed, 22 Feb 2006) | 2 lines

added call to addDescendants to the remove case.
Fixed undefined variable $database; in saveOrder()
------------------------------------------------------------------------
r313 | chanh | 2006-02-21 16:20:16 -0700 (Tue, 21 Feb 2006) | 2 lines

Missing closing php tags!
------------------------------------------------------------------------
r312 | chanh | 2006-02-21 16:08:14 -0700 (Tue, 21 Feb 2006) | 1 line

Missing closing php tags!
------------------------------------------------------------------------
r311 | chanh | 2006-02-21 16:07:58 -0700 (Tue, 21 Feb 2006) | 1 line

Missing closing php tags!
------------------------------------------------------------------------
r310 | cauld | 2006-02-21 07:02:46 -0700 (Tue, 21 Feb 2006) | 1 line

cauld - committing a change to database.php to fix a content update / insert
issue based on a suggested fix by counterpoint
------------------------------------------------------------------------
r309 | adi | 2006-02-20 20:47:49 -0700 (Mon, 20 Feb 2006) | 1 line

Trac ticket #36
------------------------------------------------------------------------
r305 | cauld | 2006-02-18 16:10:53 -0700 (Sat, 18 Feb 2006) | 1 line

cauld - Adding some stuff for MOStlyCE and fixing Safari warning
------------------------------------------------------------------------
r304 | csouza | 2006-02-16 20:07:10 -0700 (Thu, 16 Feb 2006) | 2 lines

corrected a few non i18ned strings
------------------------------------------------------------------------
r303 | csouza | 2006-02-16 20:06:03 -0700 (Thu, 16 Feb 2006) | 1 line

added localization vars to configuration.php-dist
------------------------------------------------------------------------
r302 | csouza | 2006-02-16 20:05:11 -0700 (Thu, 16 Feb 2006) | 1 line

fixed fixlanguage()
------------------------------------------------------------------------
r301 | csouza | 2006-02-16 20:04:10 -0700 (Thu, 16 Feb 2006) | 1 line

updated mod_whosonline to select a plural string from a specific language file
------------------------------------------------------------------------
r300 | csouza | 2006-02-16 20:02:31 -0700 (Thu, 16 Feb 2006) | 1 line

updated com_languages
------------------------------------------------------------------------
r299 | csouza | 2006-02-16 20:02:08 -0700 (Thu, 16 Feb 2006) | 1 line

updated com_languages
------------------------------------------------------------------------
r298 | csouza | 2006-02-16 20:00:30 -0700 (Thu, 16 Feb 2006) | 1 line

updated com_languages
------------------------------------------------------------------------
r297 | csouza | 2006-02-16 14:43:38 -0700 (Thu, 16 Feb 2006) | 1 line

replacement of copyright notices
------------------------------------------------------------------------
r296 | cauld | 2006-02-16 08:02:03 -0700 (Thu, 16 Feb 2006) | 1 line

cauld - fixing PHP version to low notice on install
------------------------------------------------------------------------
r295 | cauld | 2006-02-16 07:58:50 -0700 (Thu, 16 Feb 2006) | 1 line

cauld - updating install screen to display PHP version 4.3.0 as min requirement
------------------------------------------------------------------------
r294 | adi | 2006-02-16 01:59:01 -0700 (Thu, 16 Feb 2006) | 1 line

remove td width in printicon function
------------------------------------------------------------------------
r293 | adi | 2006-02-16 01:57:15 -0700 (Thu, 16 Feb 2006) | 1 line

remove td width in pdficon and emailicon function
------------------------------------------------------------------------
r292 | adi | 2006-02-16 01:34:47 -0700 (Thu, 16 Feb 2006) | 1 line

Trac ticket #38
------------------------------------------------------------------------
r290 | counterpoint | 2006-02-15 16:16:04 -0700 (Wed, 15 Feb 2006) | 1 line

Fix submit news problems by changing to submit faq (also removed itemid)
------------------------------------------------------------------------
r289 | counterpoint | 2006-02-15 10:56:19 -0700 (Wed, 15 Feb 2006) | 1 line

Fixed bugs in resequencing various types of item
------------------------------------------------------------------------
r288 | counterpoint | 2006-02-15 10:18:43 -0700 (Wed, 15 Feb 2006) | 1 line

Bug fixes
------------------------------------------------------------------------
r287 | counterpoint | 2006-02-15 09:49:55 -0700 (Wed, 15 Feb 2006) | 1 line

Bug fixes
------------------------------------------------------------------------
r286 | counterpoint | 2006-02-15 04:18:27 -0700 (Wed, 15 Feb 2006) | 2 lines

Bug fixes
------------------------------------------------------------------------
r284 | adi | 2006-02-14 22:18:19 -0700 (Tue, 14 Feb 2006) | 1 line

fix css problem for menu height in firefox
------------------------------------------------------------------------
r283 | counterpoint | 2006-02-14 15:39:59 -0700 (Tue, 14 Feb 2006) | 1 line

Bug fix problem analysing parameters from XML
------------------------------------------------------------------------
r282 | counterpoint | 2006-02-14 15:38:15 -0700 (Tue, 14 Feb 2006) | 1 line

Bug fix theme.js incorrect path to find menu images
------------------------------------------------------------------------
r281 | counterpoint | 2006-02-14 14:42:10 -0700 (Tue, 14 Feb 2006) | 2 lines

Bug fix
------------------------------------------------------------------------
r277 | adi | 2006-02-14 01:14:48 -0700 (Tue, 14 Feb 2006) | 2 lines

hide secret word in global config based on, Trac ticket #9
------------------------------------------------------------------------
r276 | adi | 2006-02-14 00:38:24 -0700 (Tue, 14 Feb 2006) | 1 line

Trac ticket #5
------------------------------------------------------------------------
r275 | adi | 2006-02-14 00:32:53 -0700 (Tue, 14 Feb 2006) | 2 lines

update sample data, Trac ticket #4
------------------------------------------------------------------------
r274 | adi | 2006-02-14 00:17:41 -0700 (Tue, 14 Feb 2006) | 2 lines

remove key reference based on
http://forum.mamboserver.com/showthread.php?t=66453
------------------------------------------------------------------------
r273 | adi | 2006-02-13 22:46:12 -0700 (Mon, 13 Feb 2006) | 2 lines

add client id column in showClients function, based on
Trac ticket #15
------------------------------------------------------------------------
r272 | counterpoint | 2006-02-13 08:41:51 -0700 (Mon, 13 Feb 2006) | 1 line

Installer developments and bugs, syndstyle handling.
------------------------------------------------------------------------
r271 | counterpoint | 2006-02-13 08:37:07 -0700 (Mon, 13 Feb 2006) | 1 line

Installer bug fixes and development.
------------------------------------------------------------------------
r270 | counterpoint | 2006-02-13 08:31:12 -0700 (Mon, 13 Feb 2006) | 1 line

Syndstyle and file handling bug fixes.
------------------------------------------------------------------------
r269 | counterpoint | 2006-02-13 08:12:12 -0700 (Mon, 13 Feb 2006) | 1 line

Introduce syndstyle to allow components to be used as objects at other sites.
------------------------------------------------------------------------
r268 | adi | 2006-02-13 03:59:27 -0700 (Mon, 13 Feb 2006) | 1 line

fix global variables
------------------------------------------------------------------------
r267 | adi | 2006-02-13 03:52:27 -0700 (Mon, 13 Feb 2006) | 1 line

fix showInstallMessage function, add third parameter for redirect
------------------------------------------------------------------------
r266 | csouza | 2006-02-12 16:49:56 -0700 (Sun, 12 Feb 2006) | 2 lines

fixed some localization bugs
------------------------------------------------------------------------
r265 | csouza | 2006-02-12 16:49:14 -0700 (Sun, 12 Feb 2006) | 1 line

localization
------------------------------------------------------------------------
r264 | csouza | 2006-02-12 16:45:24 -0700 (Sun, 12 Feb 2006) | 1 line

fixed some localization bugs
------------------------------------------------------------------------
r263 | csouza | 2006-02-12 16:44:33 -0700 (Sun, 12 Feb 2006) | 1 line

localization fixes
------------------------------------------------------------------------
r262 | csouza | 2006-02-12 16:43:25 -0700 (Sun, 12 Feb 2006) | 1 line

fixed some localization bugs
------------------------------------------------------------------------
r260 | cauld | 2006-02-12 15:11:01 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - Adding MOStlyCE onclick plugin
------------------------------------------------------------------------
r259 | cauld | 2006-02-12 13:41:12 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE table plugin upgrade
------------------------------------------------------------------------
r258 | cauld | 2006-02-12 13:39:40 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE advlink plugin upgrade
------------------------------------------------------------------------
r257 | cauld | 2006-02-12 13:38:07 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE advimage plugin fix
------------------------------------------------------------------------
r256 | cauld | 2006-02-12 13:36:52 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE advhr plugin fix
------------------------------------------------------------------------
r255 | cauld | 2006-02-12 13:34:32 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE preview plugin fix
------------------------------------------------------------------------
r254 | cauld | 2006-02-12 13:31:54 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - MOStlyCE auth_plugin.php change to handle the removal of auth.php
------------------------------------------------------------------------
r253 | csouza | 2006-02-12 12:38:26 -0700 (Sun, 12 Feb 2006) | 1 line

mostlyce popup fix
------------------------------------------------------------------------
r252 | csouza | 2006-02-12 12:37:34 -0700 (Sun, 12 Feb 2006) | 2 lines

fix for mostlyce popup and localization calls to select language file
------------------------------------------------------------------------
r251 | cauld | 2006-02-12 10:25:32 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - more MOStlyCE changes
------------------------------------------------------------------------
r250 | cauld | 2006-02-12 10:17:00 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - adding mclayer.js for MOStlyCE
------------------------------------------------------------------------
r247 | cauld | 2006-02-12 08:52:29 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - removing old MOStlyCE onclick plugin
------------------------------------------------------------------------
r246 | cauld | 2006-02-12 08:49:29 -0700 (Sun, 12 Feb 2006) | 1 line

cauld - Upgrading MOStlyCE guts to 2.0.2 and fixing a few MOStlyCE bugs
------------------------------------------------------------------------
r245 | counterpoint | 2006-02-10 10:38:03 -0700 (Fri, 10 Feb 2006) | 1 line

Mambot handler fix, compatibility fixes.
------------------------------------------------------------------------
r244 | counterpoint | 2006-02-10 07:08:05 -0700 (Fri, 10 Feb 2006) | 1 line

Compatibility fixes.
------------------------------------------------------------------------
r243 | counterpoint | 2006-02-10 05:42:40 -0700 (Fri, 10 Feb 2006) | 1 line

Handle https and non standard ports; reduce volume of metadata by restricting to one item.
------------------------------------------------------------------------
r238 | counterpoint | 2006-02-07 11:03:58 -0700 (Tue, 07 Feb 2006) | 1 line

Bug fixes, mostly missing ampersands.
------------------------------------------------------------------------
r237 | counterpoint | 2006-02-06 09:36:18 -0700 (Mon, 06 Feb 2006) | 1 line

Remove "generator" tag, improve SEF to cover archived material, correct bugs in contact component.
------------------------------------------------------------------------
r236 | csouza | 2006-02-06 08:35:49 -0700 (Mon, 06 Feb 2006) | 1 line

fixed php4 reference to component handler
------------------------------------------------------------------------
r235 | counterpoint | 2006-02-05 10:46:04 -0700 (Sun, 05 Feb 2006) | 1 line

Bug fix
------------------------------------------------------------------------
r234 | counterpoint | 2006-02-05 09:08:28 -0700 (Sun, 05 Feb 2006) | 1 line

Security fixes.  Add universal installer code.
------------------------------------------------------------------------
r233 | cauld | 2006-02-04 14:29:29 -0700 (Sat, 04 Feb 2006) | 1 line

cauld - updating version info for release
------------------------------------------------------------------------
r232 | csouza | 2006-02-04 13:36:36 -0700 (Sat, 04 Feb 2006) | 2 lines

corrected path to phpInputFilter
------------------------------------------------------------------------
r231 | csouza | 2006-02-04 13:36:24 -0700 (Sat, 04 Feb 2006) | 2 lines

corrected path to phpInputFilter
------------------------------------------------------------------------
r230 | csouza | 2006-02-04 13:13:58 -0700 (Sat, 04 Feb 2006) | 1 line

added admin.languages.class.php
------------------------------------------------------------------------
r229 | cauld | 2006-02-04 11:45:08 -0700 (Sat, 04 Feb 2006) | 1 line

cauld - fixing phpInputFilter path
------------------------------------------------------------------------
r228 | cauld | 2006-02-04 10:32:51 -0700 (Sat, 04 Feb 2006) | 1 line

cauld - fixing issue with __parameters create table statement
------------------------------------------------------------------------
r226 | counterpoint | 2006-02-03 02:43:17 -0700 (Fri, 03 Feb 2006) | 1 line

Delete patTemplate
------------------------------------------------------------------------
r223 | counterpoint | 2006-02-02 15:13:45 -0700 (Thu, 02 Feb 2006) | 1 line

Tidying up and bug fixing.
------------------------------------------------------------------------
r222 | counterpoint | 2006-02-02 07:50:48 -0700 (Thu, 02 Feb 2006) | 1 line

Various bug fixes and tidying up.
------------------------------------------------------------------------
r221 | csouza | 2006-02-01 16:44:54 -0700 (Wed, 01 Feb 2006) | 1 line

corrected notice in fixlanguages
------------------------------------------------------------------------
r220 | csouza | 2006-02-01 16:21:57 -0700 (Wed, 01 Feb 2006) | 1 line

language fix
------------------------------------------------------------------------
r219 | csouza | 2006-02-01 16:04:51 -0700 (Wed, 01 Feb 2006) | 1 line

language/english.xml
------------------------------------------------------------------------
r218 | counterpoint | 2006-02-01 13:38:06 -0700 (Wed, 01 Feb 2006) | 1 line

Universal installer UI.
------------------------------------------------------------------------
r216 | csouza | 2006-02-01 09:45:51 -0700 (Wed, 01 Feb 2006) | 1 line

complete set of language files for translation
------------------------------------------------------------------------
r213 | counterpoint | 2006-01-31 05:11:42 -0700 (Tue, 31 Jan 2006) | 1 line

Mambot developments.
------------------------------------------------------------------------
r212 | counterpoint | 2006-01-31 01:30:02 -0700 (Tue, 31 Jan 2006) | 1 line

Add support for free standing parameter object installation.
------------------------------------------------------------------------
r211 | csouza | 2006-01-30 16:38:54 -0700 (Mon, 30 Jan 2006) | 1 line

added define check to prevent notices
------------------------------------------------------------------------
r210 | csouza | 2006-01-30 16:31:55 -0700 (Mon, 30 Jan 2006) | 1 line

restored english.php and english.ignore.php
------------------------------------------------------------------------
r209 | counterpoint | 2006-01-30 15:13:58 -0700 (Mon, 30 Jan 2006) | 1 line

Extra mambot hooks for registration, password changes.
------------------------------------------------------------------------
r208 | counterpoint | 2006-01-30 10:58:42 -0700 (Mon, 30 Jan 2006) | 1 line

Handle language issue causing double display of modules.
------------------------------------------------------------------------
r207 | counterpoint | 2006-01-30 07:25:33 -0700 (Mon, 30 Jan 2006) | 1 line

Possible fix for authenticator not found bug.
------------------------------------------------------------------------
r206 | counterpoint | 2006-01-30 07:14:36 -0700 (Mon, 30 Jan 2006) | 1 line

Installer error handling, version to point to Foundation web site, attempted fix for redirect.
------------------------------------------------------------------------
r205 | cauld | 2006-01-28 10:06:06 -0700 (Sat, 28 Jan 2006) | 1 line
------------------------------------------------------------------------
r204 | cauld | 2006-01-28 10:03:42 -0700 (Sat, 28 Jan 2006) | 1 line

cauld - adding MOStlyCE admin component
------------------------------------------------------------------------
r202 | cauld | 2006-01-28 09:45:00 -0700 (Sat, 28 Jan 2006) | 1 line

cauld - MOStlyCE change
------------------------------------------------------------------------
r199 | counterpoint | 2006-01-27 08:37:12 -0700 (Fri, 27 Jan 2006) | 1 line

Installer bug fixes and changes to handle Docman latest.  Bug fix in installation/index.php.
------------------------------------------------------------------------
r198 | csouza | 2006-01-26 17:20:20 -0700 (Thu, 26 Jan 2006) | 1 line

added the final complete language catalog containing 2027 unique strings.
------------------------------------------------------------------------
r197 | counterpoint | 2006-01-26 16:40:05 -0700 (Thu, 26 Jan 2006) | 1 line

Correction for archive manager - error when database objects not an array - used for array merge.
------------------------------------------------------------------------
r196 | counterpoint | 2006-01-26 16:23:04 -0700 (Thu, 26 Jan 2006) | 1 line

Improved site search.
------------------------------------------------------------------------
r195 | csouza | 2006-01-26 13:20:17 -0700 (Thu, 26 Jan 2006) | 1 line

removed unnecessary file from com_languages
------------------------------------------------------------------------
r194 | csouza | 2006-01-26 13:11:56 -0700 (Thu, 26 Jan 2006) | 1 line

verified and corrected all deprecated localization constants
------------------------------------------------------------------------
r193 | counterpoint | 2006-01-26 11:09:47 -0700 (Thu, 26 Jan 2006) | 1 line

Optimise DB access in admin of users.  Correct HTML yes/no radio buttons.
------------------------------------------------------------------------
r192 | counterpoint | 2006-01-26 11:07:55 -0700 (Thu, 26 Jan 2006) | 1 line

Replaced ACL related code for storing new users (removed during testing of new access mechanisms).
------------------------------------------------------------------------
r191 | counterpoint | 2006-01-26 09:07:51 -0700 (Thu, 26 Jan 2006) | 1 line

Small bug fixes
------------------------------------------------------------------------
r190 | cauld | 2006-01-26 07:45:16 -0700 (Thu, 26 Jan 2006) | 1 line

cauld - fixing a mostlyce xml issue
------------------------------------------------------------------------
r189 | cauld | 2006-01-26 07:44:44 -0700 (Thu, 26 Jan 2006) | 1 line

cauld - fixing a mostlyce xml issue
------------------------------------------------------------------------
r188 | csouza | 2006-01-26 06:06:55 -0700 (Thu, 26 Jan 2006) | 1 line

fixed localization notices
------------------------------------------------------------------------
r187 | counterpoint | 2006-01-26 05:49:51 -0700 (Thu, 26 Jan 2006) | 1 line

Fix problem in mambo.sql losing user login authenticator mambot.
------------------------------------------------------------------------
r186 | counterpoint | 2006-01-26 04:51:01 -0700 (Thu, 26 Jan 2006) | 1 line

Merge and other bug fixes.  Suppress pathway if only says "Home".  Suppress warnings from Magpie.
------------------------------------------------------------------------
r185 | csouza | 2006-01-25 16:55:33 -0700 (Wed, 25 Jan 2006) | 1 line

replaced language constants
------------------------------------------------------------------------
r183 | csouza | 2006-01-25 14:36:13 -0700 (Wed, 25 Jan 2006) | 1 line

fixed i18n bugs and notices
------------------------------------------------------------------------
r182 | counterpoint | 2006-01-25 10:21:03 -0700 (Wed, 25 Jan 2006) | 1 line

Adjust for database.php moving back to /includes.  Remove executable code from version.php (should be just class, executable code is in index.php).
------------------------------------------------------------------------
r180 | csouza | 2006-01-25 06:42:26 -0700 (Wed, 25 Jan 2006) | 1 line

fixed localization bug
------------------------------------------------------------------------
r179 | csouza | 2006-01-25 06:41:01 -0700 (Wed, 25 Jan 2006) | 1 line

phpgettext update
------------------------------------------------------------------------
r178 | csouza | 2006-01-24 09:16:09 -0700 (Tue, 24 Jan 2006) | 1 line

update phpgettext.catalog.php
------------------------------------------------------------------------
r177 | csouza | 2006-01-24 09:15:11 -0700 (Tue, 24 Jan 2006) | 1 line

updating language directory and first complete string catalog
------------------------------------------------------------------------
r176 | cauld | 2006-01-24 07:36:50 -0700 (Tue, 24 Jan 2006) | 1 line

cauld - fixing MOStlyCE undefined variable notice
------------------------------------------------------------------------
r175 | csouza | 2006-01-24 04:45:38 -0700 (Tue, 24 Jan 2006) | 1 line

corrected return value in ngettext
------------------------------------------------------------------------
r174 | counterpoint | 2006-01-24 03:27:45 -0700 (Tue, 24 Jan 2006) | 1 line

Correct problem with merge.
------------------------------------------------------------------------
r172 | counterpoint | 2006-01-24 02:23:40 -0700 (Tue, 24 Jan 2006) | 1 line

Correct short tag
------------------------------------------------------------------------
r171 | cauld | 2006-01-23 21:57:24 -0700 (Mon, 23 Jan 2006) | 1 line

cauld - fixing an include file in mostlyce.php
------------------------------------------------------------------------
r170 | counterpoint | 2006-01-23 16:11:50 -0700 (Mon, 23 Jan 2006) | 1 line

Bring 4.5.4 /includes/frontend.php into 4.6
------------------------------------------------------------------------
r169 | counterpoint | 2006-01-23 10:57:22 -0700 (Mon, 23 Jan 2006) | 1 line

Fix installation bugs.
------------------------------------------------------------------------
r168 | csouza | 2006-01-22 21:47:31 -0700 (Sun, 22 Jan 2006) | 1 line

modified getConfig () in index.php to remove 'administrator' from mosConfig_live_site
------------------------------------------------------------------------
r167 | csouza | 2006-01-22 21:45:40 -0700 (Sun, 22 Jan 2006) | 1 line

switched phpgettext debugging off
------------------------------------------------------------------------
r166 | csouza | 2006-01-22 21:44:09 -0700 (Sun, 22 Jan 2006) | 1 line

added two css classes to remove <font> tags
------------------------------------------------------------------------
r162 | cauld | 2006-01-22 01:10:42 -0700 (Sun, 22 Jan 2006) | 1 line

cauld - updating install sql file to include entries for MOStlyCE
------------------------------------------------------------------------
r160 | cauld | 2006-01-22 01:04:13 -0700 (Sun, 22 Jan 2006) | 1 line

cauld - adding MOStlyCE mambot
------------------------------------------------------------------------
r159 | cauld | 2006-01-22 01:01:09 -0700 (Sun, 22 Jan 2006) | 1 line

cauld - adding MOStlyCE component
------------------------------------------------------------------------
r158 | cauld | 2006-01-22 00:58:59 -0700 (Sun, 22 Jan 2006) | 1 line

cauld - cleaning merge artifacts in index.php that were causing failures
------------------------------------------------------------------------
r157 | mambo | 2006-01-21 09:20:19 -0700 (Sat, 21 Jan 2006) | 1 line

cauld - Merging in the final 4.5.4 branch revisions (155 & 156).

The 4.5.4 branch is now closed.
------------------------------------------------------------------------
r153 | csouza | 2006-01-19 10:11:47 -0700 (Thu, 19 Jan 2006) | 1 line

added debugging capabilities
------------------------------------------------------------------------
r152 | csouza | 2006-01-19 10:10:57 -0700 (Thu, 19 Jan 2006) | 1 line

added gettext support to mamboCore::fixLanguage()
------------------------------------------------------------------------
r151 | csouza | 2006-01-19 07:24:56 -0700 (Thu, 19 Jan 2006) | 1 line

csouza - Merging 4.5.4 changes (revisions 139 to 148) into 4.6.
------------------------------------------------------------------------
r150 | csouza | 2006-01-19 06:37:49 -0700 (Thu, 19 Jan 2006) | 1 line

csouza - i18n - uploaded/removed i18n files
------------------------------------------------------------------------
r149 | csouza | 2006-01-19 06:29:35 -0700 (Thu, 19 Jan 2006) | 1 line

csouza - i18n - uploaded several internationalized files
------------------------------------------------------------------------
r138 | csouza | 2006-01-16 04:12:43 -0700 (Mon, 16 Jan 2006) | 1 line

csouza - Merging 4.5.4 changes (revisions 131 to 137) into 4.6.
------------------------------------------------------------------------
r129 | csouza | 2006-01-14 11:19:40 -0700 (Sat, 14 Jan 2006) | 1 line

csouza - Merging 4.5.4 changes (revisions 118 to 127) into 4.6.
------------------------------------------------------------------------
r117 | mambo | 2006-01-07 14:26:39 -0700 (Sat, 07 Jan 2006) | 1 line

cauld - Merging the current 4.5.4 changes (revisions 2 thru 99) into 4.6.
------------------------------------------------------------------------
r114 | mambo | 2006-01-06 14:16:56 -0700 (Fri, 06 Jan 2006) | 1 line

cauld - merging 453h revisions 30 thru 38 into 4.6
------------------------------------------------------------------------
r113 | mambo | 2006-01-06 13:05:43 -0700 (Fri, 06 Jan 2006) | 1 line

cauld - removing the old tinymce dir from 4.6.  it is causing merge issues with this branch as well.
------------------------------------------------------------------------
r112 | mambo | 2006-01-05 22:54:35 -0700 (Thu, 05 Jan 2006) | 1 line

cauld - merging revisions 22 thru 30 into 4.6.
------------------------------------------------------------------------
r3 | root | 2005-12-12 20:49:45 -0700 (Mon, 12 Dec 2005) | 1 line

creating branch
------------------------------------------------------------------------
