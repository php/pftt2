<?php

$forum_loader->add_css($base_url.'/style/Oxygen/Oxygen.min.css', array('type' => 'url', 'group' => FORUM_CSS_GROUP_SYSTEM, 'media' => 'screen'));

?>
