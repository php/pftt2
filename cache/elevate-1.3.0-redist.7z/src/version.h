// Full name; this will appear in the version info
#define ELEVATE_NAME_STR "Command-Line UAC Elevation Utility"

// Full version: MUST be in the form of major,minor,revision,build
#define ELEVATE_VERSION_FULL 1,3,0,0

// String version: May be any suitable string
#define ELEVATE_VERSION_STR "1.3.0.0"

// PE version: MUST be in the form of major.minor
#pragma comment(linker, "/version:1.3")
