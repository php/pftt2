<?php
/**
 * @package     Joomla.UnitTest
 * @subpackage  HTML
 *
 * @copyright   Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

require_once JPATH_PLATFORM . '/legacy/html/category.php';

/**
 * Test class for JHtmlCategory.
 *
 * @since  11.1
 */
class JHtmlCategoryTest extends PHPUnit_Framework_TestCase
{
	/**
	 * @todo Implement testOptions().
	 */
	public function testOptions()
	{
		// Remove the following lines when you implement this test.
		$this->markTestIncomplete(
		'This test has not been implemented yet.'
		);
	}
}
