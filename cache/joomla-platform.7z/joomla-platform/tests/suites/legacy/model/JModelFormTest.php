<?php
/**
 * @version		$Id: JModelFormTest.php 20196 2011-01-09 02:40:25Z ian $
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Test class for JModelForm.
 */
class JModelFormTest extends PHPUnit_Framework_TestCase
{
	/**
	 * @todo Implement testGetForm().
	 */
	public function testGetForm()
	{
		// Remove the following lines when you implement this test.
		$this->markTestIncomplete('This test has not been implemented yet.');
	}

	/**
	 * @todo Implement testValidate().
	 */
	public function testValidate()
	{
		// Remove the following lines when you implement this test.
		$this->markTestIncomplete('This test has not been implemented yet.');
	}
}
