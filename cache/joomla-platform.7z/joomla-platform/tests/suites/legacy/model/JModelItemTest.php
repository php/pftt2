<?php
/**
 * @version		$Id: JModelItemTest.php 20196 2011-01-09 02:40:25Z ian $
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Test class for JModelItem.
 */
class JModelItemTest extends PHPUnit_Framework_TestCase
{
	/**
	 * @todo Decide how to Implement.
	 */
	public function testDummy()
	{
		// Remove the following lines when you implement this test.
		$this->markTestIncomplete('This test has not been implemented yet.');
	}
}
