#
#<?php die('Forbidden.'); ?>
#Date: 2012-09-25 18:04:35 UTC
#Software: Joomla Platform 12.1.0 Stable [ Louis Landry ] 10-May-2012 00:00 GMT

#Fields: priority	category	message
INFO	-	Testing Entry 01
ERROR	-	Testing 02
EMERGENCY	deprecated	Testing3
